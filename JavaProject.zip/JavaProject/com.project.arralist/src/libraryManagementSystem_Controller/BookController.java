package libraryManagementSystem_Controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import libraryManagementSystem_Model.Book;
import libraryManagementSystem_Model.Sort_By_Author;
import libraryManagementSystem_Model.Sort_By_Id;
import libraryManagementSystem_Model.Sort_By_Title;

public class BookController {
	private ArrayList<Book> arrayList = new ArrayList<>();
	private Scanner scanner = new Scanner(System.in);

	public void add() {
		System.out.println("Enter the book title");
		String title = scanner.next();
		System.out.println("Enter the book author");
		String author = scanner.next();
		System.out.println("Enter the book id");
		String id = scanner.next();
		Book book = new Book(title, author, id, true);
		arrayList.add(book);
		System.out.println("Book added into Library successfully");
	}

	public void serachBook() {
		System.out.println("Enter the title or author or id to serach");
		String str = scanner.next();
		boolean found = false;
		for (Book book : arrayList) {
			if (book.getTitle().equalsIgnoreCase(str) || book.getAuthor().equalsIgnoreCase(str)
					|| book.getId().equalsIgnoreCase(str)) {
				System.out.println("Book found");
				System.out.println(book);
				found = true;
				break;
			}
		}
		if (found == false) {
			System.out.println("Book not found in the Library");
		}
	}

	public void barrowBook() {
		System.out.println("Enter the title or author or id to serach");
		String str = scanner.next();
		boolean found = false;
		for (Book book : arrayList) {
			if (book.getTitle().equalsIgnoreCase(str) || book.getAuthor().equalsIgnoreCase(str)
					|| book.getId().equalsIgnoreCase(str) && book.isAvailable()) {
				found = true;
				arrayList.remove(str);
				System.out.println("Book barrowed successfully");
				break;
			}
		}
		if (found == false) {
			System.out.println("Book not found in the Library");
		}
	}

	public void returnBook() {
		System.out.println("Enter the title or author or id to serach");
		String str = scanner.next();
		boolean found = false;
		for (Book book : arrayList) {
			if (book.getTitle().equalsIgnoreCase(str) || book.getAuthor().equalsIgnoreCase(str)
					|| book.getId().equalsIgnoreCase(str) && !(book.isAvailable())) {
				book.setAvailable(true);
				System.out.println("Book returned successfully");
				found = true;
				break;
			}
		}
		if (found == false) {
			System.out.println("Book Data not matched");
		}
	}

	public void removeBook() {
		System.out.println("Enter the title or author or id to serach");
		String str = scanner.next();
		boolean found = false;
		for(int i=0; i<arrayList.size(); i++)
		{
			Book book = arrayList.get(i);
			if (book.getTitle().equalsIgnoreCase(str) || book.getAuthor().equalsIgnoreCase(str)
					|| book.getId().equalsIgnoreCase(str))
			{
				arrayList.remove(book);
				System.out.println("Book has been removed from library...!");
				found = true;
				break;
			}
		}
		if (found == false) {
			System.out.println("Book Data not matched");
		}
	}
	public void sort()
	{
		System.out.println(" 1 :Sort based on title");
		System.out.println(" 2 :Sort based on author");
		System.out.println(" 3 :Sort based on id");
		System.out.println("Enter the choice");
		int choice = scanner.nextInt();
		switch(choice)
		{
		case 1: Collections.sort(arrayList, new Sort_By_Title());
		System.out.println(arrayList);
			break;
			
		case 2:Collections.sort(arrayList, new Sort_By_Author());
		System.out.println(arrayList);
			break;
		case 3:Collections.sort(arrayList, new Sort_By_Id());
		System.out.println(arrayList);
			break;
		}
	}
}
