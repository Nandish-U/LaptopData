package libraryManagementSystem_View;

import java.util.Scanner;

import libraryManagementSystem_Controller.BookController;

public class DriverBook {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		BookController bc = new BookController();
		while (true) {
			System.out.println("Welcome to Book Library Management System...!");
			System.out.println(" 1: addBook\n 2: SearchBook\n 3: BarrowBook\n 4: ReturnBook\n 5: RemoveBook\n"
					+ " 6: Sort \n 7: exit");
			System.out.println("Please enter your choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				bc.add();
				break;
			case 2:
				bc.serachBook();
				break;
			case 3:
				bc.barrowBook();
				break;
			case 4:
				bc.returnBook();
				break;
			case 5:
				bc.removeBook();
				break;
			case 6:
				bc.sort();
				break;
			case 7:
				System.out.println("Thankyou");
				System.exit(0);
				break;
			}
		}
	}
}
