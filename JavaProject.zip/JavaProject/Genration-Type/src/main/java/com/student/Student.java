package com.student;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name="student_table")
public class Student {
	@Id
	@Column(name="s_id")
	// our own id sequence with auto generating and sequence table will be created
//	@GeneratedValue(strategy = GenerationType.TABLE, generator = "stu_seq_tab")
//	@TableGenerator(name="stu_seq_tab" , initialValue = 1, allocationSize = 10, table = ="my_stu_seq"_tab)
	@GeneratedValue(strategy = GenerationType.TABLE,generator = "stu_rol_gen")
	@SequenceGenerator(name="stu_rol_gen", initialValue = 100, allocationSize = 10, sequenceName = "stu_seq_info")
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@GeneratedValue(strategy = GenerationType.AUTO )
	private int id;
	@Column(name="student_name")
	private String name;
	@Column(name = "student_email")
	private String email;
	private double height;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
}	
