package driver;

import book.Book;
import bookController.BookController;
import java.util.*;

public class Driver {
	public static void main(String[] args) {
		BookController c = new BookController();
		Scanner s = new Scanner(System.in);
		jk: while (true) {
			System.out.println("Enter the operation to perform");
			System.out.println("1. Add new book");
			System.out.println("2. Search book");
			System.out.println("3. Update book");
			System.out.println("4. To stop");
			int a = s.nextInt();
			switch (a) {
			case 1:
				c.add();
				break;
			case 2:
				c.search();
				break;
			case 3:
				c.update();
			case 4:
				System.out.println("Thank you");
				break jk;
			default:
				System.out.println("Enter valid input");
			}
		}
	}

}
