package bookController;
import java.util.*;

import book.Book;


public class BookController {
	HashSet<Book> a=new HashSet();
	Scanner s=new Scanner(System.in);
	
	public void add() {
		System.out.println("enter book Title");
		String title = s.nextLine();
		System.out.println("enter book Author");
		String author = s.nextLine();
		System.out.println("enter book Id");
		int id= s.nextInt();
		a.add(new Book(title, author,id));
		System.out.println("Book Added Successfully");
		}
	
	public void search() {
		
		System.out.println("Enter Book id");
		int c=s.nextInt();
		for(Book b:a) {
			if (c==b.getId()) {
				System.out.println("the book Title is "+ b.getTitle());
				System.out.println("the book Author is "+ b.getAuthor());
				return;
			}
			else
				System.out.println("Not Found");
		}
	}
	public void update() {
		System.out.println("Enter Book id to update");
		int c=s.nextInt();
		for(Book b:a) {
			if (c==b.getId()) {
				System.out.println("Enter new title");
				String n=s.nextLine();
				b.setTitle(n);
				System.out.println("Enter new Author");
				String m=s.nextLine();
				b.setAuthor(m);
			}
			else
				System.out.println("Not Found");
		}
	}
	

}