package com.bicycle.model;

import java.util.HashMap;
import java.util.Map;

public class Bi_Cycle_Inventory 
{
	private Map<String, Stock> map = new HashMap<>();

	public Map<String, Stock> getMap() {
		return map;
	}
	
	public  void stock()
	{
		map.put("seats", new Stock("seat",50));
		map.put("frames", new Stock("frame",80));
		map.put("brake sets", new Stock("brakeSet",25));
		map.put("brake paddles", new Stock("brakePaddle",100));
		map.put("brake cables", new Stock("brakeCable",75));
		map.put("levers", new Stock("lever",60));
		map.put("brake shoes", new Stock("brakeShoe",150));
		map.put("handle bars", new Stock("handleBar",100));
		map.put("wheels", new Stock("wheel",60));
		map.put("tires", new Stock("tire",80));
		map.put("chains", new Stock("chain",100));
		map.put("crank set", new Stock("crankSet",50));
		map.put("paddles", new Stock("paddle",150));
	}

	@Override
	public String toString() {
		return "Bi_Cycle_Inventory [map=" + map + "]";
	}
	
}
