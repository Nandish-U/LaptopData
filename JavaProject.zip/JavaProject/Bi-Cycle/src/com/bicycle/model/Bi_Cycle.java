package com.bicycle.model;

import java.util.HashMap;
import java.util.Map;

public class Bi_Cycle {
	
	private Map<String, Integer> map = new HashMap<>();
	
	public Map<String, Integer> getMap() {
		return map;
	}

	public void setMap(Map<String, Integer> map) {
		this.map = map;
	}

	public void add()
	{
		map.put("seat", 1);
		map.put("frame", 1);
		map.put("brakeSet", 2);
		map.put("handleBar", 1);
		map.put("wheel", 2);
		map.put("tire", 2);
		map.put("crankSet", 1);
		map.put("peddal", 2);
		map.put("chain", 1);
	}
//	private int seat=1;
//	private int frame=1;
//	private int brake_set=2;
//	private int handleBar=1;
//	private int wheels=2;
//	private int tires=2;
//	private int chain=1;
//	private int crank_Set=1;
//	private int pedals=2;
//	public int getSeat() {
//		return seat;
//	}
//	public int getFrame() {
//		return frame;
//	}
//	public int getBrake_set() {
//		return brake_set;
//	}
//	public int getHandleBar() {
//		return handleBar;
//	}
//	public int getWheels() {
//		return wheels;
//	}
//	public int getTires() {
//		return tires;
//	}
//	public int getChain() {
//		return chain;
//	}
//	public int getCrank_Set() {
//		return crank_Set;
//	}
//	public int getPedals() {
//		return pedals;
//	}
	
}
