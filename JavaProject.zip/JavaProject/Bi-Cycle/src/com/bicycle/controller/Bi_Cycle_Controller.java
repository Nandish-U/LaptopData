package com.bicycle.controller;

import java.util.Set;

import com.bicycle.model.Bi_Cycle;
import com.bicycle.model.Bi_Cycle_Inventory;

public class Bi_Cycle_Controller {
	Bi_Cycle_Inventory b1 = new Bi_Cycle_Inventory();
	Bi_Cycle i = new Bi_Cycle();

	public void Mrp() {
		b1.stock();
		i.add();
		Set<String> keys = b1.getMap().keySet();
		Set<String> s = i.getMap().keySet();
		for (String it : keys) {
			for(String it2: s)
			{
				if(it2.equalsIgnoreCase(b1.getMap().get(it).getName()))
				{
					
				}
			}
		}
	}

	public static void main(String[] args) {
		Bi_Cycle_Controller c = new Bi_Cycle_Controller();
		c.Mrp();
	}

}
