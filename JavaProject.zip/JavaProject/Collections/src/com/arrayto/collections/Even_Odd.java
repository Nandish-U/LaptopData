package com.arrayto.collections;

import java.util.ArrayList;
import java.util.Collections;

public class Even_Odd 
{
	public static void main(String[] args) 
	{
		int[] a = {10,15,65,75,85};
		ArrayList<Integer> even = new ArrayList<>();
//		ArrayList odd = new ArrayList<>();
		
		for(int i=0; i<a.length ;i++)
		{
//			if(a[i]%2==0)
			even.add(a[i]);
//			else
//			odd.add(a[i]);	
		}
		System.out.println(even);
		for(int i=0; i<even.size(); i++)
		{
			if(even.get(i)%2==0)
			{
				System.out.print(even.get(i)+" ");
			}
		}
//		Collections.sort(even);
//		System.out.print(even+" ");
//		System.out.println();
//		Collections.sort(odd);
//		System.out.print(odd+" ");
	}
}
