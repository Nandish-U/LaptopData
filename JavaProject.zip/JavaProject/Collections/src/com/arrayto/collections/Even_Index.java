package com.arrayto.collections;

import java.util.ArrayList;

public class Even_Index {
	public static void main(String[] args) 
	{
		int[] a = {10,25,23,32,85,78,42};
		ArrayList<Integer> even = new ArrayList<>();
		for(int i=0; i<a.length; i++)
		{
			even.add(a[i]);
		}
		for(int i=0; i<even.size(); i++)
		{
			if(i%2==0)
			{
				System.out.println(even.get(i));
			}
		}
	}

}
