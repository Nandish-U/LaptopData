package com.arrayto.collections;

import java.util.ArrayList;
import java.util.Collections;

public class Count_Frequency {
	public static void main(String[] args) 
	{
		int[] a = {10,25,23,32,10,78,10};
		ArrayList<Integer> even = new ArrayList<>();
		for(int i=0; i<a.length; i++)
		{
			even.add(a[i]);
		}
//		for(Integer e:even)
//		{
//		System.out.println(Collections.frequency(even, e));
//		}
		for(int i=0; i<even.size(); i++)
		{
			System.out.println(Collections.frequency(even, even.get(i)));
		}
	}
}
