package com.arrayto.collections;

import java.util.ArrayList;

public class Divisible_By5 
{
	public static void main(String[] args) 
	{
		int[] a = {10,25,23,32,85,78,42};
		ArrayList<Integer> a1 = new ArrayList<>();
		for(int i=0; i<a.length; i++)
		{
			a1.add(a[i]);
		}
		for(int i=0; i<a1.size(); i++)
		{
			if(i%5==0)
			{
				System.out.print(a1.get(i)+" ");
			}
		}
	}
}
