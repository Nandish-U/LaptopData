package com.arrayto.collections;

import java.util.ArrayList;

public class Avg_Odd_Index {
	public static void main(String[] args) 
	{
		int[] a = {10,25,23,32,85,78,42};
		ArrayList<Integer> odd = new ArrayList<>();
		for(int i=0; i<a.length; i++)
		{
			odd.add(a[i]);
		}
		int sum =0;
		int count =0;
		for(int i=0; i<odd.size(); i++)
		{
			if(i%2==1)
			{
				count++;
				sum+=odd.get(i);
			}
		}
		System.out.println(sum/count);
	}
}
