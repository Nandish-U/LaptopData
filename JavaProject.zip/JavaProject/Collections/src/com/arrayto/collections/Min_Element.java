package com.arrayto.collections;

import java.util.ArrayList;
import java.util.Collections;

public class Min_Element {
	public static void main(String[] args) {
		int[] a = { 10, 25, 23, 32, 85, 78, 42 };
		ArrayList<Integer> even = new ArrayList<>();
		for (int i = 0; i < a.length; i++) {
			even.add(a[i]);
		}

		System.out.println(Collections.min(even));
	}

}
