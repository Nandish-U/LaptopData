package com.arrayto.collections;

import java.util.ArrayList;

public class Second_Largest {
	public static void main(String[] args) {
		int[] a = { 10, 25, 23, 99, 32, 85, 78, 42, 105, 125 };
		ArrayList<Integer> even = new ArrayList<>();
		for (int i = 0; i < a.length; i++) {
			even.add(a[i]);
		}
		int max = even.get(0);
		int max2 = 0;
		for (int i = 0; i < even.size(); i++) {
			if (even.get(i) > max) {
				max = even.get(i);
			}
		}
		for (int i = 0; i < even.size(); i++) {
			if (even.get(i) > max2 && even.get(i) != max) {
				max2 = even.get(i);
			}
		}
		System.out.println(max2);
	}
}
