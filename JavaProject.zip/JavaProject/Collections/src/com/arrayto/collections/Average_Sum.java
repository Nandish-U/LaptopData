package com.arrayto.collections;

import java.util.ArrayList;

public class Average_Sum 
{
	public static void main(String[] args) 
	{
		int[] a = {10,25,23,32,85,78,42};
		ArrayList<Integer> sum = new ArrayList<>();
		for(int i=0; i<a.length; i++)
		{
			sum.add(a[i]);
		}
		int avgsum = 0;
		for(int i=0; i<sum.size(); i++)
		{
			avgsum = avgsum+sum.get(i);
		}
		System.out.println(avgsum/sum.size());
	}
}
