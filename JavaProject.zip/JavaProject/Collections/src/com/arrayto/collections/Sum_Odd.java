package com.arrayto.collections;

import java.util.ArrayList;

public class Sum_Odd 
{
	public static void main(String[] args) 
	{
		int[] a = {10,25,23,32,85,78,42};
		ArrayList<Integer> odd = new ArrayList<>();
		for(int i=0; i<a.length; i++)
		{
			odd.add(a[i]);
		}
		int sum = 0;
		for(int i=0; i<odd.size(); i++)
		{
			if(odd.get(i)%2!=0)
			sum = sum+odd.get(i);
		}
		System.out.println(sum);
	}
}
