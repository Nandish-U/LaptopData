package com.arrayto.collections;

import java.util.ArrayList;

public class Sum_Even 
{
	public static void main(String[] args) 
	{
		int[] a = {10,25,23,32,85,78,42};
		ArrayList<Integer> even = new ArrayList<>();
		for(int i=0; i<a.length; i++)
		{
			even.add(a[i]);
		}
		int sum = 0;
		for(int i=0; i<even.size(); i++)
		{
			sum = sum+even.get(i);
		}
	}
}
