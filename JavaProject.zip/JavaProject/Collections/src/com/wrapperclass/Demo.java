package com.wrapperclass;

public class Demo 
{
	String name;
	int price;
	Demo(String name, int price)
	{
		this.name = name;
		this.price = price;
	}
	public int hashCode()
	{
		return 100;
	}
	public boolean equals(Object o)
	{
		Demo d = (Demo )o;
		return this.price==d.price;
	}
	public static void main(String[] args) 
	{
		Demo d = new Demo("nandi", 10);
		Demo d1 = new Demo("nandi", 10);
		System.out.println(d.hashCode());
		System.out.println(d1.hashCode());
		System.out.println(d.toString());
		System.out.println(d1.toString());
		System.out.println(d==d1);
		System.out.println(d.equals(d1));
	}
}
