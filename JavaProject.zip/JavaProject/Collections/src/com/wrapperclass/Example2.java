package com.wrapperclass;

public class Example2 
{
	public static void main(String[] args) 
	{
		String s = "a236525";
//		int n = Integer.parseInt(s,2);//CTE bcz binary has only 0 & 1;
//		System.out.println(n);
		
//		int n1 = Integer.parseInt(s,10);
//		System.out.println(n1);
//		
		
//		int n2 = Integer.parseInt(s,8);
//		System.out.println(n2);
//		
		int n3 = Integer.parseInt(s,16);
		System.out.println(n3);
		Integer i = new Integer(10);
		Double b = new Double(20);
	}
}
