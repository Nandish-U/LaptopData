package com.wrapperclass;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Objects;

class Sort implements Comparator<Integer>
{

	@Override
	public int compare(Integer o1, Integer o2) {
		return o2-o1;
	}


	
}
public class Hello {
	String name;
	int price;
	Hello(String name,int price)
	{
		this.price = price;
		this.name = name;
	}
	
//	@Override
//	public String toString() {
//		return name;
//	}
//	
//
	@Override
	public int hashCode() {
//		return name.hashCode()+price;
		return 10;
	}
	
//	@Override
//	public boolean equals(Object obj) {
//		Hello h = (Hello)obj;
//	}

	public static void main(String[] args) 
	{
//		ArrayList<Integer> a = new ArrayList<>();
//		a.add(5);
//		a.add(90);
//		a.add(20);
//		a.add(50);
//		a.add(80);
//		a.add(10);
//		System.out.println(a);
//		Collections.sort(a,new Sort());
//		System.out.println(a);
		Hello h = new Hello("nandi",10);
		System.out.println(h.toString());
		Hello h1 = new Hello("nandi",10);
		System.out.println(h.toString()==h1.toString());//true
		System.out.println(h==h1);//false
		System.out.println(h1.toString());
		System.out.println(h.equals(h1));
	}
//	public static void main(String[] args) {
//		for(int i=1;i<=5;i++)
//		{
//			for(int j=1;j<=i;j++)
//			{
//				System.out.print("* ");
//			}
//			System.out.println();
//		}
//
//		System.out.println("=============1===============");
//		for(int i=1;i<=5;i++)
//		{
//			for(int j=1;j<=i;j++)
//			{
//				System.out.print(i+" ");
//			}
//			System.out.println();
//		}
//
//		System.out.println("==============2==============");
//		for(int i=1;i<=5;i++)
//		{
//			for(int j=1;j<=i;j++)
//			{
//				System.out.print(j+" ");
//			}
//			System.out.println();
//		}
//		System.out.println("==============3==============");
//		char c='A';
//
//		for(int i=1;i<=5;i++)
//		{
//			for(int j=1;j<=i;j++)
//			{
//				System.out.print(c+" ");
//			}
//			c++;
//			System.out.println();
//		}
//		System.out.println("==============4==============");
//
//	
//		for(int i=1;i<=5;i++)
//		{
//
//			for(int j=1;j<=i;j++)
//			{
//				if(i%2==1)
//					System.out.print(5+" ");
//				else
//				{
//					System.out.print(i+" ");
//					
//				}
//
//			}
//
//			System.out.println();
//		}
//		System.out.println("===============5=============");
//		char ch='A';
//		for(int i=1;i<=6;i++)
//		{
//			for(int j=1;j<=i;j++)
//			{
//				System.out.print(ch++ +" ");
//			}
//			System.out.println();
//		}
//
//		System.out.println("========6============");
//		for(int i=1;i<=5;i++)
//		{
//			for(int j=1;j<=i;j++)
//			{
//				if(j%2==0)
//				{
//					System.out.print(0+" ");
//				}
//				else
//				{
//					System.out.print(1+" ");
//				}
//			}
//			System.out.println();
//		}
//		System.out.println("============7=============");
//		int y=1;
//		for(int i=1;i<=4;i++)
//		{
//			for(int j=1;j<=i;j++)
//			{
//				System.out.print(y+++" ");
//			}
//			System.out.println();
//		}
//		System.out.println("============8=============");
//		
//		int y3=1;
//		
//		for(int i=1;i<=5;i++)
//		{
//			int g3=4;
//			for(int j=1;j<=i;j++)
//			{
//				System.out.print(y3+" ");
//				y3=y3+g3--;
//			}
//			y3=1;
//			y3+=i;
//			System.out.println();
//		}
//		System.out.println("==============9==============");
//		char ch1='A';
//		for(int i=1;i<=3;i++)
//		{
//			for(int j=1;j<=i;j++)
//			{
//				System.out.print(ch1++ +" ");
//			}
//			System.out.println();
//		}
//		System.out.println("================10================");
//		
//		for(int i=1;i<=3;i++)
//		{
//			char ch2='A';
//			for(int j=1;j<=i;j++)
//			{
//				System.out.print(ch2++ +" ");
//			}
//			System.out.println();
//		}
//		
//		System.out.println("===========11=====================");
//		char ch3='A';
//		for(int i=1;i<=3;i++)
//		{
//			
//			for(int j=1;j<=i;j++)
//			{
//				System.out.print(ch3++ +" ");
//			}
//			System.out.println();
//		}
//		System.out.println("============12=====================");
//		char c3='A';
//		int n3=4;
//		for(int i=1;i<=n3;i++)
//		{
//			for(int j=1;j<=i;j++)
//			{
//				System.out.print(c3+" ");
//				c3+=n3-j;
//			}
//			System.out.println();
//			c3=(char)(i+'A');
//		}
//		
//	}

}
