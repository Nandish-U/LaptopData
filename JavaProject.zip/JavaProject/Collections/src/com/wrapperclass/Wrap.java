package com.wrapperclass;

public class Wrap {
	int a = 10;

	public static void main(String[] args) {
		Integer[] i = new Integer[2];
		i[0] = 10;
		i[1] = 20;
		System.out.println(i);
	}

}
