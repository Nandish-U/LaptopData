package com.wrapperclass;

public class Example1 
{
	public static void main(String[] args) 
	{
		int a = 10255;
		Integer b = a;
		Integer c = 30;
		Double b2 = 10.5;
		System.out.println(a);
		Character c2 = 'a';
		System.out.println(c2.hashCode());
		
//		System.out.println(b+'a'+30);
		System.out.println(b2.toString());
		System.out.println(b2.hashCode());
//		System.out.println(c.equals(b));
//		Double d = b.doubleValue();
//		System.out.println(d);
//		Byte g = d.byteValue();
//		System.out.println(g);
//		Character c1 = (char) g.intValue();
//		System.out.println(c1);
//		String s = "1101";
//		int r = Integer.parseInt(s,2);
//		System.out.println(r);
		
	}
}
