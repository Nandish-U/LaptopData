package com.map;

import java.util.HashMap;
import java.util.Set;

class Token {
	int no;
	String date;

	public Token(int no, String date) {
		super();
		this.no = no;
		this.date = date;
	}

	@Override
	public String toString() {
		return "Token [no=" + no + ", date=" + date + "]";
	}

}

public class Hashmap {
	public static void main(String[] args) {
		HashMap map = new HashMap<>();
		map.put(new Token(10,"2-05-2023"), "Sharan");
		map.put(new Token(20,"3-05-2023"), "Sharan");
		map.put(new Token(30,"4-05-2023"), "Sharan");
		map.put(new Token(40,"5-05-2023"), "Sharan");
		map.put(new Token(50,"6-05-2023"), "Sharan");
		map.put(new Token(50,"6-05-2023"), "Sharan");
		map.put(new Token(50,"6-05-2023"), "Sharan");
		map.put(null,null);
		map.put(null,null);
		System.out.println(map);
		
		Token t = new Token(60, null);
		map.put(t, "Kiran");
		System.out.println(map);
		t.no=88;
		t.date="88/88/23";
		map.put(t, "pradeep");
		System.out.println(map);
		
		Set keys=  map.keySet();
		for (Object key : keys) {
			System.out.println(key+" "+map.get(key));
		}
	}
}
