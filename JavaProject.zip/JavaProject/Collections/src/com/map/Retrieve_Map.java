package com.map;

import java.util.HashMap;
import java.util.Set;

class Employee
{
	int id;
	String name;
	Employee(int id, String name)
	{
		this.id = id;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}
	
}
public class Retrieve_Map {
	public static void main(String[] args) 
	{
		HashMap<String, Employee> m = new HashMap<>();
		m.put("nandi", new Employee(10,"nandi"));
		m.put("jay", new Employee(15,"jay"));
		m.put("sanika", new Employee(10,"sanika"));
		System.out.println(m);
		System.out.println("===================");
		System.out.println(m.values());
		System.out.println("====================");
		System.out.println(m.keySet());
		System.out.println("====================");
		//retrieve using Lamda expression
		m.forEach((key,value)-> System.out.println(key+" "+value));
		System.out.println("====================");
		
		Set<String> s = m.keySet();
		for(String keys:s)
		{
			System.out.println(keys+" "+m.get(keys));
		}
	}

}
