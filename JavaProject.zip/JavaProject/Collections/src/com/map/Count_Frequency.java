package com.map;

import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

public class Count_Frequency {
	public static void main(String[] args) {
		HashMap map = new HashMap<>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the data");
		String str = sc.nextLine();
		int count = 1;
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			Integer c1 = (Integer) map.get(c);
			map.put(c, map.get(c) == null ? count : c1 + 1);
		}
		System.out.println(map);
		TreeMap t = new TreeMap<>(map);
		System.out.println(t);
	}
}
