package com.map;

import java.util.HashMap;

public class Example1 
{
	public static void main(String[] args) 
	{
		/*
		 * Lamda expression
		 */
		HashMap map = new HashMap<>();
		map.put(12, 123);
		map.put(13, 123);
		map.put(14, 123);
		map.put(15, 123);
		
		map.compute(12, (k,v)->(v==null)?34:(Integer)v+200);
		System.out.println(map);
		System.out.println(map);
	}
}
