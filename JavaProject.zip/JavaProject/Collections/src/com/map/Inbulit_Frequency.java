package com.map;

import java.util.HashMap;
import java.util.Scanner;

public class Inbulit_Frequency 
{
	public static void main(String[] args) 
	{
		HashMap map = new HashMap<>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the data");
		String str = sc.nextLine();
		for(int i=0; i<str.length();i++)
		{
		
			map.put(str.charAt(i), map.get(str.charAt(i))==null?map.getOrDefault(str.charAt(i), 1): (Integer)map.get(str.charAt(i))+1);
		}
		System.out.println(map);
	}
}
