package com.linkedlist;

import java.util.LinkedList;

public class Prime {
	public static void main(String[] args) {
		LinkedList<Integer> l = new LinkedList<>();

		for (int i = 1; i <= 100; i++) {
			int count = 0;
			for (int j = 2; j <= i/2; j++) {
				if (i % j == 0) {
					count++;
					break;
				}
			}
			if (count == 0 && i != 1) {
				l.add(i);
			}
		}
		System.out.print(l + " ");
		System.out.println();
		int sum =0;
		for(int i=0; i<l.size(); i++)
		{
			sum = sum+l.get(i);
		}
		System.out.println(sum);
	}
}
