package com.linkedlist;

import java.util.LinkedList;

public class Min_Odd_Max_Even {
	public static void main(String[] args) {
		LinkedList<Integer> l = new LinkedList<>();
		l.add(0);
		l.add(2);
		l.add(7);
		l.add(1);
		l.add(3);
		l.add(4);
		l.add(8);
		l.add(5);
		System.out.print(l + " ");
		System.out.println();
		int minodd = 0;
		int maxeven = 0;
		for (int i = 0; i < l.size(); i++) {
			if (l.get(i) % 2 == 1) {
				minodd = l.get(i);
				break;
			} else {
				maxeven = l.get(i);
			}
		}
		for (int i = 0; i < l.size(); i++) {
			if (l.get(i) % 2 == 0) {
				if (maxeven < l.get(i)) {
					maxeven = l.get(i);
				}
			} else {
				if (minodd > l.get(i)) {
					minodd = l.get(i);
				}
			}
		}
		System.out.println(minodd);
		System.out.println(maxeven);

	}
}
