package com.linkedlist;

import java.util.LinkedList;
import java.util.Scanner;

class Employee
{
	String name;
	double sal;
	String dept;
	public Employee(String name, double sal, String dept) {
		super();
		this.name = name;
		this.sal = sal;
		this.dept = dept;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", sal=" + sal + ", dept=" + dept + "]";
	}
}
public class Employee_Driver 
{
	public static void main(String[] args) 
	{
		LinkedList<Employee> l = new LinkedList<>();
		l.add(new Employee("ram",10000.0,"Dev"));
		l.add(new Employee("john",30000.0,"test"));
		l.add(new Employee("miller",15000.0,"Dev"));
		l.add(new Employee("smith",20000.0,"test"));
		System.out.println(l);
		double sum=0;
		int count =0;
		for(int i=0; i<l.size(); i++)
		{
			if(l.get(i).dept.equalsIgnoreCase("dev"))
			{
				count++;
				sum= sum+l.get(i).sal;
						
			}
		}
		System.out.println(sum/count);
	}
}
