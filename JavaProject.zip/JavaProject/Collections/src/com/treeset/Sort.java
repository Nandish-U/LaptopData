package com.treeset;

import java.util.Comparator;

public class Sort implements Comparator<Contact_Model> {

	@Override
	public int compare(Contact_Model o1, Contact_Model o2) {
		return o1.name.compareTo(o2.name);
	}

}
