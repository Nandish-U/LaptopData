package com.treeset;

import java.util.Comparator;
import java.util.TreeSet;
class Sort1 implements Comparator<Pen>
{

	@Override
	public int compare(Pen o1, Pen o2) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
public class Pen implements Comparable<Pen>
{
	int price;
	String color;
	public Pen(int price, String color) {
		super();
		this.price = price;
		this.color = color;
	}
	@Override
	public String toString() {
		return "Pen [price=" + price + ", color=" + color + "]";
	}
	public static void main(String[] args) 
	{
		TreeSet<Pen> t = new TreeSet<>();
		t.add(new Pen(10,"blue"));
		t.add(new Pen(10,"baue"));
		t.add(new Pen(20,"red"));
		t.add(new Pen(5,"glue"));
		t.add(new Pen(3,"blue"));
		t.add(new Pen(15,"yellow"));
		t.add(new Pen(22,"purple"));
		System.out.println(t);
	}
	@Override
	public int compareTo(Pen o) {
		return this.color.compareTo(o.color);
	}
}
