package com.treeset;

import java.util.Scanner;
import java.util.TreeSet;

public class C_Controller {
	TreeSet<Contact> t = new TreeSet<>(new SortContact());
	Scanner sc = new Scanner(System.in);

	public void add() {
		System.out.println("Enter the name");
		String name = sc.nextLine();
		if (name.length() <= 0)
			name = sc.nextLine();
		System.out.println("Enter the phno");
		long phno = sc.nextLong();
		Contact c = new Contact(name, phno);
		t.add(c);
		System.out.println("Contact details added successfully");
	}

	public void search() {
		System.out.println("Enter the name");
		String name = sc.nextLine();
		if (name.length() <= 0)
			name = sc.nextLine();
		Contact c1 = null;
		boolean flag = false;
		for (Contact c : t) {
			if (c.getName().equalsIgnoreCase(name)) {
				System.out.println("Contact details found");
				flag = true;
				System.out.println(c);
				c1 =c; 
			}
		}
		if(flag == false) {
			System.out.println("Contact details not found");
		}
	}
	public void remove(String name)
	{
		if(t.contains(name))
		{
			t.remove(name);
		}
		else
		{
			System.out.println("Contact details not found");
		}
	}
	public void display() {
		for (Contact contact : t) {
			System.out.println(contact);
		}
	}
}
