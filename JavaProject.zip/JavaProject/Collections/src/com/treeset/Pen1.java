package com.treeset;

public class Pen1 implements Comparable<Pen1>
{
	double price;
	String color;
	public Pen1(double price, String color) {
		super();
		this.price = price;
		this.color = color;
	}
	public int hashCode()
	{
		int c= 0;
		c = c+Double.valueOf(price).hashCode()+color.hashCode();
		return c;
	}
	
	@Override
	public String toString() {
		return "Pen1 [price=" + price + ", color=" + color + "]";
	}
	@Override
	public int compareTo(Pen1 o) 
	{
		if(this.hashCode()>o.hashCode())
		{
			return 1;
		}
		else if(this.hashCode()<o.hashCode())
		{
			return -1;
		}
		else
			return 0;
	}
	
}
