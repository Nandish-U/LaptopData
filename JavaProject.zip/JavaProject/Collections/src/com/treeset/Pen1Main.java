package com.treeset;

import java.util.TreeSet;

public class Pen1Main 
{
	public static void main(String[] args) 
	{
		TreeSet<Pen1> t = new TreeSet<>();
		t.add(new Pen1(10,"blue"));
		t.add(new Pen1(20,"red"));
		t.add(new Pen1(30,"green"));
		t.add(new Pen1(40,"blue"));
		t.add(new Pen1(50,"black"));
		t.add(new Pen1(30,"black"));
		System.out.println(t.size());
		System.out.println(t);
	}
}
