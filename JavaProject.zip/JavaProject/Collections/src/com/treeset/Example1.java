package com.treeset;

import java.util.TreeSet;

public class Example1 
{
	public static void main(String[] args) {
		TreeSet<Boolean> t = new TreeSet<>();
//		t.add(10);
//		t.add('a');
//		t.add("Hello");
		
		t.add(false);//how???
		t.add(true);
//		t.add(50.5);
		System.out.println(t);
	}
}
