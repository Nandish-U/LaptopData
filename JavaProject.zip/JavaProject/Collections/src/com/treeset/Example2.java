package com.treeset;

import java.util.Comparator;
import java.util.SortedSet;
import java.util.TreeSet;

class comp implements Comparator<Integer>
{
	@Override
	public int compare(Integer o1, Integer o2) {
		return o2-o1;
	}
}
public class Example2 
{
	public static void main(String[] args) 
	{
		TreeSet<Integer> t = new TreeSet<>();
		t.add(10);
		t.add(20);
		t.add(10);
		t.add(30);
		t.add(40);
		t.add(50);
		t.add(60);
		t.add(70);
		System.out.println(t);
		System.out.println(t.last());
		System.out.println(t.pollLast());
		System.out.println(t);
		SortedSet<Integer> s = t.subSet(20, 60);
		TreeSet<Integer> tt = new TreeSet<>(s);
		System.out.println(tt);
		
		
	}
}


