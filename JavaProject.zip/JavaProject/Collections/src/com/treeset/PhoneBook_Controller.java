package com.treeset;

import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class PhoneBook_Controller {
	TreeSet<Contact_Model> t = new TreeSet<>(new Sort());
	Scanner sc = new Scanner(System.in);

	public Contact_Model getContact() {
		System.out.println("Enter the name");
		String name = sc.nextLine();
		if (name.length() <= 0)
		name = sc.nextLine();
		System.out.println("Enter the mobile no");
		int mobno = sc.nextInt();
		return new Contact_Model(name, mobno);
	}

	public void addContact() {
		if (t.add(getContact())) {
			System.out.println("Contact added successfully");
		} else {
			System.out.println("Contact is already existing");
		}
	}

	public void removeContact() {
		Contact_Model con = getContact();
		if (t.contains(con)) {
			t.remove(con);
		} else {
			System.out.println("Contact not found");
		}
//		System.out.println("Enter the name");
//		String name = sc.nextLine();
//		if (name.length() <= 0)
//			name = sc.nextLine();
//		for (Contact_Model c : t) {
//			if(c.name.equalsIgnoreCase(name))
//			{
//				t.remove(name);
//			}
//		}
	}

	public void search() {
		System.out.println("Enter the name");
		String name = sc.nextLine();
		for (Contact_Model con : t) {
			if (con.name.equalsIgnoreCase(name)) {
				System.out.println("contact data found");
				System.out.println(con);
			} else {
				System.out.println("Contact details not found");
			}
		}
	}

	public void edit() {
		System.out.println("Enter the name to search");
		String name = sc.nextLine();
		if (name.length() <= 0)
			name = sc.nextLine();
		Iterator<Contact_Model> i = t.iterator();
		boolean found = false;
		Contact_Model con = null;
		while (i.hasNext()) {
			if (i.next().name.equalsIgnoreCase(name)) {
				found = true;
				i.remove();
				System.out.println("Enter the new contact details");
				con = getContact();
			}
		}
		if (found == false) {
			System.out.println("the contact data not found");

		} else {
			t.add(con);
		}
	}

	public void display() {
		for (Contact_Model con : t) {
			System.out.println(con);
		}
	}
}
