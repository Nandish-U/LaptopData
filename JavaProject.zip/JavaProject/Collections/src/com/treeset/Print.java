package com.treeset;

public class Print<T>
{
	  void print(T data)
	{
		System.out.println(data);
	}
}
