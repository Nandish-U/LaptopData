package com.treeset;

import java.util.Scanner;

public class C_View {
	public static void main(String[] args) {
		C_Controller c = new C_Controller();
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to Contact Details");
		while (true) {
			System.out.println("1: add contact");
			System.out.println("2: search contact");
			System.out.println("3: display contact");
			System.out.println("4: remove contact");
			System.out.println("5: exit");
			System.out.println("Enter the choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				c.add();
				break;
			case 2:
				c.search();
				break;
			case 3:
				c.display();
				break;

			case 4: {
				System.out.println("Enter the name");
				c.remove(sc.next());
			}
			case 5:
				return;
			}
		}
	}
}
