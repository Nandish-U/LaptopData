package com.treeset;

public class Book implements Comparable<Book>{
	private int bid;
	private double price;
	private String title;

	Book() {

	}

	Book(int bid, String title,double price ) {
		this.bid = bid;
		this.price = price;
		this.title = title;
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int hashCode() {
		int hc = 0;
		hc = hc+Integer.valueOf(bid).hashCode() + Double.valueOf(price).hashCode() + title.hashCode();
		return hc;
	}

	@Override
	public String toString() {
		return "Book [bid : " + bid + " price : " + price + ", title : " + title + "]";
	}

	public boolean equals(Object o) {
		Book b = (Book) o;
		if (this.bid != b.bid)
			return false;
		if (this.price != b.price)
			return false;
		if (!this.title.equalsIgnoreCase(b.title))
			return false;

		return true;
	}

	@Override
	public int compareTo(Book o) {
		if(this.hashCode()>o.hashCode())
			return 1;
		else if(this.hashCode()<o.hashCode())
			return -1;
		return 0;
	}
}
