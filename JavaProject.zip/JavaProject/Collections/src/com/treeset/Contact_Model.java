package com.treeset;

public class Contact_Model {
	String name;
	long phno;
	public Contact_Model(String name, long phno) {
		super();
		this.name = name;
		this.phno = phno;
	}
	@Override
	public String toString() {
		return "Contact_Model [name=" + name + ", phno=" + phno + "]";
	}
	@Override
	public int hashCode() {
		return name.hashCode();
	}
	
}
