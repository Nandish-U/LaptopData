package com.treeset;

import java.util.ArrayList;
import java.util.Scanner;

public class BookDriver 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		ArrayList<Book> lib = new ArrayList<>();
		lib.add(new Book(1,"RRR",2300));
		lib.add(new Book(2,"Harry potter",1800));
		lib.add(new Book(3,"Mission impossible",2865));
		lib.add(new Book(4,"Kgf1",1200));
		lib.add(new Book(5,"Barbie1",4500));
		lib.add(new Book(6,"RRR1",2300));
		lib.add(new Book(7,"Harry potter1",1800));
		lib.add(new Book(8,"Mission impossible1",2865));
		lib.add(new Book(9,"Kgf2",1200));
		lib.add(new Book(10,"Barbie2",4500));
		lib.add(new Book(11,"RRR2",2300));
		lib.add(new Book(12,"Harry potter2",1800));
		lib.add(new Book(13,"Mission impossible2",2865));
		lib.add(new Book(14,"Kgf3",1200));
		lib.add(new Book(15,"Barbie3",4500));
		//search the book
		System.out.println("Enter the title to search");
		String search_title = scanner.nextLine();
		boolean available = false;
		Book temp = null;
		long start = System.nanoTime();
		for(Book b :lib)
		{
			if(search_title.equalsIgnoreCase(b.getTitle()))
			{
				available = true;
				temp = b;
			}
		}
		long stop = System.nanoTime();
		if(available)
		{
			System.out.println("Book is available "+temp);
		}
		else
		{
			System.out.println("Book is not available");
		}
		// time taken to search the book
		System.out.println("Time taken is "+(stop-start)+" ns");

	}
}
