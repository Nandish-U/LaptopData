package com.treeset;

public class Contact 
{
	private String name;
	private long phno;
	public Contact(String name, long phno) {
		super();
		this.name = name;
		this.phno = phno;
	}
	@Override
	public int hashCode() {
		return name.hashCode();
	}
	@Override
	public String toString() {
		return "Contact [name=" + name + ", phno=" + phno + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhno() {
		return phno;
	}
	public void setPhno(long phno) {
		this.phno = phno;
	}	
}
