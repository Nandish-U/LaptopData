package com.treeset;

import java.util.Scanner;

public class Contact_View {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PhoneBook_Controller pb = new PhoneBook_Controller();
		System.out.println("Welcome to Phone_Book Controller");
		while (true) {
			System.out.println("1: add contact");
			System.out.println("2: remove contact");
			System.out.println("3: edit contact");
			System.out.println("4: search contact");
			System.out.println("5: display contact");
			System.out.println("6: exit");

			System.out.println("Enter the choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				pb.addContact();
				break;
			case 2:
				pb.removeContact();
				break;
			case 3:
				pb.edit();
				break;
			case 4:
				pb.search();
				break;
			case 5:
				pb.display();
				break;
			case 6:
				return;
			default:
				System.out.println("Enter a valid choice");
			}
		}
	}
}
