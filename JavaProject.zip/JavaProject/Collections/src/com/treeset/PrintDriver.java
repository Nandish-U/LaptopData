package com.treeset;

public class PrintDriver {
	public static void main(String[] args) {
		Print p = new Print<>();
		p.print("Hello");
		Print<Integer> p1 = new Print<>();
		p1.print(10);
		Print<Double> p2 = new Print<>();
		p2.print(50.0);
	}
}
