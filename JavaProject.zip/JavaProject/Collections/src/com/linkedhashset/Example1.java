package com.linkedhashset;

import java.util.LinkedHashSet;

public class Example1 {
	public static void main(String[] args) {
		LinkedHashSet l = new LinkedHashSet<>();
		l.add(1);
		l.add(2.525);
		l.add(true);
		l.add("Hello");
		l.add('a');
		l.add(true);
		l.add(7);
		l.add(null);
		l.add(null);
		System.out.println(l.add(true));
		System.out.println(l.add(false));
		System.out.println(l);
	}
}
