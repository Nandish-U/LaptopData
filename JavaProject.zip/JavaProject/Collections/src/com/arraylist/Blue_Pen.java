package com.arraylist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class Blue_Pen implements Comparable<Blue_Pen> 
{
	int price;
	String color;
	public Blue_Pen(int price, String color) {
		super();
		this.price = price;
		this.color = color;
	}
	@Override
	public String toString() {
		return "Blue_Pen [price=" + price + ", color=" + color + "]";
	}
//	@Override
//	public int compareTo(Blue_Pen o) {
//		if(this.price>o.price)
//			return 85;
//		if(this.price<o.price)
//			return -865;
//		return 0;
//		return  this.color.compareTo(o.color);
//	}
	@Override
	public int compareTo(Blue_Pen o) {
//		int res = 0;
		if(this.price>o.price)
//			res= 85;
			return 85;
		if(this.price<o.price)
//			res= -865;
			return -8;
		if(this.price==o.price)
		{
			return  this.color.compareTo(o.color);
		}
		return 0;
	}
	
	public static void main(String[] args) 
	{
		ArrayList<Blue_Pen> arr = new ArrayList<>();
		arr.add(new Blue_Pen(10,"rlue"));
		arr.add(new Blue_Pen(80,"blue"));
		arr.add(new Blue_Pen(30,"blue"));
		arr.add(new Blue_Pen(10,"ablue"));
		System.out.println("Before sorting "+arr);
		Collections.sort(arr);
		Collections.reverse(arr);
		System.out.println("After sorting"+arr);
		ArrayList<Integer> a = new ArrayList<>();
		a.add(10);
		a.add(80);
		a.add(70);
		a.add(20);
		a.add(35);
		a.add(95);
//		System.out.println(a);
		Iterator<Integer> k= a.iterator();
//		for( ;k.hasNext() ; )
//		{
//			System.out.println(k.next());
//		}
		ListIterator<Integer> l = a.listIterator();
		while(l.hasNext())
		{
			System.out.println(l.next());
		}
		while(l.hasPrevious())
		{
			System.out.println(l.previous());
		}
//		for(Integer f:a)
//		{
//			
//		}
//		Collections.reverse(a);
//		System.out.println(a);
//		Collections.sort(a);
//		System.out.println(a);
//		System.out.println(Collections.binarySearch(a, 35));
	
	}
	
	
}
