package com.arraylist;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class Pen1 {
	String color;
	double price;

	public Pen1(String color, double price) {
		super();
		this.color = color;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Pen [color=" + color + ", price=" + price + "]";
	}

	@Override
	public boolean equals(Object obj) {
		Pen1 p = (Pen1) obj;
		return this.price == p.price;
	}

	public static void main(String[] args) {
		ArrayList<Pen1> l = new ArrayList<Pen1>();
		l.add(new Pen1("red", 20.0));
		l.add(new Pen1("blue", 15.0));
		l.add(new Pen1("black", 10.0));
		l.add(new Pen1("green", 25.0));
		l.add(new Pen1("white", 40.0));
		l.add(new Pen1("yellow", 50.0));
		// for (int i = 0; i < l.size(); i++) {
		// if (l.get(i).price >= 13) {
		// l.remove(i);
		// }
		// }
//		for(Pen1 obj:l)
//		{
//			if(obj.price>=20)
//			{
//				l.remove(obj);
//			}
//		}
		// iterator
		Iterator i1 = l.iterator();
		//		while (i1.hasNext()) {
		//			if (((Pen1) i1.next()).price >= 30) {
		//				i1.remove();
		//			}
		//		}
		//		// retrieve using iterator
		while (i1.hasNext()) {
			System.out.println(i1.next());
		}
//		System.out.println("======================");
//		// retrieve using listIterator
//
//		ListIterator<Pen1> l3 = l.listIterator();
//
//		while(l3.hasNext())
//		{
//			System.out.println(l3.next());
//		}
		//		while (l3.hasPrevious()) {
		//			System.out.println(l3.previous());
		//		}
		//		System.out.println(l);
	}
}
