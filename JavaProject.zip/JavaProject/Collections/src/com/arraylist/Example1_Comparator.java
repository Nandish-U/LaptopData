package com.arraylist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class P implements Comparator<P>
{
	int price;
	String color;
	public P(String color, int price) {
		super();
		this.color = color;
		this.price = price;
	}
	P()
	{
		
	}
	@Override
	public String toString() {
		return "p [price=" + price + ", color=" + color + "]";
	}
	@Override
	public int compare(P o1, P o2) {
		return o2.price-o1.price;
	}
}
public class Example1_Comparator 
{
	public static void main(String[] args) 
	{
		ArrayList<P> arr = new ArrayList<>();
		arr.add(new P("red",10));
		arr.add(new P("blue",50));
		arr.add(new P("green",20));
		arr.add(new P("purple",45));
		System.out.println(arr);
		//Collections.sort(arr);//
		Collections.sort(arr, new P());
		System.out.println(arr);
		
		
	}
}
