package com.arraylist;

import java.util.ArrayList;

public class Example1 
{
	public static void main(String[] args) 
	{
		ArrayList l= new ArrayList<>();
		l.add(1);
		l.add(2);
		l.add("Hello");
		l.add('a');
		l.add(50.0);
		ArrayList l1 = new ArrayList<>();
		l1.add(8);
		l1.add(9);
		l1.add('s');
		System.out.println(l);
		System.out.println(l1);
		l.addAll(l1);
		System.out.println(l);
		l.remove(1);
		System.out.println(l);
		System.out.println(l.size());
		l.set(5, 100);
		System.out.println(l);
		l1.clear();
		System.out.println(l1);
		Object o = 50.0;
		l.remove(o);
		System.out.println(l);
	}
}
