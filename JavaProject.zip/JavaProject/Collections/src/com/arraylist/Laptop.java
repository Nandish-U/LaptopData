package com.arraylist;

import java.util.ArrayList;

public class Laptop 
{
	String name;
	double price;
	Laptop(String name, double price)
	{
		this.name = name;
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "Laptop [name=" + name + ", price=" + price + "]";
	}
	

	public static void main(String[] args) 
	{
		ArrayList<Laptop> arr = new ArrayList<>();
		arr.add(new Laptop("Hp",15000.0));
		arr.add(new Laptop("Dell",18000.0));
		arr.add(new Laptop("Mi",24000.0));
		arr.add(new Laptop("Lenovo",35000.0));
		arr.add(new Laptop("Asus",55000.0));
		System.out.println(arr);
	}
}
