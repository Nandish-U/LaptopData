package com.arraylist;

import java.util.ArrayList;
public class Pen 
{
	String color;
	double price;
	public Pen(String color, double price) {
		super();
		this.color = color;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Pen [color=" + color + ", price=" + price + "]";
	}
	@Override
	public boolean equals(Object obj) {
		Pen p = (Pen)obj;
		return this.color==p.color && this.price==p.price;
	}
	public static void main(String[] args) 
	{
		ArrayList l = new ArrayList<>();
		l.add(new Pen("red", 20.0));
		l.add(new Pen("blue", 15.0));
		l.add(new Pen("black", 10.0));
		l.add(new Pen("green", 25.0));
		System.out.println(l);
		//		System.out.println(l.remove(new Pen("red", 20.0)));// object will not be removed
		//		Pen p = new Pen("brown",30.0);
		//		l.add(p);
		//		System.out.println(l);
		//		System.out.println(l.remove(p));
		//		System.out.println(l);
		//		p.color="blue";
		//		p.price=15.0;
		//		System.out.println(l.remove(p));
		//		System.out.println(l.remove(new Pen("red",20.0)));
		//		System.out.println(l);
		System.out.println(l.remove(new Pen("red",20.0)));
		System.out.println(l);
		for(Object elb: l)
		{
			Pen p = (Pen)elb;
			System.out.println(p.price);
		}
		System.out.println(l.listIterator());
	}
}
