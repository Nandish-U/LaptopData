package com.arraylist;

import java.util.ArrayList;

public class Book 
{
	String  name;
	double price;
	
	public Book(String name, double price) {
		super();
		this.name = name;
		this.price = price;
	}

	public static void main(String[] args) 
	{
		Book b = new Book("java",550.0);
		Book b1 = new Book("web",450.0);
		Book b2 = new Book("sql",300.0);
		ArrayList<Book> l = new ArrayList<Book>();
		l.add(b2);
		l.add(b1);
		l.add(b);
		System.out.println(l);
		
	}
}
