package com.Hashset;

import java.util.HashSet;

class Employee
{
	String name;
	int eid;
	public Employee(String name, int eid) {
		super();
		this.name = name;
		this.eid = eid;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", eid=" + eid + "]";
	}
	@Override
	public int hashCode() {
		return eid;
	}
	public boolean equals(Object o)
	{
		Employee e = (Employee)o;
		return name.equals(e.name);
	}
}
public class EmployeeMain 
{
	public static void main(String[] args) 
	{
		HashSet<Employee> e = new HashSet<>();
		e.add(new Employee("smith",123));
		e.add(new Employee("smith",123));
		e.add(new Employee("smith",123));
		e.add(new Employee("smith",123));
		e.add(new Employee("smith",123));
		System.out.println(e);
		Employee e1 = new Employee("Allen", 456);
		Employee e2 = new Employee("Allen", 456);
		e.add(e1);
		e.add(e2);
		e1.name="king";
		e1.eid=859;
		e.add(e1);
		System.out.println(e);
	}
}
