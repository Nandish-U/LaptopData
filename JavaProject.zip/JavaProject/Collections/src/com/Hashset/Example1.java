package com.Hashset;

import java.util.ArrayList;
import java.util.HashSet;

public class Example1 
{
	public static void main(String[] args) 
	{
		HashSet h = new HashSet<>();
		h.add(10);
		h.add(10.5);
		h.add(true);
		h.add('a');
		h.add(null);
		h.add(56);
		h.add("Hello");
		System.out.println(h);
		System.out.println(h.clone());
		ArrayList a = new ArrayList<>(h);
		a.add(10);
		a.add(56);
		a.add(true);
		a.add(null);
		System.out.println(a);
		System.out.println(a.get(1));
		HashSet h1 = new HashSet<>(a);
		System.out.println(h1);
	
	}
}
