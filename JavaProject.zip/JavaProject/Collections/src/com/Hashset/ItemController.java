package com.Hashset;

import java.util.HashSet;
import java.util.Set;

public class ItemController 
{
	private Set<Item> cartItems = new HashSet<>();
	
	public Set<Item> getCartItems() {
		return cartItems;
	}
	public void addItem(Item item)
	{
		cartItems.add(item);
	}
	public void removeItem(Item item)
	{
		if(cartItems.remove(item))
		{
			System.out.println("Item "+item+" has been removed successfully");
		}
		else
		{
			System.out.println("Item not found");
		}
	}
	public void containsItem(Item item)
	{
		if(cartItems.contains(item))
		{
			System.out.println("The item is present in the stock");
		}
		else
		{
			System.out.println("Entered item is not in the stock");
		}
	}
	public void calculateTotalPrice()
	{
		double price=0;
		for(Item item:cartItems)
		{
			price+=item.getPrice();
		}
		System.out.println("The total price is "+price);
	}
	public void display()
	{
		System.out.println("The cart items are....!!");
		int i=1; 
		for(Item item:cartItems)
		{
			System.out.println(i+++" "+item);
		}
	}
}
