package com.Hashset;

import java.util.Scanner;

public class ItemView {
	static Scanner scanner = new Scanner(System.in);

	public static Item createItem() {
		System.out.println("Enter the Itemid");
		int itemid = scanner.nextInt();
		System.out.println("Enter the ItemName");
		String name = scanner.next();
		System.out.println("Enter the ItemPrice");
		double price = scanner.nextDouble();
		Item item = new Item(itemid, name, price);
		return item;
	}

	public static void main(String[] args) {
		ItemController ic = new ItemController();

		while (true) {
			System.out.println("welcome");
			System.out.println("1 : Add items");
			System.out.println("2 : Remove items");
			System.out.println("3 : Search items");
			System.out.println("4 : TotalPrice of items");
			System.out.println("5 : Display items");
			System.out.println("6 : exit");
			System.out.println("Please enter the choice");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1: {
				ic.addItem(createItem());
				System.out.println("Item added successfully");
			}
				break;
			case 2: {
				ic.removeItem(createItem());
			}
				break;
			case 3:
				ic.containsItem(createItem());
				break;
			case 4:
				ic.calculateTotalPrice();
				break;
			case 5:
				ic.display();
				break;
			case 6:
				return;
			}
		}
	}
}
