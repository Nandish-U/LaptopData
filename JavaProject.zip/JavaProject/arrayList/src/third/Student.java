package third;

import java.util.*;

public class Student {
	public static void main(String[] args) {
		ArrayList<Marks> a = new ArrayList();
		Scanner s = new Scanner(System.in);
		a: while (true) {
			System.out.println("Enter the operation to perform");
			System.out.println("1. Add Marks");
			System.out.println("2. End");
			int b = s.nextInt();
			switch (b) {
			case 1: {
				System.out.println("Enter students name");
				s.nextLine();
				String h = s.nextLine();
				System.out.println("Enter English marks");
				int i = s.nextInt();
				System.out.println("Enter Maths marks");
				int j = s.nextInt();
				System.out.println("Enter Science marks");
				int l = s.nextInt();
				a.add(new Marks(h, i, j, l));
			}
			case 2: {
				System.out.println("Thank you");
				break a;
			}
			default:
				System.out.println("Enter valid input");
			}

		}
		System.out.println(a);
		for (Marks m : a) {
			m.english=0;
		}
		System.out.println(a);
	}

}
