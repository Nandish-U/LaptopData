package third;

public class Marks {
	String name;
	double english;
	double maths;
	@Override
	public String toString() {
		return "Marks [name=" + name + ", english=" + english + ", maths=" + maths + ", science=" + science + "]";
	}
	double science;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getEnglish() {
		return english;
	}
	public void setEnglish(double english) {
		this.english = english;
	}
	public double getMaths() {
		return maths;
	}
	public void setMaths(double maths) {
		this.maths = maths;
	}
	public double getScience() {
		return science;
	}
	public void setScience(double science) {
		this.science = science;
	}
	public Marks(String name, double english, double maths, double science) {
		super();
		this.name = name;
		this.english = english;
		this.maths = maths;
		this.science = science;
	}
	
}
