package fifth;
import java.util.*;

public class Retain {
	public static void main(String[] args) {
		ArrayList a=new ArrayList();
		a.add('a');
		a.add('b');
		a.add('c');
		System.out.println(a);
		ArrayList b= new ArrayList();
		b.addAll(a);
		b.add('d');
		b.add('e');
		b.add('f');
		System.out.println(b);
	}

}
