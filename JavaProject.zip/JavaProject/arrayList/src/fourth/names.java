package fourth;
import java.util.*;

public class names {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		ArrayList<String> a=new ArrayList();
		a.add("Tom");
		a.add("Jerry");
		a.add("Oggy");
		a.add("Noddy");
		a.add("Smith");
		System.out.println(a);
		a.remove(2);
		System.out.println(a);
	}

}
