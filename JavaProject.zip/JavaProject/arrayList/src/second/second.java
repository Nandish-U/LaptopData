package second;

import java.util.ArrayList;

public class second {
	public static void main(String[] args) {
		ArrayList a=new ArrayList();
		ArrayList b= new ArrayList();
		a.add(10);
		a.add(1, b);
		a.add(20.7);
		a.add('a');
		a.add("Hey");
		a.add("!@#$");
		System.out.println(a);
	}

}
