package seven;

public class Laptop implements Comparable {
	String brand;
	int price;
	int ram;

	public Laptop(String brand, int price, int ram) {
		super();
		this.brand = brand;
		this.price = price;
		this.ram = ram;
	}

	@Override
	public String toString() {
		return "Laptop [brand=" + brand + ", price=" + price + ", ram=" + ram + "]";
	}

	@Override
	public int compareTo(Object o) {
		return this.ram - (int) o;
	}
}