package seven;
import java.util.*;
public class Driver {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		ArrayList a= new ArrayList();
		a:while(true) {
			System.out.println("Enter operation");
			System.out.println("1. Create Laptop");
			System.out.println("2. End");
			int n=s.nextInt();
			switch (n){
			case 1:{
				System.out.println("Enter Brand");
				s.nextLine();
				String b=s.nextLine();
				System.out.println("Enter Price");
				int c=s.nextInt();
				System.out.println("Enter Ram");
				int d=s.nextInt();
				a.add(new Laptop(b,c,d));
			} break;
			case 2:{
				System.out.println("Thank you");
				break a;
			}
			default:System.out.println("Invalid input");
			}
		}
		Collections.sort(a);
		System.out.println(a);
	}

}
