package six;

import java.util.ArrayList;

public class contains {
	public static void main(String[] args) {
		ArrayList a=new ArrayList();
		a.add('a');
		a.add('b');
		a.add('c');
		System.out.println(a);
		ArrayList b= new ArrayList();
		b.add('a');
		b.add('b');
		b.add('c');
		b.add('d');
		b.add('e');
		b.add('f');
		System.out.println(b);
		System.out.println(b.containsAll(a));
	}

}
