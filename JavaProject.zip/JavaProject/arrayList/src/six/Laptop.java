package six;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class Laptop implements Comparable<Laptop>
{
	int id;
	String name;
	String brand;
	static String cname="TestYantra";
	
	Laptop(int id, String name, String brand)
	{
		this.id = id;
		this.name= name;
		this.brand = brand;
	}
	
	@Override
	public String toString() {
		return "Laptop [id=" + id + ", name=" + name + ", brand=" + brand + "]";
	}

	public static void main(String[] args) 
	{
		ArrayList<Laptop> a = new ArrayList<>();
		a.add(new Laptop(101,"hp510","hp"));
		a.add(new Laptop(105,"dell456","Dell"));
		a.add(new Laptop(108,"Ryzen","hp"));
		
		System.out.println(a);
	}

	@Override
	public int compareTo(Laptop o) {
		return this.id-o.id;
	}
	
	
}

