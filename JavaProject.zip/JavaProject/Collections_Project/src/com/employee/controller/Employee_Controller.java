package com.employee.controller;

import java.util.Collections;
import java.util.Scanner;
import com.employee.customexception.InvalidChoiceException;
import com.employee.model.Company;
import com.employee.model.Employee;
import com.sorting.SortByEmpid;
import com.sorting.SortByName;

public class Employee_Controller {
	public static Scanner scanner = new Scanner(System.in);

	public void addEmployee() {
		System.out.println("Enter the empid");
		int empid = scanner.nextInt();
		System.out.println("Enter the name");
		String name = scanner.next();
		System.out.println("Enter the Last Name");
		String lastName = scanner.next();
		System.out.println("Enter the phno");
		Long phno = scanner.nextLong();
		System.out.println("Enter the email");
		String email = scanner.next();
		System.out.println("Enter the password");
		String pwd = scanner.next();
		Company.getEmployees().add(new Employee(empid, name, lastName, phno, email, pwd));
		System.out.println("Data added successfully");
	}

	public void remove() {
		System.out.println("Remove based on\n 1: Byname\n 2: Bymobno\n 3: Byempid");
		System.out.println("Enter the choice");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1: {
			System.out.println("Enter the name");
			String name = scanner.next();
			for (int i = 0; i < Company.getEmployees().size(); i++) {
				if (Company.getEmployees().get(i).getFirstName().equalsIgnoreCase(name)) {
					Company.getEmployees().remove(name);
					System.out.println("Data removed successfully");
					break;
				}
			}
		}
			break;
		case 2: {
			System.out.println("Enter the mobno");
			Long mobno = scanner.nextLong();
			for (int i = 0; i < Company.getEmployees().size(); i++) {
				if (Company.getEmployees().get(i).getPhno() == mobno) {
					Company.getEmployees().remove(i);
					System.out.println("Data removed successfully");
					break;
				}
			}
		}
			break;
		case 3: {
			System.out.println("Enter the empid");
			int empid = scanner.nextInt();
			for (int i = 0; i < Company.getEmployees().size(); i++) {
				if (Company.getEmployees().get(i).getEmpid() == empid) {
					Company.getEmployees().remove(i);
					System.out.println("Data removed successfully");
					break;
				}
			}
		}
			break;
		default:
			try {
				throw new InvalidChoiceException("Invalid Input");
			} catch (InvalidChoiceException e) {
				System.out.println(e.getMessage());
			}
		}
	}

	public void sort() {
		System.out.println("Select sort based on \n 1: ByName\n 2: ByEmpid");
		System.out.println("Enter the choice");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1: {
			Collections.sort(Company.getEmployees(), new SortByName());
			display();
		}
			break;
		case 2: {
			Collections.sort(Company.getEmployees(), new SortByEmpid());
			display();
		}
			break;
		default:
			try {
				throw new InvalidChoiceException("Invalid Input");
			} catch (InvalidChoiceException e) {
				System.out.println(e.getMessage());
			}
		}
	}

	public void edit() {
		System.out.println("Edit data based on\n 1: Name\n 2: mobno");
		System.out.println("Enter the choice");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1: {
			System.out.println("Enter the name");
			String name = scanner.nextLine();
			if (name.length() <= 0)

				scanner.nextLine();
			for (int i = 0; i < Company.getEmployees().size(); i++) {
				if (Company.getEmployees().get(i).getFirstName().equalsIgnoreCase(name)) {
					System.out.println("Enter a new name");
					String newName = scanner.nextLine();
					Company.getEmployees().get(i).setFirstName(newName);
					System.out.println("Data updated successfully");
				}
			}
		}
			break;
		case 2: {
			System.out.println("Enter the mobno");
			Long mobno = scanner.nextLong();
			for (int i = 0; i < Company.getEmployees().size(); i++) {
				if (Company.getEmployees().get(i).getPhno() == mobno) {
					System.out.println("Enter a new number");
					Long newmobno = scanner.nextLong();
					Company.getEmployees().get(i).setPhno(newmobno);
					;
					System.out.println("Data updated successfully");
				}
			}
		}
			break;
		default:
			try {
				throw new InvalidChoiceException("Invalid Input");
			} catch (InvalidChoiceException e) {
				System.out.println(e.getMessage());
			}
		}
	}

	public void display() {
		for (Employee emp : Company.getEmployees()) {
			System.out.println(emp);
		}
	}
}
