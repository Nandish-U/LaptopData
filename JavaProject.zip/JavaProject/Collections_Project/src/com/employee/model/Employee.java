package com.employee.model;

public class Employee {
	private int empid;
	private String FirstName;
	private String LastName;
	private long phno;
	private String email;
	private String pwd;
	public Employee(int empid, String firstName, String lastName, long phno, String email, String pwd) {
		this.empid = empid;
		FirstName = firstName;
		LastName = lastName;
		this.phno = phno;
		this.email = email;
		this.pwd = pwd;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public long getPhno() {
		return phno;
	}
	public void setPhno(long phno) {
		this.phno = phno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", FirstName=" + FirstName + ", LastName=" + LastName + ", phno=" + phno
				+ ", email=" + email + ", pwd=" + pwd + "]";
	}
	
	
	
}
