package com.employee.model;

import java.util.ArrayList;
import java.util.List;

public class Company {
	static private String cName="TestYantra";
	static private String address="SouthEnd";
	static private long phno=9035646554l;
	static private int pincode=560010;

	public static String getcName() {
		return cName;
	}

	public static void setcName(String cName) {
		Company.cName = cName;
	}

	public static String getAddress() {
		return address;
	}

	public static void setAddress(String address) {
		Company.address = address;
	}

	public static long getPhno() {
		return phno;
	}

	public static void setPhno(long phno) {
		Company.phno = phno;
	}

	public static int getPincode() {
		return pincode;
	}

	public static void setPincode(int pincode) {
		Company.pincode = pincode;
	}

	private static List<Employee> employees = new ArrayList<Employee>();

	public static List<Employee> getEmployees() {
		return employees;
	}

	public static void setEmployees(List<Employee> employees) {
		Company.employees = employees;
	}
	public static void CompDetails()
	{
		System.out.println(cName);
		System.out.println(address);
		System.out.println(phno);
		System.out.println(pincode);
	}
	
}
