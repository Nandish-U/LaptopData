package com.employee.view;

import com.employee.controller.Employee_Controller;
import com.employee.customexception.InvalidChoiceException;
import com.employee.customexception.InvalidinputException;
import com.employee.model.Company;

public class Employee_View {

	public static void main(String[] args) {
		Employee_Controller controller = new Employee_Controller();
		System.out.println("Welcome to TestYantra");
		while (true) {
			System.out.println("1: addEmployee");
			System.out.println("2: display");
			System.out.println("3: remove");
			System.out.println("4: sort");
			System.out.println("5: edit");
			System.out.println("6: CompanyDetails");
			System.out.println("7: exit");
			System.out.println("Enter the choice");
			int choice = controller.scanner.nextInt();
			switch (choice) {
			case 1:
				controller.addEmployee();
				break;
			case 2: controller.display();
			break;
			case 3:
				controller.remove();
			break;
			case 4: controller.sort();
			break;
			case 5: controller.edit();
			break;
			case 6: Company.CompDetails();
				break;
			case 7:
				System.out.println("ThankYou");
				System.exit(0);
			default: {
				try {
					String msg = "Enter a valid choice";
				throw new InvalidinputException(msg);
				}
				catch(InvalidinputException e)
				{
					System.out.println(e.getMessage());
				}
			}
				
			
			}
		}
	}
}
