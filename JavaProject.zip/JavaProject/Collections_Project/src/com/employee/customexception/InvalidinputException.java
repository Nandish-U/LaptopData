package com.employee.customexception;

public class InvalidinputException extends RuntimeException {
	String message;
	public InvalidinputException(String message)
	{
		this.message = message;
	}
	@Override
	public String getMessage()
	{
		return message;
		
	}
}
