package com.employee.customexception;

public class InvalidChoiceException extends RuntimeException {
	String message;

	public InvalidChoiceException(String msg) {
		super(msg);
	}

	@Override
	public String getMessage() {
		return message;

	}
}
