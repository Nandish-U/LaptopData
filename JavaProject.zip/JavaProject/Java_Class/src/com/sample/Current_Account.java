package com.sample;

public class Current_Account extends Account 
{ 
	public Current_Account(long accno, long mobno) {
		super(accno, mobno);
		// TODO Auto-generated constructor stub
	}
	double minbal=5000.0;
//	public Current_Account(String name, long accno, long mobno)
//	{
////		super(name, accno,mobno);
//	}
	@Override
	public void withdraw(double amt)
	{
		if(amt>0 && bal-amt>=minbal)
		{
		bal = bal-amt;
		System.out.println(bal);
		}
		else
		{
			System.out.println("Insufficient fund");
		}
	}
	public void deposit(double amt)
	{
		if(amt>0)
		{
		bal = bal+amt;
		}
		else
		{
			System.out.println("Invalid input");
		}
	}
}
