package com.sample;

abstract class Account
{
	
	long accno;
	long mobno;
	
	public Account(long accno, long mobno) {
		super();
		this.accno = accno;
		this.mobno = mobno;
	}
	double bal;
	abstract void deposit(double amt);
	abstract void withdraw(double amt);
}
class Saving extends Account
{

	public Saving(long accno, long mobno) {
		super(accno, mobno);
	}

	@Override
	void deposit(double amt) {
		bal = bal+amt;
		
	}

	@Override
	void withdraw(double amt) {
		bal = bal-amt;
	}
}
public class Main 
{
	public static void main(String[] args) 
	{
		Account c = new Saving(9035512542l,9035546696l);
		c.deposit(5000);
		System.out.println(c.bal);
		c.withdraw(2000);
		System.out.println(c.bal);
	}
}
