package com.sample;

public class A1 {
	public static void main(String[] args) {
		A1 a= new A1();
		System.out.println(a.toString());
	}

}
