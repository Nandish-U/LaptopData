package com.sample;

interface A
{
	void add();
}

interface B
{
	default void add()
	{
		System.out.println("ok");
	}
}
class C implements A,B
{
	@Override
	public void add() {
		System.out.println("Not ok");
	}
}
public class Driver1 
{
	public static void main(String[] args) 
	{
		B a = new C();
		a.add();
	}
}
