package com.astraction;

public interface User 
{
	void transfer();
}
class Atm implements User
{

	@Override
	public void transfer() 
	{
		System.out.println("Transfer through ATM");
	}
	
}
class Web implements User
{

	@Override
	public void transfer() 
	{
		System.out.println("Transfer through Web");
	}
	
}
