package com.astraction;

 class Service_Class 
{
	User u1;
	public User createObject(int pin)
	{
		
		if(pin==1234)
		{
			 u1 = new Atm();
			System.out.println("Atm object is created");
			return u1;
		}
		else if(pin==4567)
		{
			u1 = new Web();
			System.out.println("Web object has been created");
			return u1;
		}
		else
		{
			System.out.println("Invalid input");
		}
		return u1;
	}
}
