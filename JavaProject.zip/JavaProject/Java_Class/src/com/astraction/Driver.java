package com.astraction;

public class Driver 
{
	public static void main(String[] args) 
	{
		Service_Class s = new Service_Class();
		User r = s.createObject(1234);
		r.transfer();
		System.out.println("===============");
		User u =s.createObject(4567);
		u.transfer();
	}
}
