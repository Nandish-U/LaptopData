package com.account;

abstract class Account 
{
	String name;
	long accno;
	long mobno;
	double bal;
	public Account(String name, long accno, long mobno)
	{
		this.name = name;
		this.accno = accno;
		this.mobno = mobno;
	}
	abstract public void withdraw(double amt);
	abstract public void deposit(double amt);
}
