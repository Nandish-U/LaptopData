package com.account;

public class Saving_Account extends Account 
{
	public Saving_Account(String name, long accno, long mobno)
	{
		super(name, accno,mobno);
	}
	@Override
	public void withdraw(double amt)
	{
		if(amt>0 && amt<=bal)
		{
		bal = bal-amt;
		}
		else
		{
			System.out.println("Insufficient fund");
		}
	}
	public void deposit(double amt)
	{
		if(amt>0)
		{
		bal = bal+amt;
		}
		else
		{
			System.out.println("Invalid input");
		}
	}
}
