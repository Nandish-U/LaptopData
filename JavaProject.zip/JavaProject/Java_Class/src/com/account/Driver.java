package com.account;

public class Driver 
{
	public static void main(String[] args) 
	{
//	Account a = new Current_Account("smith", 56235894585l, 9035546968l);
//	a.withdraw(100);
//	System.out.println(a.bal);
//	a.deposit(10000.0);
//	System.out.println(a.bal);
//	a.withdraw(5100);
	}
}
