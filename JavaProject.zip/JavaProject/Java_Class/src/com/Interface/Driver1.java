package com.Interface;

interface Cement
{
	void quantity();
}
interface Acc extends Cement
{
	double cost = 550.0;
}
public class Driver1 implements Acc
{
	public void quantity()
	{
		System.out.println("Interface Cement");
	}
	public static void main(String[] args) 
	{
		Driver1 d = new Driver1();
		d.quantity();
		System.out.println(cost);
	}
}
