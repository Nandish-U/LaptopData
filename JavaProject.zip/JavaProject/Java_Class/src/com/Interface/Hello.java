package com.Interface;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

class A1
{
	@Override
	public int hashCode()
	{
		return 10;
	}
}
public class Hello 
{
	public static void main(String[] args) 
	{
//		A1 a = new A1();
//		A1 a1 = new A1();
//		System.out.println(a.hashCode());
//		System.out.println(a.hashCode());
		ArrayList<Integer> b = new ArrayList<>();
		ArrayList<Integer> b1 = new ArrayList<>();
		b.add(10);
		b.add(20);
		b.add(30);
		b.add(120);
		b1.add(40);
		b1.add(20);
		b1.add(30);
		b1.add(10);
		Arrays.asList();
		for(Integer e:b)
		{
			System.out.println(e);
		}
		System.out.println(b.retainAll(b1));
		for(Integer e:b)
		{
			System.out.println(e);
		}
		System.out.println(b.containsAll(b1));
		for(Integer e:b)
		{
			System.out.println(e);
		}
		
	}
}
