package com.Interface;

interface Main8 
{	
//	 void add();
	  static void m2()
	 {
		 System.out.println("Hello");
	 }
	  default void m1()
	  {
		  System.out.println("Good Evening");
	  }
}
public class Test2 extends Object
{
//	@Override
//	public int hashcode()
//	{
//		
//	}

	public static void main(String[] args) 
	{
		Test2 t =new Test2();
		Test2 t1 =new Test2();
		System.out.println(t);
		System.out.println(t1);
		System.out.println(t.equals(t1));
		System.out.println(t==t1);
	}
}
