package com.Interface;

 interface Main1 
{	
	 void add();
	  static void m2()
	 {
		 System.out.println("Hello");
	 }
}
// class Main5 implements Main1
// {
//	 
// }
