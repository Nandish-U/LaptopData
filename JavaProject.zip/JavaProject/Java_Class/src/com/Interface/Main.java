package com.Interface;

interface Run
{
	void m1();
	void m2();
}
interface Run1 extends Run
{
	void m3();
}
class Test1 implements Run1,Run
{
	@Override
	public void m1()
	{
		System.out.println("Hello");
	}
	public void m2()
	{
		System.out.println("Bye");
	}
	@Override
	public void m3() {
		System.out.println("Run1");
	}
}
public class Main
{
	public static void main(String[] args) 
	{
		Run1 t = new Test1();
		t.m1();
		t.m2();
		t.m3();
//		Test1 t1 = (Test1)t;
//		t1.m1();
//		t1.m2();
//		t1.m3();
		StringBuffer s = new StringBuffer("Java");
		StringBuffer b = s;
		s.append("Sql");
		
		System.out.println(b);
		System.out.println(s.equals(b));
		System.out.println(s==b);
		
	}
}
