package com.Interface;

interface Sample 
{
	
}
