package com.Interface;

class A
{
	
}
interface Test  // super interface
{
	static int a=10;
	//by default abstract method
	
	    void add();
}
 class Sample1 implements Test // is called as implementation class
{

	@Override
	public void add() {
		
	}
	
}

public class Driver 
{
	public static void main(String[] args) 
	{
		System.out.println(Test.a);
	}
}
