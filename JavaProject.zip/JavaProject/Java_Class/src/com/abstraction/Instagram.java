package com.abstraction;

abstract class Instagram 
{
	abstract void post();
}
