package com.abstraction;

public class InstagarmV1 extends Instagram {
	@Override
	public void post()
	{
		System.out.println("Posted successfully");
	}
}
