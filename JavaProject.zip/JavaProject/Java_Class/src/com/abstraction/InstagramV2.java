package com.abstraction;

public class InstagramV2 extends InstagarmV1 {
	
	@Override
	public void post()
	{
		System.out.println("From Instagarm v3");
	}
}
