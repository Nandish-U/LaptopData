package com.abstraction;


 abstract class Demo //superclass
{
	abstract public  void m1();
	
	public static void m2()
	{
		System.out.println("Hello");
	}
	public void m3()
	{
		System.out.println("Bye");
	}
}
 class Sample extends Demo //sub-class
 {
	 @Override
	 public void m1()
	 {
		 System.out.println("Good Evening");
	 }
	 public void m5()
	 {
		 System.out.println("Hi");
	 }
 }
public class Test 
{
	public static void main(String[] args) 
	{
		Demo d ;
	}
}