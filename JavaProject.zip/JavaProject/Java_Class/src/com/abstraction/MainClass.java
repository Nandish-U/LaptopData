package com.abstraction;

abstract class Chocolate
{
	abstract  void flavour();
	public static void m1()
	{
		System.out.println("Hello");
	}
	public void m2()
	{
		System.out.println("Bye");
	}
}
class DairyMilk extends Chocolate
{
	@Override
	public void flavour()
	{
		System.out.println("Oreo");
	}
}
public class MainClass 
{
	public static void main(String[] args) 
	{
		DairyMilk d = new DairyMilk();
		d.flavour();
		Chocolate c = new DairyMilk();
//		c.flavour();
//		Chocolate.m1();
//		d.m1();
		c.m1();
		c.m2();
		d.m2();
		
	}
}
