package com.abstraction;

public class Main 
{
	public static void main(String[] args) 
	{
		Instagram s = new InstagramV2();
		s.post();
	}
}
