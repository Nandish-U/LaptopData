
abstract class A
{
	abstract   void m1();
}
class B extends A
{

	@Override
	void m1() {
		// TODO Auto-generated method stub
		
	}
	
}
public class Example1 
{
	public static void main(String[] args) 
	{
		
	}
}
