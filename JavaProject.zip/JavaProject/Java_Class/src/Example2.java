
public class Example2 
{
	public static void main(String[] args) 
	{
		int age=16;
		if(age>=18)
		{
			System.out.println("Eligible for voter id");
		}
		else
		{
			System.out.println("Not Eligible");
		}
	}
}
