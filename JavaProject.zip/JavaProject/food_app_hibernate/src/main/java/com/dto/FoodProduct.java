package com.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class FoodProduct {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator = "fp12")
	@SequenceGenerator(name="fp12",initialValue = 101,allocationSize = 1)
	private int id;
	private String 	foodName;
	private String foodType;
	private String about;
	private String availability;
	private double price;
	
	@ManyToOne
	@JoinColumn(name="my_menu_id")
	private Menu menu;
}
