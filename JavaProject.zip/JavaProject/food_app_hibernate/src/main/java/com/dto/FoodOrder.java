package com.dto;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class FoodOrder {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator = "fo12")
	@SequenceGenerator(name="fo12",initialValue = 201,allocationSize = 1)
	private int id;
	private String status;
	private double totalPrice;
	private String orderCreatedTime;
	private String orderDeliveryTime;
	private String customerName;
	private long contactNumber;
	
	@ManyToOne
	@JoinColumn(name="my_user_id1")
	User user;
	@OneToMany
	List<Item> items;
}
