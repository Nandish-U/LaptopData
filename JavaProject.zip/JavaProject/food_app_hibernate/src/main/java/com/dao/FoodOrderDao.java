package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dto.FoodOrder;


public class FoodOrderDao {
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("vikas");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	public void saveFoodOrder(FoodOrder foodOrder) {
		entityTransaction.begin();
		entityManager.persist(foodOrder);
		entityTransaction.commit();
	}
	
	public void updateFoodOrder(FoodOrder foodOrder) {
		entityTransaction.begin();
		entityManager.merge(foodOrder);
		entityTransaction.commit();
	}
	
	public void deleteFoodOrder(FoodOrder foodOrder) {
		entityTransaction.begin();
		entityManager.remove(foodOrder);
		entityTransaction.commit();
	}
	
	public FoodOrder findFoodOrderById(int id) {
		return entityManager.find(FoodOrder.class, id);
	}
}
