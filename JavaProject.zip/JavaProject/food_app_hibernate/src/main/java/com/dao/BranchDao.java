package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dto.Branch;


public class BranchDao {
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("vikas");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	public void saveBranch(Branch branch) {
		entityTransaction.begin();
		entityManager.persist(branch);
		entityTransaction.commit();
	}
	
	public void updateBranch(Branch branch) {
		entityTransaction.begin();
		entityManager.merge(branch);
		entityTransaction.commit();
	}
	
	public void deleteBranch(Branch branch) {
		entityTransaction.begin();
		entityManager.remove(branch);
		entityTransaction.commit();
	}
	
	public Branch findBranchById(int id) {
		return entityManager.find(Branch.class, id);
	}
}
