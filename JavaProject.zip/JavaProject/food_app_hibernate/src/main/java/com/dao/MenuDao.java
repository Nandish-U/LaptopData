package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dto.Item;
import com.dto.Menu;

public class MenuDao {
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("vikas");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	public void saveItem(Menu menu) {
		entityTransaction.begin();
		entityManager.persist(menu);
		entityTransaction.commit();
	}
	
	public void updateItem(Menu menu) {
		entityTransaction.begin();
		entityManager.merge(menu);
		entityTransaction.commit();
	}
	
	public void deleteItem(Menu menu) {
		entityTransaction.begin();
		entityManager.remove(menu);
		entityTransaction.commit();
	}
	
	public Item findItemById(int id) {
		return entityManager.find(Item.class, id);
	}
	
}
