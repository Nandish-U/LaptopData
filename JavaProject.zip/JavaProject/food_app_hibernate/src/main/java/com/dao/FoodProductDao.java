package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dto.FoodProduct;


public class FoodProductDao {
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("vikas");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	public void saveFoodProduct(FoodProduct foodProduct) {
		entityTransaction.begin();
		entityManager.persist(foodProduct);
		entityTransaction.commit();
	}
	
	public void updateFoodProduct(FoodProduct foodProduct) {
		entityTransaction.begin();
		entityManager.merge(foodProduct);
		entityTransaction.commit();
	}
	
	public void deleteFoodProduct(FoodProduct foodProduct) {
		entityTransaction.begin();
		entityManager.remove(foodProduct);
		entityTransaction.commit();
	}
	
	public FoodProduct findFoodProductById(int id) {
		return entityManager.find(FoodProduct.class, id);
	}
}
