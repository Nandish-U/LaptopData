package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dto.Item;

public class ItemDao {
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("vikas");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	public void saveItem(Item item) {
		entityTransaction.begin();
		entityManager.persist(item);
		entityTransaction.commit();
	}
	
	public void updateItem(Item item) {
		entityTransaction.begin();
		entityManager.merge(item);
		entityTransaction.commit();
	}
	
	public void deleteItem(Item item) {
		entityTransaction.begin();
		entityManager.remove(item);
		entityTransaction.commit();
	}
	
	public Item findItemById(int id) {
		return entityManager.find(Item.class, id);
	}
}
