package com.Driver;

import java.util.Scanner;

import com.dao.MenuDao;
import com.dao.UserDao;
import com.dto.Menu;
import com.dto.User;
import com.dto.User1;

public class Driver 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		User1 user = new User1();
		user.setEmail("Hello");
		user.setName("ok");
		user.setPassword("ok");
		user.setRole("manager");
		
		UserDao dao = new UserDao();
		dao.saveUser(user);
//		Menu menu = new Menu();
//		MenuDao dao = new MenuDao();
//		dao.saveItem(menu);
	}
}
