package com.test;

import java.io.Serializable;

public class Food implements Serializable {
	private String fname;
	private double price;
	
	Food(String fname, double price)
	{
		this.fname = fname;
		this.price = price;
	}
	@Override
	public String toString() {
		return "fname=" + fname + " price : " + price +"\n";
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
}
