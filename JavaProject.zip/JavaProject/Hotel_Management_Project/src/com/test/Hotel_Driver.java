package com.test;

import java.util.Scanner;

public class Hotel_Driver {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Hotel_Controller1 h = new Hotel_Controller1();
		while(true) {
			System.out.println("Welcome to hotel Management");
			System.out.println(" 1: SignUp\n 2: Login\n 3: GetTransactionDetails\n 4:Exit");
			System.out.println("Enter the choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1: {
				h.signup();
			}
			break;
			case 2:{
				h.login();
			}
			break;
			case 3:
			{
				h.getTransaction();
			}
			case 4:{
				System.exit(0);
			}
			}
		}
	}
}

