package com.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import com.model.Customer;
import com.model.Dish;
import com.model.Hotel_Management;

public class Hotel_Controller1 implements Hotel_Management {
	Scanner sc = new Scanner(System.in);
	String path = "E:/Food/";
	String path1 = "E:/Food_Transaction/";
	File file;
	File file1;
	String url;
	String name;

	public void path(String name) {
		url = path + name + ".txt";
		file = new File(url);
	}

	@Override
	public void signup() {

		System.out.println("Welcome to SignUp");
		System.out.println("Enter the Username");
		String name1 = sc.next();
		path(name1);
		name = name1;
		System.out.println("Enter the password");
		String password = sc.next();
		System.out.println("Enter the email");
		String email = sc.next();
		System.out.println("Enter the phone number");
		long phno = sc.nextLong();
		Customer c = new Customer(name1, password, email, phno);
		try {
			FileOutputStream d = new FileOutputStream(file);
			ObjectOutputStream o = new ObjectOutputStream(d);
			o.writeObject(c);
			o.flush();
			System.out.println("Serialization has been done");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void login() {
		System.out.println("Welcome to Login");
		System.out.println("enter the name");
		String name = sc.next();
		path(name);
		System.out.println("Enter the password");
		String password = sc.next();
		FileInputStream h;
		try {
			h = new FileInputStream(file);
			ObjectInputStream o = new ObjectInputStream(h);
			while (true) {
				try {
					Object c = o.readObject();
					Customer customer = (Customer) c;
					if (customer.getName().equalsIgnoreCase(name)
							&& customer.getPassword().equalsIgnoreCase(password)) {
						System.out.println("Logged in successfull");
						addFood();
						restaurant();
					} else {
						System.out.println("Invalid username or password");
					}
				} catch (Exception e) {
					break;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	Map<Food, String> map = new LinkedHashMap<>();
	public void addFood()
	{
		map.put(new Food("Chicken",450.5), "Kfc");
		map.put(new Food("wings",250.0), "Kfc");
		map.put(new Food("chicken65",600.50), "Kfc");
	}
	@Override
	public void restaurant() {
		Set<Food> key = map.keySet();
		for (Food food : key) {
			System.out.println(food);
		}
		System.out.println("Please enter the food name ");
		String name = sc.next();
		System.out.println("Please select the number of food");
		int qty = sc.nextInt();
		System.out.println("Please confirm the order");
		System.out.println("Ordered food "+name+" Number of food :"+qty);
		System.out.println("Do you want to proceed");
		System.out.println("Please type y/n");
		String msg = sc.next();
		if(msg.equalsIgnoreCase("y"))
		{
			getBill(name,qty);
		}
		else
		{
			System.out.println("Thankyou");
			System.exit(0);
		}
	}
	public void getBill(String name, int qty)
	{
		String url = path1+this.name+".txt";
		file1 = new File(url);
		double price = 0;
		Set<Food> s = map.keySet();
		for (Food food : s) {
			if(food.getFname().equalsIgnoreCase(name))
			{
				price = food.getPrice()*qty;
				try {
					FileWriter d1 = new FileWriter(file1,true);
//					 ObjectOutputStream o = new ObjectOutputStream(d1);
					d1.append(food.getFname() + "" + price + " " + qty+"\n");
					d1.flush();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println("Ordered Food "+name+ "\n "+"Total price : "+price);
		System.out.println("Wait for your order");
		System.out.println("Thankyou");
		System.out.println("===============================");
		System.out.println("Do you want transaction details");
		System.out.println("Please type y/n");
		String s1 = sc.next();
		if(s1.equalsIgnoreCase("y"))
		{
			getTransaction();
		}
		else
		{
			System.out.println("Thankyou");
			System.exit(0);
		}
		
	}
	public void getTransaction()
	{
		System.out.println("Enter the name");
		String name1 = sc.next();
//		path(name);
//		System.out.println("Enter the passworc");
//		String pwd = sc.next();
		try {
			FileInputStream f1 = new FileInputStream(file1);
			ObjectInputStream o = new ObjectInputStream(f1);
			for(;;) {
				try {
					Object a = o.readObject();
					Food f = (Food)a;
				}
				catch(Exception e )
				{
					break;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

