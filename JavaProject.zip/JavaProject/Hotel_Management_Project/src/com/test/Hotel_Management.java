package com.test;

public interface Hotel_Management {
	void signup();
	void login();
	void restaurant();
	
}
