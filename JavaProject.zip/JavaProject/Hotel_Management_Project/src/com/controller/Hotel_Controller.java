package com.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import com.model.Customer;
import com.model.Dish;
import com.model.Hotel_Management;

public class Hotel_Controller implements Hotel_Management {
	Scanner sc = new Scanner(System.in);
	String path = "E:/Food_Management/";
	File file;
	String url;
	String name;

	public void path() {
		System.out.println("Enter the Username");
		name = sc.next();
		url = path + name + ".txt";
		file = new File(url);
	}

	@Override
	public void signup() {

		System.out.println("Welcome to SignUp");
		path();
		String name1 = name;
		System.out.println("Enter the password");
		String password = sc.next();
		System.out.println("Enter the email");
		String email = sc.next();
		System.out.println("Enter the phone number");
		long phno = sc.nextLong();
		Customer c = new Customer(name1, password, email, phno);
		try {
			FileOutputStream d = new FileOutputStream(file);
			ObjectOutputStream o = new ObjectOutputStream(d);
			o.writeObject(c);
			o.flush();
			System.out.println("Serialization has been done");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void login() {
		System.out.println("Welcome to Login");
		path();
		String username = name;
		System.out.println("Enter the password");
		String password = sc.next();
		FileInputStream h;
		try {
			h = new FileInputStream(file);
			ObjectInputStream o = new ObjectInputStream(h);
			while (true) {
				try {
					Object c = o.readObject();
					Customer customer = (Customer) c;
					if (customer.getName().equalsIgnoreCase(username)
							&& customer.getPassword().equalsIgnoreCase(password)) {
						System.out.println("Logged in successfull");
						restaurant();
					} else {
						System.out.println("Invalid username or password");
					}
				} catch (Exception e) {
					break;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	ArrayList<String> a = new ArrayList<>();

	@Override
	public void restaurant() {
		System.out.println("Welcome to Restaurant Data");
		a.add("1: KFC");
		a.add("2: Empire");
		a.add("3: Truffles");
		a.add("4: PolarBear");
		a.add("5: South-indies");
		a.add("6: A2b");

		for (String string : a) {
			System.out.println(string);
		}
		System.out.println("Please select the restaurant");

		int choice = sc.nextInt();

		dish(choice);
	}

	Map<Dish, String> kfc = new LinkedHashMap<>();

	public void dish(int choice) {
		// int qty=0;
		// String res=null;
		String food = null;

		switch (choice) {
		case 1: {
			int i = 1;
			kfc.put(new Dish("fries", 150.0), "kfc");
			kfc.put(new Dish("Chicken", 350.0), "kfc");
			kfc.put(new Dish("Lollypop", 280.0), "kfc");
			kfc.put(new Dish("Wings", 170.0), "kfc");
			Set<Dish> s = kfc.keySet();
			for (Dish k : s) {
				System.out.println(i++ + " " + k.getFoodname() + " \n" + "price :" + k.getPrice());
			}
			System.out.println("Please select your food");
			food = sc.next();
			System.out.println("Please select the quantity");
			double qty = sc.nextInt();
			System.out.println("Do you want to order more");
			System.out.println("Please type : y/n");
			String res = sc.next();
			if (res.equalsIgnoreCase("n")) {
				for (Dish k : s) {
					if (food.equalsIgnoreCase(k.getFoodname())) {
						System.out.println("Ordered food " + k);
						generateBill(food, qty);
					}
				}
			}
		}
		}
	}

	public void generateBill(String food, double qty) {
		double cost = 0;
		Set<Dish> s = kfc.keySet();
		System.out.println("Please confirm the order");
		for (Dish d : s) {
			if (food.equalsIgnoreCase(d.getFoodname())) {
				System.out.println("ordered food is ->" + d.getFoodname());
			}
		}
		System.out.println(" 1: Proceed\n 2: Cancel");
		int choice = sc.nextInt();
		switch (choice) {
		case 1: {
			for (Dish d : s) {
				if (food.equalsIgnoreCase(d.getFoodname())) {
					System.out.println("Ordered placed...!");
					cost = d.getPrice() * qty;
					System.out.println("Totak cost is " + cost);
					System.out.println("Thankyou for ordering.....!!");
//					try {
//						FileWriter d1 = new FileWriter(file);
//						// ObjectOutputStream o = new ObjectOutputStream(d1);
//						d1.append(d.getFoodname() + "" + cost + " " + qty);
//						d1.flush();
//					} catch (IOException e) {
//						e.printStackTrace();
//					}
				}
			}
			System.out.println("==========================");
		}
		break;
		case 2: {

		}
		}
	}

//	public void getTransactionHistory() {
//
//		FileReader fr=null;
//		String s="";
//		try {
//
//			fr=new FileReader(path+name+".txt");
//			try {
//				int ch=fr.read();
//
//				while(ch!=-1) {
//					s=s+(char)ch;
//					ch=fr.read();
//					System.out.print((char)ch);
//				}
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//			System.out.println();
//		}
//		catch(Exception e )
//		{
//			e.printStackTrace();
//		}
//	}
}
	/*
	 * // public void addDish() { // kfc.put("kfc", new Dish("fries", 150.0)); //
	 * Set<String> set=kfc.keySet(); // for (String string : set) { //
	 * System.out.println(kfc.get(string)); // } //
	 * System.out.println("Enter the restaurant name"); // String name = sc.next();
	 * // System.out.println("Enter the food name"); // String foodname = sc.next();
	 * // System.out.println("Enter the price"); // double price = sc.nextDouble();
	 * 
	 * 
	 * // }
	 */
