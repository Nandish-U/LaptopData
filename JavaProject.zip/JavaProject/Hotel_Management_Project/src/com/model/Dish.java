package com.model;

public class Dish
{
	private String foodname;
	private double price;
	public Dish(String foodname, double price) {
		super();
		this.foodname = foodname;
		this.price = price;
	}
	public Dish()
	{
		
	}
	public String getFoodname() {
		return foodname;
	}
	public void setFoodname(String foodname) {
		this.foodname = foodname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return  foodname + "-> price=" + price ;
	}
	
	
}
