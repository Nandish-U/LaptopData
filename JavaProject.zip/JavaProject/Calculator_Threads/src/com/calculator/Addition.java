package com.calculator;

import java.util.Scanner;

public class Addition extends Thread {
	Scanner sc = new Scanner(System.in);
	
	public synchronized int add()
	{
		System.out.println("Enter the 1st number");
		int a = sc.nextInt();
		System.out.println("Enter the 2nd number");
		int b = sc.nextInt();
		
		return a+b;
	}
	@Override
	public void run()
	{
		System.out.println(add());
		
	}
}
