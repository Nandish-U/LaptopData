package com.calculator;

import java.util.Scanner;

public class Driver{
	public synchronized void display()
	{
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Welcome to calculator");
			System.out.println(" 1: Addition\n 2: Subtraction\n 3: Multiplication\n 4: Division\n 5: Exit");
			System.out.println("Enter the choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1: {
				Addition a = new Addition();
				a.start();
//				try {
//					a.sleep(2000);
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//				}
			}
			break;
			case 2: {
				Subtraction s = new Subtraction();
				s.start();
//				try {
//					s.sleep(3000);
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//				}
			}
			break;
			case 3: {
				Multiplication s = new Multiplication();
				s.start();
//				try {
//					s.sleep(4000);
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//				}
			}
			break;
			case 4: {
				Division s = new Division();
				s.start();
//				try {
//					s.sleep(5000);
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//				}
			}
			break;
			case 5: {
				System.out.println("ThankYou..!!");
				System.exit(0);
			}
			default: System.out.println("Enter a valid choice");
			}
		}
	}
	public static void main(String[] args) {
		Driver d = new Driver();
		d.display();
		
	}
	
}
