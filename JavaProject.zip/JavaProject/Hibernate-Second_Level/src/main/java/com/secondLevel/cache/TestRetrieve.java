package com.secondLevel.cache;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

public class TestRetrieve 
{
	public static void main(String[] args) {
		EntityManager em = Persistence.createEntityManagerFactory("vikas").createEntityManager();
		Student stu = em.find(Student.class, 1);
		System.out.println(stu.getId());
		System.out.println(stu.getName());
		System.out.println(stu.getEmail());
		System.out.println(stu.getHeight());
		
		System.out.println("-----------------------");
		EntityManager em1 = Persistence.createEntityManagerFactory("vikas").createEntityManager();
		Student stu1 = em.find(Student.class, 1);
		System.out.println(stu1.getId());
		System.out.println(stu1.getName());
		System.out.println(stu1.getEmail());
		System.out.println(stu1.getHeight());
	}
}
