package com.secondLevel.cache;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestInsertStudent
{
	public static void main(String[] args) 
	{
		EntityManager em = Persistence.createEntityManagerFactory("vikas").createEntityManager();
		EntityTransaction et = em.getTransaction();
		Scanner sc = new Scanner(System.in);
		Student s = new Student();
		s.setEmail(sc.next());
		s.setHeight(sc.nextDouble());
		s.setName(sc.next());
		
		et.begin();
		em.persist(s);
		et.commit();
	}
}
