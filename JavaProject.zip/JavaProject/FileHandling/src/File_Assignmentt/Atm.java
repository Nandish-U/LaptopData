package File_Assignmentt;

interface Atm {
  void deposite(double money);
  void withdraw(double amount);
  void checkbalance();
  void viewTrasaction();
}
