package File_Assignmentt;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReader1 {
public static void main(String[] args) {
	File f= new File("Hello123");
	FileWriter fw=null;
	try {
		fw =new FileWriter(f);
		fw.write("wow");
		fw.flush();
		System.out.println("data entered successfully");
	} catch (IOException e) {
		e.printStackTrace();
	}
	
	FileReader fr=null;
	try {
		fr=new FileReader(f);
		try {
			int ch=fr.read();
			String s1="";
			String s="";
			while(ch!=-1) {
				s1=s1+((char)ch);
				s=(char)ch+s;
	          ch= fr.read();
			}
			if(s.equalsIgnoreCase(s1)) {
				System.out.println("palindrome");
			}else {
				System.out.println("not a palindrome");
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	} catch (FileNotFoundException e) {
		
		e.printStackTrace();
	}
	
}
}
