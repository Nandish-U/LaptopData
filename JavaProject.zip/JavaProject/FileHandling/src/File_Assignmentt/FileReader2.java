package File_Assignmentt;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileReader2 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter data to be inserted in frst file");
	String str1=sc.nextLine();
	System.out.println("enter data to be entered to sec file");
	String str2=sc.nextLine();
	File f= new File("vig123");
	File f2= new File("sam345");
	FileWriter fw=null;
	try {
		fw=new FileWriter(f);
		fw.write(str1);
		fw.flush();
	} catch (IOException e) {
		e.printStackTrace();
	}
	try {
		fw=new FileWriter(f2);
		fw.write(str2);
		fw.flush();
	} catch (IOException e) {
		e.printStackTrace();
	}
	FileReader fr=null;
	String s="";
	try {
		
		fr=new FileReader(f);
		try {
			int ch=fr.read();
			
			while(ch!=-1) {
				s=s+(char)ch;
				ch=fr.read();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	}
	String s1="";
	try {
		
		fr = new FileReader(f2);
		try {
			int ch1=fr.read();

			while(ch1!=-1) {
				s1=s1+(char)ch1;
				ch1=fr.read();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	}
	
	if(s.equalsIgnoreCase(s1)) {
		System.out.println("data present is same");
	}else {
		System.out.println("data present is not same");
	}
}
}
