package File_Assignmentt;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class File_Append {
	public static void main(String[] args) {
		File f = new File("min123");
		FileWriter fw = null;
		try {
			fw = new FileWriter(f);
			fw.write("hello");
			//fw.flush();
			fw.write("good morning");
			fw.flush();
			System.out.println("data appended succesfull");
		} catch (IOException e) {

			e.printStackTrace();
		}
		FileReader fr = null;
		try {
			fr = new FileReader(f);
			try {
				int ch=fr.read();
				while(ch!=-1) {
				try {
					Thread.sleep(2000);
					System.out.println((char)ch);
					ch=fr.read();
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}}
				
			} catch (IOException e) {

				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}

	}
}
