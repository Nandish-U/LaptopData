package File_Assignmentt;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;


public  class Atm_Implemts implements Atm{
	File f= new File("atm123");
	FileWriter fw=null;
	FileReader fr=null;
	  double balance=0;
	public void deposite(double money) {
		balance=balance+money;
		System.out.println("deposited:"+money);
		try {
			fw=new FileWriter(f);
			fw.write("deposited amount:"+money+"\n");
			long mil=f.lastModified();
			Date d=new Date(mil);
			System.out.println(d);
			//System.out.println(mil);
			fw.flush();
			System.out.println("data entered successfully");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void withdraw(double amount) {
		if(balance>=amount) {
		balance=balance-amount;
		System.out.println("withdraw successfull");
		}
		else {
			System.out.println("insufficeint balance");
		}
		try {
			fw=new FileWriter(f,true);
			fw.write("withdraw amount:"+amount+"\n");
			fw.flush();
			System.out.println("data entered succesfull");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void checkbalance() {
		System.out.println("balance :"+balance);
		try {
			
			fw=new FileWriter(f,true);
			fw.write("balance:"+balance+"\n");
			fw.flush();
		} catch (IOException e) {
		
			e.printStackTrace();
		}
	}
	public void viewTrasaction() {
		try {
			fr=new FileReader(f);
			try {
				int ch=fr.read();
				
				while(ch!=-1) {
					System.out.print((char)ch);
					ch=fr.read();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		System.out.println("==========");
	}

	

	

	

}
