package File_Assignmentt;

import java.util.Scanner;

public class DriverAtm {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Atm_Implemts atm = new Atm_Implemts();
		while (true) {
			System.out.println("1.deposite");
			System.out.println("2.withdraw");
			System.out.println("3.checkbalance");
			System.out.println("4.view transaction");
			System.out.println("enter your choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("enter money to be deposited");
				double money = sc.nextDouble();
				atm.deposite(money);
				break;
			case 2:
				System.out.println("enter money to be deposited");
				double amount = sc.nextDouble();
				atm.withdraw(amount);
				break;
			case 3:
				atm.checkbalance();
				break;
			case 4:
				atm.viewTrasaction();
				break;
			default:
				System.out.println("thank you");
				return;
			}

		}
	}

}
