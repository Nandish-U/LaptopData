package com.file.writer;

import java.io.FileWriter;
import java.io.IOException;

public class WriteData 
{
	public static void main(String[] args) 
	{
		FileWriter fw = null;
		
		try {
			fw = new FileWriter("d:/Panda.txt");
			fw.write("Hello good morning");
			System.out.println("Data updated");
			fw.flush();
			fw.append(" working");
			System.out.println("data append successful");
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally
		{
			try {
				fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
}
