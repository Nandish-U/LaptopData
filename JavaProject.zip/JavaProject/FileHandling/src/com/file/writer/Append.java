package com.file.writer;

import java.io.FileWriter;
import java.io.IOException;

public class Append {
	public static void main(String[] args) 
	{
		FileWriter fw = null;
		String path = "d:/new1/Nandish.txt";
		try {
			fw = new FileWriter(path);
			fw.write("Hello good morning");
			fw.flush();
			System.out.println("Data added successfully");
			fw = new FileWriter(path, false);
			fw.write("Adding data to existing file");
			System.out.println("data appended successfully");
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally
		{
			try {
				fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
