package com.file.creation;

import java.io.File;
import java.io.IOException;

public class RenameFile {
public static void main(String[] args) 
{
	File f = new File("d:/new1/Hiiiii.txt");
	try {
		System.out.println(f.createNewFile());
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	File f1 = new File("d:/new1/Kee.txt");
	boolean res = f.renameTo(f1);
	System.out.println(res);
	
}
}
