package com.file.creation;

import java.io.File;
import java.io.IOException;

public class CreateFile {
	public static void main(String[] args) 
	{
		File f = new File("d:/whatsapp.txt");
		try {
			System.out.println(f.createNewFile());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
