package com.practice;

import java.io.File;
import java.io.IOException;

public class Folder 
{
	public static void main(String[] args) 
	{
		File f = new File("e:/hi.txt");
		try {
			boolean res = f.createNewFile();
			System.out.println(res);
		} catch (IOException e) {
			e.printStackTrace();
		}
		File f1 = new File("e:/Do.txt");
		boolean res = f.renameTo(f1);
		System.out.println(res);
	}
}
