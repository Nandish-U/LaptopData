package com.practice;

import java.io.File;

public class Demo 
{
	public static void main(String[] args) 
	{
//		File f = new File("text");
//		boolean res = f.mkdir();
//		System.out.println(res);
		File f1 = new File("e:File");
		System.out.println(f1.mkdir());
		
		System.out.println(f1.exists());
		if(f1.exists())
		{
			boolean res = f1.delete();
			System.out.println(res);
		}
		System.out.println(f1.exists());
	}
}
