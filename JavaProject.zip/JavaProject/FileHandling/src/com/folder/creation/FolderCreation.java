package com.folder.creation;

import java.io.File;

public class FolderCreation {
	public static void main(String[] args) 
	{
		//create a folder in current project
		File f = new File("Hello");
		System.out.println(f.mkdir());
		
		// create a folder in specific drive/place
		File f1 = new File("d:/desktop/Hello565");
		System.out.println(f1.mkdir());
		
		//how to check wheather the folder is present or not
		
		System.out.println(f.exists());
		System.out.println(f1.exists());
	}
}
