package com.serialization;

import java.io.Serializable;

public class Car implements Serializable {
	String brand;
	Car(String brand)
	{
		this.brand = brand;
	}
}
