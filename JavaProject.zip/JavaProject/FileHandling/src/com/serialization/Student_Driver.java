package com.serialization;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Student_Driver {
	public static void main(String[] args) {
		File f = new File("d:/Student.ser");

		try {
			FileOutputStream y = new FileOutputStream(f);
			ObjectOutputStream z = new ObjectOutputStream(y);
			Student s = new Student(101, "Nandi");
			Student s1 = new Student(102, "jay");
			z.writeObject(s);
			z.writeObject(s1);
			z.flush();
			System.out.println("Serialized successfully");
		} catch (IOException e) {
			e.printStackTrace();
		}

		// De-serialization

		try {
			FileInputStream f1 = new FileInputStream(f);
			ObjectInputStream o = new ObjectInputStream(f1);
			for(;;) {
				try {
				Object o1 = o.readObject();
				Student s = (Student) o1;
				System.out.println("id : " + s.id + " name : " + s.name);
				}
				catch(Exception e )
				{
					break;
				}
			}
//			System.out.println("De-serialization is successfull");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
