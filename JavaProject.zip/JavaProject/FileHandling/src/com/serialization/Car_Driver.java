package com.serialization;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Car_Driver {
	public static void main(String[] args) {
		File f = new File("d:/Car.txt");

		try {
			FileOutputStream z = new FileOutputStream(f);
			ObjectOutputStream o = new ObjectOutputStream(z);
			Car c = new Car("MiniCooper");
			Car c1 = new Car("Lamborgini");
			o.writeObject(c);
			o.writeObject(c1);
			o.flush();
			System.out.println("Object serialized succesfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
		// De-serialization

		try {
			FileInputStream f1 = new FileInputStream(f);
			ObjectInputStream o = new ObjectInputStream(f1);
			while (true) {
				try {
					Object o1 = o.readObject();
					Car s = (Car) o1;
					System.out.println("Brand : " + s.brand);
				} catch (Exception e1) {
					break;
				}
			}
//					System.out.println("De-serialization is successfull");
		} catch (IOException  e) {
			e.printStackTrace();
		}
	}
}
