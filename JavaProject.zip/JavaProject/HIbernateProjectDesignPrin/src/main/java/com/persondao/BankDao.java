package com.persondao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.model.Bank;

public class BankDao {
	private EntityManager em = Persistence.createEntityManagerFactory("vikas").createEntityManager();

	public void saveData(Bank bank) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(bank);
		et.commit();
	}

	public void updateData(Bank bank) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.merge(bank);
		et.commit();
	}

	public void deleteData(Bank bank) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.remove(bank);
		et.commit();
	}

	public Bank findBank(int id) {
		return em.find(Bank.class, id);
	}
}
