package com.persondao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import com.model.Account;
import com.model.Bank;

public class AccountDao {

	private EntityManager em = Persistence.createEntityManagerFactory("vikas").createEntityManager();

	public void saveAccountData(Account account) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(account);
		et.commit();
	}

	public void updateAccountData(Account account) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.merge(account);
		et.commit();
	}
	public Account findBank(int id)
	{
		return em.find(Account.class, id);
	}
}
