package com.service;

import com.model.Account;
import com.model.Bank;
import com.persondao.AccountDao;
import com.persondao.BankDao;

public class BankService {
	private BankDao bankDao = new BankDao();
	private AccountDao accountDao = new AccountDao();

	public void saveData(Bank bank) {
		if (bank.getAccounts() != null) {
			accountDao.saveAccountData(bank.getAccounts());
			bankDao.saveData(bank);
		} else if (bank.getAccounts() == null) {
			bankDao.saveData(bank);
		}
	}

	public void CreateAccount(Bank bank) {
		if (bank.getAccounts() != null) {
			accountDao.saveAccountData(bank.getAccounts());
			bankDao.updateData(bank);
		}
	}

	public void updateBank(Bank bank) {
		bankDao.updateData(bank);
	}

	public void updateAccount(Account account) {

		accountDao.updateAccountData(account);
	}

	public void deleteData(Bank bank) {
		bankDao.deleteData(bank);
	}

	public Bank findBank(int id) {
		return bankDao.findBank(id);
	}

	public Account findAccount(int id) {
		return accountDao.findBank(id);
	}
}
