package com.view;

import java.util.Scanner;

import com.model.Account;
import com.model.Bank;
import com.service.BankService;

public class Driver {
	private static BankService bankService = new BankService();

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("welcome");
			System.out.println(" 1: SaveData\n 2: UpdateData\n 3: DeleteData\n 4: DisplayById");
			System.out.println("Enter the choice");
			int choice = sc.nextInt();
			Bank bank = new Bank();
			switch (choice) {
			case 1: {
				System.out.println(" 1: saveBankAndAccount\n 2: saveOnlyBank\n 3: AddAccountToBank");
				System.out.println("Enter the choice");
				int choice1 = sc.nextInt();
				switch (choice1) {
				case 1: {
					System.out.println("Enter the bank id");
					bank.setB_id(sc.nextInt());
					System.out.println("Enter the Bank name");
					bank.setB_name(sc.next());
					System.out.println("Enter the bank branch");
					bank.setBranch(sc.next());

					Account account = new Account();
					System.out.println("Enter the account id");
					account.setA_id(sc.nextInt());
					System.out.println("Enter the accno ");
					account.setAccno(sc.nextLong());
					System.out.println("Enter the balance");
					account.setBalance(sc.nextDouble());

					bank.setAccounts(account);
					bankService.saveData(bank);
				}
					break;
				case 2: {
					System.out.println("Enter the bank id");
					bank.setB_id(sc.nextInt());
					System.out.println("Enter the Bank name");
					bank.setB_name(sc.next());
					System.out.println("Enter the bank branch");
					bank.setBranch(sc.next());
					bankService.saveData(bank);
				}
					break;
				case 3: {
					System.out.println("Enter the bank id");
					int b_id = sc.nextInt();
					Bank bank1 = bankService.findBank(b_id);
					Account account = new Account();
					System.out.println("Enter the account id");
					account.setA_id(sc.nextInt());
					System.out.println("Enter the accno ");
					account.setAccno(sc.nextLong());
					System.out.println("Enter the balance");
					account.setBalance(sc.nextDouble());

					bank1.setAccounts(account);
					bankService.CreateAccount(bank1);
				}
				}
			}
				break;
			case 2: {
				System.out.println("1: UpdateBankDetails\n 2: UpdateAccountDetails");
				System.out.println("Enter the choice");
				int choice2 = sc.nextInt();
				switch (choice2) {
				case 1: {
					System.out.println("Enter the bank id");
					int b_id = sc.nextInt();
					Bank bank2 = bankService.findBank(b_id);
					System.out.println(" 1: updateName\n 2: updateBranch");
					System.out.println("Enter the choice");
					int option = sc.nextInt();
					switch (option) {
					case 1: {
						System.out.println("Enter the new name");
						bank2.setB_name(sc.next());
						bankService.updateBank(bank2);
					}
						break;
					case 2: {
						System.out.println("Enter the new Branch name");
						bank2.setB_name(sc.next());
						bankService.updateBank(bank2);
					}
					}
				}
					break;
				case 2: {
					System.out.println("Enter the Account id");
					int a_id = sc.nextInt();
					Account account = bankService.findAccount(a_id);
					System.out.println(" 1: updateAccNo\n 2: updateBalance");
					System.out.println("Enter the choice");
					int option = sc.nextInt();
					switch (option) {
					case 1: {
						System.out.println("Enter the new accno");
						account.setAccno(sc.nextLong());
						bankService.updateAccount(account);
					}
						break;
					case 2: {
						System.out.println("Enter the amount");
						account.setBalance(sc.nextDouble());
						bankService.updateAccount(account);
					}
					}
				}
				}
			}
				break;
			case 3: {
				System.out.println("Enter the Bank id");
				Bank bank1 = bankService.findBank(sc.nextInt());
				bankService.deleteData(bank1);

			}
				break;
			case 4: {
				System.out
						.println(" 1: displayBankDetails\n 2: DisplayAccountDetails\n 3: DisplayBankAndAccountDetails");
				System.out.println("Enter the choice");
				int option = sc.nextInt();
				Bank bank1 = null;
				switch (option) {
				case 1: {
					System.out.println("Enter the Bank id");
					bank1 = bankService.findBank(sc.nextInt());
					System.out.println("bank id : " + bank1.getB_id());
					System.out.println("bank name : " + bank1.getB_name());
					System.out.println("bank branch : " + bank1.getBranch());
				}
					break;
				case 2: {
					System.out.println("Enter the Bank id");
					bank1 = bankService.findBank(sc.nextInt());
					Account account = bank1.getAccounts();
					System.out.println("account id " + account.getA_id());
					System.out.println("account number " + account.getAccno());
					System.out.println("account balance " + account.getBalance());
				}
					break;
				case 3: {
					System.out.println("Enter the Bank id");
					bank1 = bankService.findBank(sc.nextInt());
					System.out.println("bank id : " + bank1.getB_id());
					System.out.println("bank name : " + bank1.getB_name());
					System.out.println("bank branch : " + bank1.getBranch());
					System.out.println("--------------------------");
					Account account = bank1.getAccounts();
					System.out.println("account id " + account.getA_id());
					System.out.println("account number " + account.getAccno());
					System.out.println("account balance " + account.getBalance());
				}
				}
			}
			}
		}
	}
}
