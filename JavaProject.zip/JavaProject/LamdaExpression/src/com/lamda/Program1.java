package com.lamda;

import java.util.ArrayList;

public class Program1 
{
	public static void main(String[] args) 
	{
		ArrayList<Integer> a = new ArrayList<>();
		a.add(10);
		a.add(30);
		a.add(80);
		a.add(20);
		a.add(35);
		a.add(58);
		
		a.forEach((n)-> {System.out.println(n);});
	}
}
