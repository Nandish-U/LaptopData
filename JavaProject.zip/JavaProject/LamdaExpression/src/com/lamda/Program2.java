package com.lamda;

import java.util.ArrayList;
import java.util.function.Consumer;

public class Program2 
{
	public static void main(String[] args) 
	{
		ArrayList<Integer> a = new ArrayList<>();
		a.add(10);
		a.add(30);
		a.add(80);
		a.add(20);
		a.add(35);
		a.add(58);
		System.out.println(a.get(7));
		
		Consumer<Integer> c = (n) ->{System.out.println(n);};
		a.forEach(c);
	}
}
