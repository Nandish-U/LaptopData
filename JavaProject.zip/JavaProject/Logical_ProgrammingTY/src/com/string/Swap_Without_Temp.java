package com.string;

public class Swap_Without_Temp {
	public static void main(String[] args) 
	{
		String s = "hello";
		String s1 = "hi";
		s = s.concat(s1);
		s1 = s.substring(0,s.length()-s1.length());
		s = s.substring(s1.length());
		System.out.println(s);
		System.out.println(s1);
	}
}
