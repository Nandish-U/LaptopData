package com.string;

public class Remove_Consequtive_Space {
	public static void main(String[] args) 
	{
		String s = "Hello        mmmmm         hi";
		char[] c = s.toCharArray();
		String s1 ="";
		for(int i=0; i<c.length; i++)
		{
				if(s.charAt(i)==' ' && s.charAt(i+1)==' ')
				{
					
				}
				else
				{ 
					s1 = s1+c[i];
				}
		}
		System.out.println(s1);
	}
}
