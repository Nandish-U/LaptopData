package com.string;

public class Panagram
{
	public static void main(String[] args) {
		String s = "abcdefghijk  lmnopqrstuvwxyz";
		s =s.toLowerCase();
		char[] c1 = s.toCharArray();
		boolean flag = true;
		char c='a';
		for(int i=0;i<c1.length;i++) {
			for(int j=0; j<c1.length; j++)
			{
				if(c1[i]!=c)
				{
					flag = false;
					break;
				}
			}
			if(c1[i]!=' ')
			c++;
		}
		if(flag == true)
		{
			System.out.println("panagram");
		}
		else
		{
			System.out.println("Not");
		}
	}
}
