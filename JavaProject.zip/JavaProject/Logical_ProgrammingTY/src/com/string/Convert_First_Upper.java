package com.string;

import java.util.Scanner;

public class Convert_First_Upper {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		String s1 = sc.nextLine();
		String s = s1.toLowerCase();
		char[] c = new char[s.length()];
		for(int i=0; i<s.length(); i++)
		{
			c[i]= s.charAt(i);
		}
		int c1=0;
		for(int i=0; i<c.length; i++)
		{	
				
		}
		System.out.println(c1);
	}
}
