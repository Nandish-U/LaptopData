package com.string;

public class Swap_String 
{
	public static void main(String[] args) 
	{
		String s = "hello";
		String s1 = "hi";
		String temp = s;
		s = s1;
		s1 = temp;
		System.out.println(s);
		System.out.println(s1);
	}
}
