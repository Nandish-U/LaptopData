package com.string;

public class Reverse_Word {
	public static void main(String[] args) {
//		String s = "   Hello    hi    how r u   ";
//		String[] k = s.split(" ");
//		String s2 ="";
//		for (int i = 0; i < k.length; i++) {
//			char[] c = k[i].toCharArray();
//			for (int j = c.length-1; j>=0; j--) {
//				s2+=c[j];
//			}
//			s2+=" ";
//		}
//		System.out.println(s2);
		
		String s1 = "   Hello    hi    how r u   ";
		String s2="";
		String[] k1 = s1.split(" ");
		for (int i = k1.length-1; i>=0; i--) {
			s2+=k1[i]+" ";
		}
		System.out.println(s2);
	}
}
