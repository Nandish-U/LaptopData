package com.string;

public class Repeated_Words {
	public static void main(String[] args) {
		String s1 = "hello one hi One hi";
		String s[] = s1.split(" ");
		for (int i = 0; i < s.length; i++) {
			int count = 0;
			for (int j = i + 1; j<s.length; j++) {
				if (s[i].equalsIgnoreCase(s[j])) {
					count++;
					s[j] = "0";
				}
			}
			if (count > 0 && s[i] != "0")
				System.out.println(s[i]);
		}
	}
}
