package com.string;

import java.util.Scanner;

public class To_LowerCase {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		String s = sc.nextLine();
		int res =0;
		for(int i=0; i<s.length();i++)
		{
			if(s.charAt(i)>=65 && s.charAt(i)<=90)
			{
				res = s.charAt(i)+32;
			}
			else
			{
				res = (int)s.charAt(i);
			}
			System.out.print((char)res);
		}
	}
}
