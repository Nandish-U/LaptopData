package com.string;

public class Print_Duplicate {
	public static void main(String[] args) 
	{
		String s = "HelleeeeooohhhoHww";
		char[] c = s.toCharArray();
		for(int i=0 ;i<c.length; i++)
		{
			int count =0;
			for(int j=i+1;j<c.length;j++)
			{
				if(c[i]==c[j])
				{
					count++;
					c[j]='-';
				}
			}
			if(count>0 && c[i]!='-')
			{
				System.out.println(c[i]);
			}
		}
	}
}
