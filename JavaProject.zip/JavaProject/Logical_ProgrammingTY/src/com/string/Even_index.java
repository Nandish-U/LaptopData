package com.string;

import java.util.Scanner;

public class Even_index {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String ");
		String s1 = sc.next();
		String s2 ="";
		if(s1.length()%2 ==1)
		{
			for(int i=0; i<s1.length(); i++)
			{
				if(i%2==0)
				{
					s2+=s1.charAt(i);
				}
				else
				{
					s2+=",";
				}
			}
			System.out.println(s2);
		}
		else
		{
			for(int i=0; i<s1.length()-1; i++)
			{
				if(i%2==0)
				{
					s2+=s1.charAt(i);
				}
				else
				{
					s2+=",";
				}
			}
			System.out.println(s2);
		}
	}
}
