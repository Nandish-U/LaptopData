package com.string;

import java.util.Scanner;

public class Remove_Character 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		String s = sc.nextLine();
		System.out.println("Enter the string to remove");
		String r = sc.nextLine();
		char[] c = s.toCharArray();
		char[] d = r.toCharArray();
		String res="";
		for(int i=0; i<c.length; i++)
		{
			for(int j=0; j<d.length; j++)
			{
				if(c[i]==d[j])
				{
					c[i]='1';
				}
			}
			if(c[i]!='1')
			{
				System.out.print(c[i]);
			}
		}
	}
}
