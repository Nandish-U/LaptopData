package com.string;

public class Only_Digit {
	public static void main(String[] args) 
	{
		String s = "344hdjskjks444";

		int count=0;
		for(int i=0;i<s.length();i++) {


			if(s.charAt(i)>'0' && s.charAt(i)<'9') {

				count=1;
			}
			else {

				break;
			}

		}
		 String s = "programming";
			
	       String s1 = s.toLowerCase();
			int count=0;
			for(int i=0;i<s1.length();i++) {
				
				
				if(s1.charAt(i)>='a' && s1.charAt(i)<='z') {
					
				     count++;
				}
				else {
					
					break;
				}
				
			}
			
			if(count==s1.length()) {
				
				System.out.println("True");
			}
			else {	break;
			}
		
		if(count==s1.length()) {
			
			System.out.println("True");
		}
		else {
			
			System.out.println("false");
		}


		String s = "progra@#$m9876ming";
		
	       String s1 = s.toLowerCase();
			int count=0;
			for(int i=0;i<s1.length();i++) {
				
				
				if((s1.charAt(i)>='a' && s1.charAt(i)<='z') ||
				  (s1.charAt(i)>='0' && s1.charAt(i)<='9') ){
					
				     count++;
				}
				else {
					
					break;
				}
				
			}
			
			if(count==s1.length()) {
				
				System.out.println("True");
			}
			else {
				
				System.out.println("false");
			}

	}
	}
