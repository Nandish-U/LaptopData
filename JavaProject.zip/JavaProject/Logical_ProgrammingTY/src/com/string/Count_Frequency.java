package com.string;

import java.util.Scanner;

public class Count_Frequency {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String ");
		String s1 = sc.nextLine();
		// char[]c = s1.toCharArray();
		// for(int i=0; i<c.length; i++)
		// {
		// int count =1;
		// for(int j=i+1; j<c.length; j++)
		// {
		// if(c[i]==c[j])
		// {
		// count++;
		// c[j]='1';
		// }
		// }
		// if(c[i]!='1')
		// System.out.println(s1.charAt(i)+" "+count);
		//

		String s4 = "";
		while (s1.length() > 0) {
			char k = s1.charAt(0);
			s4 = s1.replace(k + "", "");
			int count = s1.length() - s4.length();
			System.out.println(k + " " + count);
			s1 = s4;
		}
	}

}
