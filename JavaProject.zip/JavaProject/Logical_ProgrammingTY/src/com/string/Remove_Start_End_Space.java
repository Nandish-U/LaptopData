package com.string;

public class Remove_Start_End_Space {
	public static void main(String[] args) {
		String s = "    hello  hi    ";
		char[] k = s.toCharArray();
		int c = 1;
		int j = 1;
		for (int i = 0; i < k.length; i++) {
			if (k[i] == ' ' && k[i + 1] == ' ') {
				c++;
			} else
				break;
		}
		
		for (int i = k.length - 1; i > 0; i--) {
			if (k[i] == ' ' && k[i - 1] == ' ') {
				j = i;
			} else
				break;

		}

		for (int i = c; i <= j; i++) {
			System.out.print(k[c]);
			c++;

		}
	}
}
