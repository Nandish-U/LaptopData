package com.string;

public class Remove_Vowels {
	public static void main(String[] args) 
	{
		String s = "Java is goode";
		s= s.toLowerCase();
		String s2 = "";
		for(int i=0; i<s.length(); i++)
		{
			if(s.charAt(i)=='a' || s.charAt(i)=='e' || s.charAt(i)=='i' || s.charAt(i)=='o' || s.charAt(i)=='u')
			{
				
			}
			else
				s2 = s2+s.charAt(i);
		}
		System.out.println(s2);
	}
}
