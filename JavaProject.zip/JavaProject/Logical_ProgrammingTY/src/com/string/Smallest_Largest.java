package com.string;

public class Smallest_Largest {
	public static void main(String[] args) {
		String s = "java is a lan language";
		String[] s1 = s.split(" ");
		int max = 0;
		int min = s1.length;
		int sm = 0;
		int lr = 0;
		for (int i = 0; i < s1.length; i++) {
			if (s1[i].length() > max) {
				max = s1[i].length();
				lr = i;
			}
			if (s1[i].length() < min) {
				min = s1[i].length();
				sm = i;
			}
		}
		System.out.println(sm);
		System.out.println(lr);
		System.out.println("smallest "+s1[sm]);
		System.out.println("largest "+s1[lr]);

	}
}
