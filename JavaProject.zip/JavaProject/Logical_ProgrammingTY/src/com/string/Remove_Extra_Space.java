package com.string;

public class Remove_Extra_Space {
	public static void main(String[] args) 
	{
		String s = "   Hi      good       Evening    ";
		s = s.trim();
		String s1="";
		int j=0;
		for(int i=0; i<s.length(); i++)
		{
			if(s.charAt(i)==' ')
			{
				j++;
			}
			if(s.charAt(i)==' ' && s.charAt(i+1)==' ')
			{
				
			}
			else
			{
				s1 = s1+s.charAt(i);
			}
		}
		System.out.println(j);
		System.out.println(s1);
	}
}
