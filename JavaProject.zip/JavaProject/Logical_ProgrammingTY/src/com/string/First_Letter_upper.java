package com.string;

import java.util.Arrays;
import java.util.Scanner;

public class First_Letter_upper {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter String");
		String str=sc.nextLine();
		String[] arr=new String[str.length()];
		for(int i=0;i<str.length();i++) {
			arr[i]=str.charAt(i)+"";
		}
		int j=0;
		for(int i=0;i<arr.length;i++) {
			int c =0;
			if(i==0)
			{
				int h = arr[i].hashCode();
				char k = (char)h;
				k+=32;
				arr[i]=k+"";
			}
				while(arr[j]!=" " && j<8)
				{
					c++;
					j++;
				}
//			if(c<arr.length)
				arr[c+1]= arr[c+1]+32;
		}
//		System.out.println(Arrays.toString(arr));
	}
	//	public static void main(String[] args) 
	//	{
	//		Scanner sc = new Scanner(System.in);
	//		System.out.println("Enter the String");
	//		String s = sc.nextLine();
	//		String[] ss = new String[s.length()];
	//		
	//		int j=0;
	//		for(int i=0; i<s.length();i++)
	//		{
	//			String res ="";
	//			while(s.charAt(j)!=' ')
	//			{
	//				res = res+s.charAt(j);
	//				j++;
	//			}
	//			ss[i]=res;
	//		}
	//		System.out.println(ss[0]);
	////		for(int i=0; i<ss.length;i++)
	////		{
	////		System.out.print(ss[i]);;
	////		}
	//	}
}
