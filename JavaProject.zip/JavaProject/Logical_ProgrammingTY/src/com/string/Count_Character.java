package com.string;

import java.util.Scanner;

public class Count_Character {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		String s = sc.nextLine();
		int res =0;
		String k = "";
		for(int i=0; i<s.length();i++)
		{
			if(s.charAt(i)>=65 && s.charAt(i)<=90)
			{
				res = s.charAt(i)+32;
			}
			else
			{
				res = (int)s.charAt(i);
			}
			k = k+(char)res;
		}
		System.out.println(k);
		int vowel =0;
		int conso =0;
		int special = 0;
		int number=0;
		for(int i=0; i<k.length(); i++)
		{
			if(k.charAt(i)=='a' || k.charAt(i)=='e' || k.charAt(i)=='i' || k.charAt(i)=='o' || k.charAt(i)=='u')
			{
				vowel++;
			}
			else
			{
				conso++;
			}
			if(!(k.charAt(i)>=65 && k.charAt(i)<=90 || k.charAt(i)>=97 && k.charAt(i)<=122 || k.charAt(i)>=48 && k.charAt(i)<=57))
			{
				special++;
			}
			else if(k.charAt(i)>=48 && k.charAt(i)<=57)
			{
				number++;
			}
		}
		System.out.println("vowel character "+vowel);
		System.out.println("consonent character "+(conso-special-number));
		System.out.println("special character "+special);
		System.out.println("number character "+number);
	}
}
