package com.string;

import java.util.Scanner;

public class Remove_Multiple_Space {

    static void removeSpace(char str[])
    {
        for (int i = 0; i < str.length; i++)
        { 
        	for(int j = i+1; j < str.length; j++)
            {
        		
            }
        }
    }
    public static void main(String[] args)
    {
    	Scanner sc = new Scanner(System.in);
    	System.out.println("Enter the string");
    	String s = sc.nextLine();
    	char[] c  = new char[s.length()];
    	for(int i=0; i<c.length; i++)
    	{
    		c[i] = s.charAt(i);
    	}
    	System.out.println(c);
    	removeSpace(c);
    }
}
