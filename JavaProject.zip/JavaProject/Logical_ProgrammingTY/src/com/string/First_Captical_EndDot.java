package com.string;

public class First_Captical_EndDot {
	public static void main(String[] args) 
	{
		String s = "hello";
		for(int i=0; i<s.length(); i++)
		{
			
		}
	}
}
