package com.string;

import java.util.Scanner;

public class Odd_index_Lower {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string");
		String s = sc.nextLine();
		System.out.println(s);
		char[] c = s.toCharArray();
		String s2 ="";
		for(int i=0; i<c.length;i++)
		{
			if(i%2==1 && c[i]!=' ' )
			{
				c[i]+=32;
				s2 = s2+c[i];
			}
			else
			{
				s2 = s2+c[i];
			}
		}
		System.out.println(s2);
	}
}
