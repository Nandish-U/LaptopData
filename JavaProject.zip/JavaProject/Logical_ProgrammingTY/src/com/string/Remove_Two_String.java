package com.string;

import java.util.Scanner;

public class Remove_Two_String {
	public static void main(String[] args) {
		// Scanner sc = new Scanner(System.in);
		// System.out.println("Enter the 1st String");
		// String s = sc.nextLine();
		// System.out.println("Enter the 2nd string");
		// String r = sc.nextLine();
		// char[] c1 = s.toCharArray();
		// char[] d2 = r.toCharArray();
		// for (int i = 0; i < d2.length; i++) {
		// int count = 0;
		// boolean flag = false;
		// for (int j = 0; j < c1.length; j++) {
		// if (d2[i] == c1[j]) {
		// count++;
		// flag = true;
		// }
		// if (count == 1) {
		// d2[i] = '!';
		// }
		// }
		// if (flag == false) {
		// System.out.print(d2[i]);
		// }
		// }
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the 1st String");
		String s = sc.nextLine();
		System.out.println("Enter the 2nd string");
		String r = sc.nextLine();
		char[] c1 = s.toCharArray();
		char[] d2 = r.toCharArray();
		for (int i = 0; i < d2.length; i++) {
			int count = 0;
			for (int j = 0; j < c1.length; j++) {
				if (d2[i] == c1[j]) {
					count++;
				}
				if (count == 1) {
					c1[i] = '!';
					d2[i] = '!';
				}
			}
			if(d2[i]!='!')
			{
				System.out.println(d2[i]);
			}
		}

	}
}
