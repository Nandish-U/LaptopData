package com.string;

import java.util.Arrays;

public class First_Upper {
	public static void main(String[] args) {
//		String s = "hello     hi   ";
//		String s1 ="";
//		int l=0;
//		String[] k = s.split(" ");
//		for(int i=0; i<k.length; i++)
//		{
//			char[] c = k[i].toCharArray();
//			for(int j=0; j<c.length; j++)
//			{
//				if(c[j]>=97 && c[j]<=122 && j==0)
//				{
//					char p = (char) (c[j]-32);
//					s1+=p;
//				}
//				else
//				{
//					s1+=c[j];
//				}
//			}
//			if(l<k.length-1) {
//			s1+=" ";
//			l++;}
//		}
//		System.out.println(s1);
		String b = "hello this is test yantra  ";
		char[] w = b.toCharArray();
		String ss = "";
		for (int i = 0; i < w.length; i++) {
			if (w[0] != ' ' && w[0] >= 'a' && w[0] <= 'z')
				w[0] = (char) (w[0] - 32);
			if (w[i] == ' ' && w[i + 1] != ' ' && w[i + 1] >= 'a' && w[i + 1] <= 'z') {
				w[i + 1] = (char) (w[i + 1] - 32);
			}
		}
		for (int i = 0; i < w.length - 1; i++) {
			ss=ss+w[i];
		}
		System.out.println(ss);
	}

}
