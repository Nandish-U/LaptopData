package com.string;

public class Remove_Space {
	public static void main(String[] args) 
	{
		String s = "Hi good     Morning";
		System.out.println(s.replaceAll(" ", ""));
		String s1 = "";
		for(int i=0; i<s.length(); i++)
		{
			if(s.charAt(i)!=' ')
			{
				s1 = s1+s.charAt(i);
			}
		}
		System.out.println(s1);
	}
}
