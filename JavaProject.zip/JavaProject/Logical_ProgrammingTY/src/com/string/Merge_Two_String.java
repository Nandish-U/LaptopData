package com.string;

public class Merge_Two_String 
{
	public static void main(String[] args) 
	{
		String s = "hello";
		String s1 = "hi";
		String res = "";
		for(int i=0; i<s.length(); i++)
		{
			res+=s.charAt(i);
		}
		for(int i=0; i<s1.length(); i++)
		{
			res+=s1.charAt(i);
		}
		System.out.println(res);
	}
}
