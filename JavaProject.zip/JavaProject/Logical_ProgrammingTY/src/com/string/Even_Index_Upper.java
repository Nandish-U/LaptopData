package com.string;

import java.util.Scanner;

public class Even_Index_Upper {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string");
		String s = sc.nextLine();
		s.toLowerCase();
		char[]c = s.toCharArray();
		System.out.println(c);
		String s1 ="";
		for(int i=0; i<c.length;i++)
		{
			if(i%2==0 && c[i]!=' ')
			{
				c[i]-=32;
				s1 = s1+c[i];
			}
			else
			{
				s1 = s1+c[i];
			}
		}
		System.out.println(s1);
	}
}
