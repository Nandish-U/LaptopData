package com.string;

public class Remove_Odd_Index {
	public static void main(String[] args) 
	{
		String s  = "Hello";
		String s1 = "";
		for(int i=0; i<s.length(); i++)
		{
			if(i%2==0)
			{
				s1+=s.charAt(i);
			}
		}
		System.out.println(s1);
	}
}			
