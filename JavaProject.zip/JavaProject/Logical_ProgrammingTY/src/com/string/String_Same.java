package com.string;

import java.util.Scanner;

public class String_Same 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first String");
		String s1 = sc.next();
		System.out.println("Enter the second String");
		String s2 = sc.next();
		int count =0;
		if(s1.length()==s2.length()) {
			for(int i=0; i<s1.length(); i++)
			{
				if(s1.charAt(i)==s2.charAt(i))
				{
					count++;
				}
			}
			if(count == s1.length())
			{
				System.out.println("same");
			}
			else
			{
				System.out.println("not same");
			}
		}
		else
		{
			System.out.println("Not same");
		}

	}
}
