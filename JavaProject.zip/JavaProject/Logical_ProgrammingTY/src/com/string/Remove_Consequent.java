package com.string;

public class Remove_Consequent {
	public static void main(String[] args) {
		String s = "abbacccd";
		char[] d = s.toCharArray();
		String s1 = "";
		for (int i = 0; i < d.length-1; ) {
			if(d[i]==d[i+1])
			{
//				s1+=d[i];
				i++;
			}
		}	
		System.out.println(s1);
	}
}
