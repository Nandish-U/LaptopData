package com.string;

import java.util.Arrays;

public class Anagram {
	public static void main(String[] args) {
//		 String s1 = "dog";
//		 s1 = s1.toLowerCase();
//		 char[] c = s1.toCharArray();
//		 String s2 = "god";
//		 s2 = s2.toLowerCase();
//		 char[] c1 = s2.toCharArray();
//		 boolean flag = true;
//		 if (c.length == c1.length) {
//		 for(int i=0 ;i<c.length; i++)
//		 {
//		 for(int j=0; j<c1.length; j++)
//		 {
//		 if(c[i]!=c1[j])
//		 {
//		 flag = false;
//		 }
//		 }
//		 }
//		 if(flag == true)
//		 {
//		 System.out.println("Anagram");
//		 }
//		 else
//		 {
//		 System.out.println("Not ");
//		 }
//		 }
//		 else
//		 {
//		 System.out.println("Unequal length");
//		 }
		String s = "aello";
		String s2 = "Hello";
		s = s.toLowerCase();
		s2 = s2.toLowerCase();
		char[] c = s.toCharArray();
		char[] c1 = s2.toCharArray();
		Arrays.sort(c);
		Arrays.sort(c1);
		boolean flag = true;
		if (c.length == c1.length) {
			for (int i = 0; i < c.length; i++) {
				if (c[i] != c1[i]) {
					flag = false;
				}
			}
			if (flag == true) {
				System.out.println("Anagram");
			} else {
				System.out.println("Not");
			}
		} else {
			System.out.println("Unequal length");
		}

	}
}
