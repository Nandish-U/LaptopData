package com.string;

public class Merge_Remove_Extra_Space
{
	public static void main(String[] args) {
		String s="           Hello           hiii          ";
		char[] a=s.toCharArray();
		String s1="";
		for(int i=0,j=i+1;i<a.length&& j<a.length-1;i++,j++)
		{
			if(a[i]==' ' && a[j]==' ')
			{
				
			}
			else
			{
				s1+=a[i];
			}
		}
		System.out.println(s1);
	}

}
