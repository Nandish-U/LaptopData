package com.number_pattern;

public class Number_Pyramid 
{
	public static void main(String[] args) 
	{
		int n=3;
		int k=1;
		for(int i=1; i<=n; i++)
		{
			for(int j=1; j<n+i; j++)
			{
				if(j>n-i)
				{
					System.out.print(k+" ");
					k++;
				}
				else
				{
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
		char c='a';
		for(int i=1; i<=n; i++)
		{
			for(int j=1; j<n+i; j++)
			{
				if(j>n-i)
				{
					System.out.print(c+" ");
					c++;
				}
				else
				{
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
	}
}

				