package com.number_pattern;

public class Today15th {
	public static void main(String[] args) {
		int n = 3;
		int e6 = 65;
		System.out.println("===========1==========");
//		AAA
//		 BB
//		  C
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (j >= i) {
					System.out.print((char) e6);

				} else {
					System.out.print(" ");
				}
			}
			e6++;

			System.out.println();
		}
		System.out.println("\t");
		char c = 'A';
		System.out.println("===========2==========");
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (j >= i) {
					System.out.print(c);
					c++;

				} else {
					System.out.print(" ");
				}
			}

			System.out.println();
		}
		System.out.println("\t");

		System.out.println("===========3==========");
		int e7 = 65 + n - 1;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (j >= i) {
					System.out.print((char) e7);
					e7--;
				} else {
					System.out.print(" ");
				}
			}
			e7 = 64 + n - i;
			System.out.println();
		}
		System.out.println("\t");
		System.out.println("===========4==========");
		char r = 'A';
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (i <= j) {
					System.out.print(r);

				} else {
					System.out.print(" ");
				}
			}
			r++;
			System.out.println();
		}
		System.out.println("\t");
		System.out.println("===========5==========");
//		AAAAA
//		11111
//		BBBBB
//		22222
//		CCCCC
		// n value is 3
		char r1 = 'A';
		int l = 1;
		for (int i = 1; i < n * 2; i++) {
			for (int j = 1; j < n * 2; j++) {
				if (i % 2 == 0) {
					System.out.print(l);

				} else {
					System.out.print(r1);
				}
			}
			if (i % 2 == 0) {
				l++;
			} else {
				r1++;
			}
			System.out.println();
		}
		System.out.println("\t");
		System.out.println("===========6=========");
		char r2 = 'A';
		int n1 = 1;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (i == j) {
					if (i % 2 == 1) {
						System.out.print(r2);
					} else {
						System.out.print(n1 + "");
					}

				} else {
					System.out.print(" ");
				}
			}
			if (i % 2 == 0) {
				n1++;
			} else {
				r++;
			}
			System.out.println();
		}
		System.out.println("\t");
		System.out.println("===========7==========");
		char r3 = 'A';
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if ((i + j) - 1 == n) {
					System.out.print(r3);

				} else {
					System.out.print(" ");
				}
			}
			r3++;
			System.out.println();
		}
		System.out.println("\t");
		System.out.println("===========8==========");

		int n2 = 1;
		for (int i = 1; i <= n; i++) {
			char r4 = 'A';
			for (int j = 1; j <= n; j++) {
				if (j % 2 == 1) {
					System.out.print(r4);
					r4++;

				} else {
					System.out.print(n2);
				}
			}
			System.out.println();
		}
		System.out.println("\t");
		System.out.println("===========9==========");
		char r5 = 'A';
		int n3 = 1;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (j == 1 || i == 1 || i == n || j == n) {
					if (i % 2 == 1) {
						System.out.print(r5);
					} else {
						System.out.print(n3);
					}
				} else {
					System.out.print(" ");
				}
			}
			if (i % 2 == 1) {
				r5++;
			} else {
				n3++;
			}
			System.out.println();
		}
		System.out.println("\t");
		System.out.println("=========================================================");
		System.out.println("============Assignment=============");
		System.out.println("===========10==========");
		int n4 = 1;
		for (int i = 1; i <= n; i++) {
			char r6 = 'A';
			for (int j = 1; j <= n; j++) {
				if (j == 1 || i == 1 || i == n || j == n) {
					if (j % 2 == 1) {
						System.out.print(r6++);
					} else {
						System.out.print(n4);
					}
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
		System.out.println("===========11==========");
		char g1 = 'A';
		char f2 = 'A';
		int n5 = 1;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (j % 2 == 1) {
					System.out.print(f2 + " ");
					f2 += n;
				} else {
					System.out.print(n5 + " ");
					n5++;
				}
			}
			g1++;
			f2 = g1;
			System.out.println();
		}
		System.out.println("\t");
		System.out.println("===========12==========");
		char f3 = 'A';
		int n6 = 1;
		for (int i = 1; i <= n + 1; i++) {
			for (int j = 1; j <= n + 1; j++) {
				if (i % 2 == 1) {
					System.out.print(f3 + " ");
					f3++;
				} else {
					System.out.print(n6 + " ");
					n6++;
				}
			}

			System.out.println();
		}
		System.out.println("\t");
		System.out.println("==========13===========");
		char f4 = 'A';
		int n7 = 1;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j < n + i; j++) {
				if (j > n - i) {
					if (i % 2 == 1)
						System.out.print(f4++ + " ");
					else
						System.out.print(n7++ + " ");
				} else {
					System.out.print("  ");
				}
			}
			f4++;
			System.out.println();
		}
		System.out.println("==========14===========");
		char f5 = 'A';
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j < n + i; j++) {
				if (i == j) {
					System.out.print(f5++ + " ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("===========15==========");

		for (int i = 1; i <= n; i++) {
			char f6 = 'A';
			for (int j = 1; j <= n; j++) {
				System.out.print(f6 + " ");
				f6++;
			}
			System.out.println();
		}
	}
}
