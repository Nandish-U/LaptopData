package com.number_pattern;

public class Number_Triangle {
	public static void main(String[] args) {
		int n = 3;
		for (int i = 1; i < n * 2; i++) {
			int a = 1;
			for (int j = 1; j <= i; j++) {
				System.out.print(a + " ");
				a++;

			}
			System.out.println();
		}
		System.out.println("\n");

		for (int i = 1; i < n * 2; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(i + " ");

			}
			System.out.println();
		}
		System.out.println("\t");

		for (int i = 1; i < n * 2; i++) {

			for (int j = 1; j <= i; j++) {
				if (i % 2 == 1) {
					System.out.print(5 + " ");
				} else if (i % 2 == 0) {
					System.out.print(i + " ");
				}

			}

			System.out.println();
		}
		System.out.println("\t");
		for (int i = 1; i < n * 2; i++) {
			for (int j = 1; j <= i; j++) {
				if (j % 2 == 1) {
					System.out.print(1 + " ");
				} else {
					System.out.print(0 + " ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
		int a = 1;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				System.out.print(a + " ");
				a = a + n;
			}
			a = i + 1;
			System.out.println();
		}
		System.out.println("\t");

		int b1 = 1;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				System.out.print(b1 + " ");
				b1++;
			}
			System.out.println();
		}
		System.out.println("\t");
		int k = 1;
		for (int i = 1; i < n * 2; i++) {

			for (int j = 1; j <= i; j++) {
				System.out.print(k + " ");
				k++;

			}
			System.out.println();
		}
		System.out.println("\t");

		int p = 1;
		int q = 5;
		for (int i = 1; i < n * 2; i++) {
			int r = q - 1;
			for (int j = 1; j <= i; j++) {
				System.out.print(p + " ");
				p = p + r--;
			}
			p = 1;
			p += i;

			System.out.println();
		}
		System.out.println("\t");
	}
}
