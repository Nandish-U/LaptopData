package com.number_pattern;

public class Nmumber_1 {
	public static void main(String[] args) {
		int a = 1;
		int n = 3;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (i + j >= n + 1) {
					System.out.print(a);
					a++;
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
		System.out.println("=====================");
		int b = 1;
		for (int i = 1; i <= n; i++) {
			for (int j = n; j >= 1; j--) {
				if (i >= j) {
					System.out.print(j);
				} else {
					System.out.print(" ");
				}
			}

			System.out.println();
		}
		System.out.println("=====================");

		for (int i = 1; i <= n + 1; i++) {
			for (int j = 1; j <= n + 1; j++) {
				if (i % 2 == 0) {
					System.out.print(0);
				} else {
					System.out.print(1);
				}
			}
			System.out.println();
		}
		System.out.println("=====================");
		int c = 1;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (i + j >= n + 1) {
					System.out.print(c);
				} else {
					System.out.print(" ");
				}
			}
			c++;
			System.out.println();
		}
		System.out.println("=====================");
		for (int i = 1; i <= n + 1; i++) {
			for (int j = 1; j <= n + 1; j++) {
				if (j % 2 == 0) {
					System.out.print(0);
				} else {
					System.out.print(1);
				}
			}
			System.out.println();
		}
		System.out.println("=====================");
		int d = 1;
		int d1 = 1;
		int d2 = 1;
		for (int i = 1; i <= n + 1; i++) {
			for (int j = 1; j <= n + 1; j++) {
				if (i % 2 == 1) {
					System.out.print(d);
				} else {
					System.out.print(d1);
					d1++;
				}
			}
			d++;
			d1 = d2;
			System.out.println();
		}
		System.out.println("=====================");
		int e = 4;
		for (int i = 1; i <= n + 1; i++) {
			for (int j = 1; j <= n + 1; j++) {
				if (i + j < n * 2) {
					System.out.print(e);
				} else {
					System.out.print("");
				}
			}
			e--;
			System.out.println();
		}
		System.out.println("=====================");
//		4444
//		 333
//		  22
//		   1
		int e1 = 4;
		for (int i = 1; i <= n + 1; i++) {
			for (int j = 1; j <= n + 1; j++) {
				if (j >= i) {
					System.out.print(e1);
				} else {
					System.out.print(" ");
				}
			}
			e1--;
			System.out.println();
		}
		System.out.println("=====================");
		
		System.out.println("==========1===========");
//		     1 
//		   2 2 2 
//		 3 3 3 3 3 
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j < n + i; j++) {
				if (j > n - i) {
					System.out.print(i + " ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("=====================");

		
		System.out.println("==========2===========");

		char c4 = 'A';
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j < n + i; j++) {
				if (j > n - i) {
					System.out.print(c4 + " ");
				} else {
					System.out.print("  ");
				}
			}
			c4++;
			System.out.println();
		}
		System.out.println("=====================");

		System.out.println("==========3===========");
		char c5 = 'A';
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				System.out.print(c5 + " ");

			}
			c5++;
			System.out.println();
		}
		System.out.println("=====================");
		System.out.println("==========4===========");
		
//		A 
//		B C 
//		D E F 
		// n value is 3
		char c6 = 'A';
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(c6 + " ");
				c6++;
			}

			System.out.println();
		}
		System.out.println("=====================");
		System.out.println("==========5===========");
		char c7 = 'A';
		char c8 = 'A';
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(c7 + " ");
				c7++;
			}
			c7 = c8;
			System.out.println();
		}
		System.out.println("=====================");

		System.out.println("==========6==========");
		char r = 'A';
		for (int i = 1; i <= n; i++) {
			for (int j = n; j >= 1; j--) {
				if (i >= j) {
					System.out.print(r);
					r++;
				} else {
					System.out.print(" ");
				}
			}
			r = c8;
			System.out.println();
		}
		System.out.println("=====================");
		System.out.println("==========7===========");
		char c9 = 'A';
		char f1 = 'A';
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				System.out.print(c9 + " ");
				c9++;
			}
			c9 = f1;
			System.out.println();
		}
		System.out.println("=====================");

		System.out.println("==========8===========");
		char g1 = 'A';
		char f2 = 'A';
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				System.out.print(f2 + " ");
				f2 += n;
			}
			g1++;
			f2 = g1;
			System.out.println();
		}
		System.out.println("=====================");
		System.out.println("==========9===========");
		int l = 65;
		int l1=65;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= i; j++) {
				
					System.out.print((char) l + " ");
					l = l + n - j;
			
					System.out.print(" ");
			}
			l = l1+i;

			System.out.println();
		}
		System.out.println("=====================");

		System.out.println("==========10===========");
//		  1 
//		 2 2 
//		3 3 3 
		int n8 = 3;
		for (int i = 1; i <= 3; i++) {
			for (int j = 1; j <=3; j++) {
				if (i + j > n) {
					System.out.print(i + " ");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
		System.out.println("=====================");
		System.out.println("=====================");
		System.out.println("==========11==========");
		int e5 = 65;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (j >= i) {
					System.out.print((char)e5);
				} else {
					System.out.print(" ");
				}
			}
			e5++;
			System.out.println();
		}
		System.out.println("==========12==========");
		int e6 = 65;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (j >= i) {
					System.out.print((char)e6);
					e6++;
				} else {
					System.out.print(" ");
				}
			}
			
			System.out.println();
		}
		System.out.println("==========13==========");
		int e7 = 65+n-1;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				if (j >= i) {
					System.out.print((char)e7);
					e7--;
				} else {
					System.out.print(" ");
				}
			}
			e7=64+n-i;
			System.out.println();
		}
		System.out.println("==========14==========");
		int e9 = 65;
		for (int i = 1; i <= n; i++) {
			for (int j = n; j >= 1; j--) {
				if (i >= j) {
					System.out.print((char)e9+" ");
				} else {
					System.out.print("  ");
				}
			}
			e9++;
			System.out.println();
		}
		
	}
}
