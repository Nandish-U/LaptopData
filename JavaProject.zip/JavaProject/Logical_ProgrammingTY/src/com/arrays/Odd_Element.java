package com.arrays;

import java.util.Scanner;

public class Odd_Element {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("======================");
		for (int i = 0; i < size; i++) {
			if (a[i] % 2 == 1 || a[i] % 2 != 0) {
				System.out.print(a[i] + " ");
			}
		}
	}
}
