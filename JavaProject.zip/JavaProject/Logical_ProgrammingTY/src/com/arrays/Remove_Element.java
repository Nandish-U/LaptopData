package com.arrays;

import java.util.Scanner;

public class Remove_Element {
	public static void shift(int[] a, int size, int pos) {
		if (pos < 0 || pos > size) {
			System.out.println("Invalid pos");
		} else {
			for (int i = pos; i < size; i++) {
				a[i - 1] = a[i];
			}
		}
		for (int i = 0; i < size - 1; i++) {
			System.out.print(a[i] + " ");
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size + 1];
		System.out.println("Enter the elements into array");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("Enter the postion to remove the element");
		int pos = sc.nextInt();
		shift(a, size, pos);
	}
}
