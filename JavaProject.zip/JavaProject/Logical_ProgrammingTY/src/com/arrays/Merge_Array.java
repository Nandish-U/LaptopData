package com.arrays;

import java.util.Scanner;

public class Merge_Array {
	public static void print(int[] a, int[] b, int size) {
		int[] res = new int[a.length + b.length];
		int count = 0;
		for (int i = 0; i < res.length; i++) {
			if (i < a.length) {
				res[i] = a[i];
			} else {
				res[i] = b[count];
				count++;
			}
		}
		for (int i = 0; i < res.length; i++) {
			System.out.print(res[i] + " ");
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		int[] b = new int[size];
		System.out.println("Enter the elements into a");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("Enter the elements into b");
		for (int i = 0; i < size; i++) {
			b[i] = sc.nextInt();
		}
		print(a, b, size);
	}
}
