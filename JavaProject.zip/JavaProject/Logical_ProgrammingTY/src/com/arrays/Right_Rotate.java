package com.arrays;

import java.util.Arrays;
import java.util.Scanner;

public class Right_Rotate {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("enter the number");
		int n = sc.nextInt();
		System.out.println("======================");
		
		for (int j = 1; j <= n; j++) {
			int last = a[size-1];
			for (int i = size-1; i >=0; i--) {
				if(i+1<size)
				{
					a[i+1] = a[i];
				}
			}
			a[0]=last;
		}
		System.out.println(Arrays.toString(a));
	}
}
