package com.arrays;

import java.util.Arrays;
import java.util.Scanner;

public class QuickSort {
	int partition(int[] a, int li, int hi) {
		int start = li;
		int end = hi;
		int pivot = a[li];
		while (start < end) {
			while (a[start] <= pivot && start < a.length - 1) {
				start++;

			}
			while (a[end] > pivot && end >= 0) {
				end--;
			}
			if (start < end) {
				int temp = a[start];
				a[start] = a[end];
				a[end] = temp;
			}
		}
		int temp = a[li];
		a[li] = a[end];
		a[end] = temp;
		return end;
	}

	int[] quickSort(int[] a, int li, int hi) {
		if (li < hi) {
			int l = partition(a, li, hi);
			quickSort(a, li, l - 1);
			quickSort(a, l + 1, a.length - 1);
		}
		return a;
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		System.out.println("Enter size");
		int size = s.nextInt();
		int[] n = new int[size];
		System.out.println("Enter elements");
		for (int i = 0; i < size; i++) {
			n[i] = s.nextInt();
		}

		QuickSort h = new QuickSort();
		// h.quickSort(n, 0, size);
		System.out.println(Arrays.toString(h.quickSort(n, 0, size - 1)));
	}

}
