package com.arrays;

import java.util.Scanner;

public class Shift_Element {
	public static void shift(int[] a, int size, int pos, int ele)
	{
		for(int i=size-2; i>=pos-1; i--)
		{
			a[i+1]=a[i];
		}
		a[pos-1]=ele;
		for(int i=0; i<size; i++)
		{
			System.out.print(a[i]+" ");
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size+1];
		System.out.println("Enter the elements into array");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("Enter the postion to store the element");
		int pos = sc.nextInt();
		System.out.println("Enter the element to store");
		int ele = sc.nextInt();
		shift(a,size,pos,ele);
	}
}
