package com.arrays;

public class Insert_Position {
	public static void merge(int[]a , int []b, int pos)
	{
		int[] res = new int[a.length+b.length];
		int a1 =0;
		int a2=0;
		for(int i=0; i<res.length; i++)
		{
			if(i>=pos-1 && i<=b.length)
			{
				res[i]= b[a1];
				a1++;
			}
			else
			{
				res[i] = a[a2];
				a2++;
			}
		}
		for(int i=0 ;i<res.length; i++)
		{
			System.out.print(res[i]+" ");
		}
	}
	public static void main(String[] args) 
	{
		int[]a = {1,2,3,4};
		int[] b = {5,6,7};
		int pos = 2;
		merge(a,b,pos);
	}
}
