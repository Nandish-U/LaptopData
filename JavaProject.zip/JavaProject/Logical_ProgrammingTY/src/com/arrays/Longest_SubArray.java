package com.arrays;

import java.util.Scanner;

public class Longest_SubArray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("enter the sum");
		int sum = sc.nextInt();

		for (int i = 0; i < size; i++) {
			int count = 0;
			int res = 0;
			for (int j = 0; j < size; j++) {
				res = a[j] + res;
				count++;
				if (res == sum) {
					System.out.println("found");
					break;
				}
			}
		}
	}
}
