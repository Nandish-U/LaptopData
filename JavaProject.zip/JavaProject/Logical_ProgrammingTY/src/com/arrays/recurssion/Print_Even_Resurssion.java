package com.arrays.recurssion;

public class Print_Even_Resurssion {
	public static void print(int i) {
		
		if (i <= 10) {
			if(i%2==0)
			{
			System.out.println(i);
			
			}
			i++;
			print(i);
		}
		
	}
	public static void main(String[] args) {
		print(1);
	}
}
