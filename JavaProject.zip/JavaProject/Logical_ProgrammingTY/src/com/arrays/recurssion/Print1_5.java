package com.arrays.recurssion;

public class Print1_5 {
	public static void print(int i) {
		System.out.println(i);
		i++;
		if (i <= 5) {
			print(i);
		}
	}
	public static void main(String[] args) {
		print(1);
	}
}
