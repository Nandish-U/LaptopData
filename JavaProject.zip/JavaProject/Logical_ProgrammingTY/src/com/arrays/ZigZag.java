package com.arrays;

import java.util.Scanner;

public class ZigZag {
	public static void print(int[] a, int[] b, int size) {
		int[] res = new int[a.length + b.length];
		int i=0; 
		int j=0;
		for(int k=0;k<res.length;)
		{
			if(i<a.length)
			{
				res[k]=a[i];
				i++;
				k++;
			}
//			if(j<b.length)
//			{
//				res[k]=b[j];
//				j++;
//				k++;
//			}
		}
		for (int l = 0; l < res.length; l++) {
			System.out.print(res[i] + " ");
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the 2nd size");
		int size1 = sc.nextInt();
		int[] b = new int[size1];
		System.out.println("Enter the elements into a");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("Enter the elements into b");
		for (int i = 0; i < size1; i++) {
			b[i] = sc.nextInt();
		}
		print(a, b, size);
	}
}
