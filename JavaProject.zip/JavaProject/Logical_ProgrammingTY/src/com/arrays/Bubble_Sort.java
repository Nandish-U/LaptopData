package com.arrays;

import java.util.Scanner;

public class Bubble_Sort {
	public static void print(int[]a , int size)
	{
		for(int i=0; i<size-1;i++)
		{
			int flag = 0;
			for(int j=0; j<size-1-i; j++)
			{
				if(a[j]>a[j+1])
				{
					int temp = a[j];
					a[j] = a[j+1];
					a[j+1] = temp;
					flag = 1;
				}
			}
			if(flag == 0)
			{
				break;
			}
		}
		for(int i=0; i<size; i++)
		{
			System.out.print(a[i]+" ");
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements into array");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		print(a,size);
	}
}
