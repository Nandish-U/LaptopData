package com.arrays;

public class Recurrsion {

	public static void print(int i) {
		System.out.println(i);
		i++;
		if (i <= 5) {
			print(i);
		}
	}
	public static void main(String[] args) {
		print(1);
	}
}
