package com.arrays;

import java.util.Scanner;

public class Unique_Element {
	public static void print(int[] a , int size)
	{
		for(int i=0; i<size; i++)
		{
			for(int j=i+1; j<size; j++)
			{
				if(a[i]==a[j])
				{
					a[j]=-1;
				}
			}
			if(a[i]!=-1)
			{
				System.out.print(a[i]+" ");
			}
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements into array");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		print(a,size);
	}
}
