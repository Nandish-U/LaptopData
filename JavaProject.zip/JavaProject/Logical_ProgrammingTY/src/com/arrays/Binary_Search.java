package com.arrays;

import java.util.Scanner;

public class Binary_Search {
	public static int binarysearch(int[] a, int size, int ele) {
		int l = 0;
		int r = size - 1;
		int mid = 0;
		while (l <= r) {
			mid = (l + r) / 2;
			if (ele == a[mid]) {
				return 0;
			} else if (ele > a[mid]) {
				l = mid + 1;
			} else {
				r = mid - 1;
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements into array");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("Enter the search element");
		int element = sc.nextInt();
		int flag = binarysearch(a, size, element);
		if (flag == 0) {
			System.out.println("element found");
		} else {
			System.out.println("element not found");
		}
	}
}
