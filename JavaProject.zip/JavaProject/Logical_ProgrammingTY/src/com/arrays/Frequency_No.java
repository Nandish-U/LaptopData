package com.arrays;

import java.util.Scanner;

public class Frequency_No {
	public static void frequency(int[] a,int[] b, int size)
	{
		for(int i=0; i<size; i++)
		{
			int count = 1;
			for(int j=i+1; j<size&& b[i]==-1; j++)
			{
				if(a[i]==a[j])
				{
					count++;
					b[j]=0;
				}
			}
			if(b[i]!=0)
			{
				b[i] = count;
			}
		}
		for(int i=0; i<size; i++)
		{
			if(b[i]!=0)
			System.out.println(a[i]+"  1"+b[i]);
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		int[] b = new int[size];
		System.out.println("Enter the elements into array");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
			b[i]=-1;
		}
		frequency(a,b,size);
	}
}
