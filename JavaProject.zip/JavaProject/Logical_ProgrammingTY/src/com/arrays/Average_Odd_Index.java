package com.arrays;

import java.util.Scanner;

public class Average_Odd_Index {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("======================");
		int sum = 0;
		int count=0;
		for (int i = 0; i < size; i++) {
			
			if(i%2==1)
			{
				count++;
			sum += a[i];
			}
		}
		System.out.println(sum / count);
	}
}
