package com.arrays;

import java.util.Scanner;

public class Array_Prime 
{
	public static void prime(int[]a, int size)
	{
		for(int i=0; i<size; i++)
		{
			int count =0;
			for(int j=2;j<=a[i]/2;j++)
			{
				if(a[i]%j==0)
				{
					count++;
					break;
				}
			}
			if(count == 0)
			{
				System.out.print(a[i]+" ");
			}
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements into array");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		prime(a,size);
	}
}
