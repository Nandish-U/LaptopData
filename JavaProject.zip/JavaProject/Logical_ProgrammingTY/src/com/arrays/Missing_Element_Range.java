package com.arrays;

import java.util.Arrays;
import java.util.Scanner;

public class Missing_Element_Range {
//	public static int[] sort(int[] a) {
//		for (int i = 0; i < a.length - 1; i++) {
//			if (a[i] > a[i + 1]) {
//				int temp = a[i];
//				a[i] = a[i + 1];
//				a[i + 1] = temp;
//			}
//		}
//		System.out.print(Arrays.toString(a));
//		return a;
//	}

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements");
		for(int i=0; i<a.length; i++)
		{
			a[i] = sc.nextInt();
		}
		Arrays.sort(a);
		int j=0;
		int min = a[0];
		int max = a[a.length-1];
		for(int i=min; i<max; i++)
		{
			if(a[j]!=i)
			{
				System.out.print(i+" ");
			}
			else
			{
				j++;
			}
		}
	}
}
