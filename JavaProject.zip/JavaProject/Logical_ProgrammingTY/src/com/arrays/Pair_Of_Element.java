package com.arrays;

import java.util.Scanner;

public class Pair_Of_Element {
	public static void pair(int[] a, int size, int ele) {
		int sum = 0;
		for (int i = 0; i < size; i++) {
			for (int j = i + 1; j < size; j++) {
				sum = a[i] + a[j];
				if (sum == ele) {
					System.out.println(a[i] + " " + a[j]);
				}
			}
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements into array");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("Enter the element to search");
		int ele = sc.nextInt();
		pair(a, size,ele);
	}
}
