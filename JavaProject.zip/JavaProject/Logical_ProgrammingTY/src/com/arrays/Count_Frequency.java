package com.arrays;

import java.util.Scanner;

public class Count_Frequency {
	public static void frequency(int[] a, int size) {
		for (int i = 0; i < size; i++) {
			int count = 1;
			for (int j = i + 1; j < size; j++) {
				if (a[i] == a[j]) {
					count++;
					a[j] = -1;
				}
			}
			if (a[i] != -1) {
				System.out.println(a[i] + " " + count);
			}
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements into array");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		frequency(a, size);
	}
}
