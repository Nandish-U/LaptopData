package com.arrays;

import java.util.Scanner;

public class Copy_Element 
{
	public static void copy(int [] a, int size)
	{
		int[] res = new int[size];
		for(int i=0; i<size; i++)
		{
			res[i] = a[i];
		}
		for(int i=0; i<res.length; i++)
		{
			System.out.print(res[i]+" ");
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements into a");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		copy(a, size);
	}
}
