package com.arrays;

import java.util.Scanner;

public class Reverse_Element 
{
	public static void reverse(int[]a, int size)
	{
		for(int i=0; i<size; i++)
		{
			int sum = 0;
			while(a[i]!=0)
			{
				int rem = a[i]%10;
				 sum = (sum*10)+rem;
				a[i]=a[i]/10;
			}
			a[i]=sum;
			System.out.print(a[i]+" ");
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements into array");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		reverse(a,size);
	}
}
