package com.arrays;

import java.util.Scanner;

public class Largest_Element {
	public static void largest(int[] a, int size) {
		int max=a[0];
		for(int i=0; i<size; i++)
		{
			if(a[i]>max)
			{
				max = a[i];
			}
		}
		System.out.println(max);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements into array");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		largest(a,size);
	}
}
