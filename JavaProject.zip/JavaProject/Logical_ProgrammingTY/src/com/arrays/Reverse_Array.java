package com.arrays;

import java.util.Arrays;
import java.util.Scanner;

public class Reverse_Array 
{
	public static void reverse(int[] a, int size) {
		for(int i = size-1; i>=0; i--)
		{
			System.out.print(a[i]+" ");
		}
	}
	public static void reverse1(int[]a, int size)
	{
		int l = 0;
		int r = size-1;
		while(l<r)
		{
				int temp = a[l];
				a[l]= a[r];
				a[r]= temp;
				l++;
				r--;
		}
		System.out.println(Arrays.toString(a));
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements into array");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		reverse1(a,size);
		int[] b = new int[size];
		int j = size-1;
		for(int i=0; i<size; i++)
		{
			b[j]= a[i];
			j--;
		}
	}
}
