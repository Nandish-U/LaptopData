package com.arrays;

public class Pattren {
public static void main(String[] args) {
	int n=6;
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=n;j++) {
			if(j==1||i==n||j==n||i==1 ) {
				System.out.print(" 1 ");
			}else if(i==2||j==2||i==n-1||j==n-1) {
				System.out.print(" a ");
			}else{
				System.out.print(" 3 ");
			}
		}
		System.out.println(  );
	}
}
}
