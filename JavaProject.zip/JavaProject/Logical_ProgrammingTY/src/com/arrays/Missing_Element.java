package com.arrays;

import java.util.Arrays;
import java.util.Scanner;

public class Missing_Element {
	public static int[] sort(int[] a )
	{
		for(int i=0; i<a.length-1; i++)
		{
			if(a[i]>a[i+1])
			{
				int temp = a[i];
				a[i] = a[i+1];
				a[i+1] = temp;
			}
		}
		System.out.print(Arrays.toString(a));
		return a;
	}
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements");
		for(int i=0; i<a.length; i++)
		{
			a[i] = sc.nextInt();
		}
		int[] res = sort(a);
		int j=a[0];
		for(int i=0; i<res.length; i++)
		{
			if(a[i]!=j)
			{
				System.out.println(j);
				break;
			}
			j++;
		}
	}
}
