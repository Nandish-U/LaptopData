package com.arrays;

import java.util.Scanner;

public class Second_Largest {

	public static void Second_Max(int[]a, int size)
	{
		int max =a[0];
		int max2 =0; 
		for(int i=0; i<size; i++)
		{
			if(a[i]>max)
			{
				max2=max;
				max=a[i];
				
			}
			else if(max<a[i] && max!=a[i])
			{
				max2 = a[i];
			}
		}
		System.out.println(max2);
	}
//	public static void largest(int[] a, int size) {
//		for(int i=0;i<size; i++)
//		{
//			for(int j=i+1; j<size; j++)
//			{
//				if(a[i]>a[j])
//				{
//					int temp = a[i];
//					a[i]= a[j];
//					a[j]= temp;
//				}
//			}
//		}
//		System.out.println(a[size-2]);
//	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements into array");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		Second_Max(a, size);
	}
}
