package com.arrays;

public class Array_Palindrome {
	public static void main(String[] args) 
	{
		int[] a = {10,20,10};
		int l=0;
		int r =a.length;
		boolean flag = true;
		for(int i=0; i<a.length/2; i++)
		{
			if(a[i]!=a[r-1])
			{
				flag = false;
			}
		}
		if(flag == true)
		{
			System.out.println("Palindrome");
		}
		else
		{
			System.out.println("Not a palindrome");
		}
	}
}
