package com.arrays;

import java.util.Scanner;

public class Compare_2Array {
	public static void check(int[] a, int[] b) {
		int count = 0;
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < b.length; j++) {
				if (a[i] == b[j]) {
					count++;
					
				}
			}
		}
		if (count == a.length) {
			System.out.println("a is subset of b");
		} else if (count == b.length) {
			System.out.println("b is subste of a");
		} else {
			System.out.println("a is not a subset of b");
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		System.out.println("Enter the size");
		int size1 = sc.nextInt();
		int[] a = new int[size];
		
		int[] b = new int[size1];
		System.out.println("Enter the elements into a");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("Enter the elements into b");
		for (int i = 0; i < size1; i++) {
			b[i] = sc.nextInt();
		}
		check(a, b);
	}
}
