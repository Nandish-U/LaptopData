package com.arrays;

import java.util.Scanner;

public class Highest_Sum 
{	
	public static void highest(int[]a, int size)
	{
		int sum = 0;
		for(int i=0; i<size; i++)
		{
			for(int j=i+1; j<size; j++)
			{
				if(a[i]+a[j]>sum)
				{
					sum = a[i]+a[j];
				}
			}
			
		}
		System.out.println(sum);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = sc.nextInt();
		int[] a = new int[size];
		System.out.println("Enter the elements into array");
		for (int i = 0; i < size; i++) {
			a[i] = sc.nextInt();
		}
		highest(a,size);
	}
}
