package com.pattern;

public class Name_Shree {

	static int power(int base, int power) {
		int res = 1;
		for (int i = 1; i <= power; i++) {
			res = res * base;
		}
		return res;
	}

	static void printJ() {
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 4; j++) {
				if (i == 4 && j == 2 || j == 3 || i == 3 && j == 2) {
					System.out.print("J ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 3; j++) {
				if (i == 1 && j == 1 || i == 1 && j == 3 || i == 2 && j == 2 || i == 4 && j == 2) {
					System.out.print("  ");
				} else {
					System.out.print("A ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 3; j++) {
				if (i == 1 && j == 1 || i == 1 && j == 3 || j == 2 && i != 1) {
					System.out.print("Y ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 3; j++) {
				if (i == 1 && j == 1 || i == 1 && j == 3 || i == 2 && j == 2 || i == 4 && j == 2) {
					System.out.print("  ");
				} else {
					System.out.print("A ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 3; j++) {
				if (i == 2 && j == 2 || i == 2 && j == 3 || i == 4 && j == 1 || i == 4 && j == 2) {
					System.out.print("  ");
				} else {
					System.out.print("S ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 3; j++) {
				if (i == 3 || j == 1 || j == 3) {
					System.out.print("H ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 4; j++) {
				if (i == 2 && j == 2 || i == 4 && j == 2 || i == 5 && j == 2 || i == 5 && j == 3 || j == 4 && i != 5) {
					System.out.print("  ");
				} else {
					System.out.print("R ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 3; j++) {
				if (i == 1 || j == 1 || i == 3 || i == 5) {
					System.out.print("E ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");

		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 3; j++) {
				if (i == 1 || j == 1 || i == 3 || i == 5) {
					System.out.print("E ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		// System.out.println(power(2,3));
		printJ();
		// int res = (int)Math.pow(2, 3);
		// System.out.println(res);
	}
}
