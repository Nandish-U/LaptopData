package com.pattern;

public class Hallow_Pyramid {
	public static void main(String[] args) 
	{
		int n=4;
		for(int i=1;i<=n; i++)
		{
			for(int j=1; j<-n*2; j++)
			{
				if(i+j==n+1|| j-i==n-1 || i==n)
				{
					System.out.print("* ");
				}
				else
				{
					System.out.print("  ");
				}
			}
			System.out.println();
		}
//		for(int i=1; i<=5; i++)
//			{
//				for(int j=1; j<=3; j++)
//				{
//					if(j+i>5)
//					{
//						System.out.print("* ");
//					}
//					else
//					{
//						System.out.print("  ");
//					}
//				}
//				System.out.println();
//			}
//		for(int i=4; i>=1; i--)
//		{
//			for(int j=1; j<=3; j++)
//			{
//				if(j+i>5)
//				{
//					System.out.print("* ");
//				}
//				else
//				{
//					System.out.print("  ");
//				}
//			}
//			System.out.println();
//		}
	}
}
