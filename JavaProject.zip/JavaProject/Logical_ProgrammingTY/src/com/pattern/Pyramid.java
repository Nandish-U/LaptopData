package com.pattern;

public class Pyramid {

	public static void main(String[] args) {
		int n = 3;
		for (int i = 1; i <= 3; i++) {
			for (int j = 1; j < n + i; j++) {
				if (j > n - i) {
					System.out.print("* ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		// right side pyramid
//		int n=3;
		System.out.println("\t");
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= n; j++) {
				if (i + j >= n + 1 && i <= n || i - j <= n - 1 && i > n) {
					System.out.print("* ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
		// right pyramid
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= n; j++)
			{
				if (j <= i && i <= n || i + j <= n * 2 && i > n) {
					System.out.print("* ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
		for(int i=1;i<n*2;i++)
		{
			for(int j=1;j<n+i;j++)
			{
				if( j>n-i && i-j<=2 && i+j<=n*3-1)
//				if(i+j>=8 && j>=3)
				{
					System.out.print("* ");
				}
				else
				{
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
		//Hallow diamond
		for(int i=1; i<n*2; i++)
		{
			for(int j=1; j<n*2; j++)
			{
				if(i+j==n+1 || i-j==n-1 || j-i==n-1
						|| i+j==n*3-1)
				{
					System.out.print("* ");
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
		//Rombus
		for(int i=1 ; i<=n;i++)
		{
			for(int j=1; j<n*2 ;j++)
			{
				if(i+j>=n+1 && i+j<=n*2)
				{
					System.out.print("* ");
				}
				else
				{
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
		for(int i=1 ; i<=n;i++)
		{
			for(int j=1; j<n*2 ;j++)
			{
				if(i+j==n+1 || i+j==n*2 || i==n&&j<=n || i==1&&j>n)
				{
					System.out.print("* ");
				}
				else
				{
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
		for(int i=1 ; i<=n;i++)
		{
			for(int j=1; j<n*2 ;j++)
			{
//				if(i<=j && j-i<=n-1)
//				{
//					System.out.print("* ");
//				}
				if(j-i>=0 && j-i<=2)
				{
					System.out.print("* ");
				}
				else
				{
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
//		int row = 6;       
//		for (int i=0; i<row; i++)   
//		{  
//			for (int j=row-i; j>1; j--)   
//			{  
//				System.out.print(" ");   
//			}   
//			for (int j=0; j<=i; j++ )   
//				
//			{   
//				System.out.print("* ");   
//			}   
//			System.out.println();   
//		}   
	}

}
