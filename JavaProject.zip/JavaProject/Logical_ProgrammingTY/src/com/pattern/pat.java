package com.pattern;

public class pat {
	public static void main(String[] args) {
		int n = 7;
		char ch = 'a';
int d=1;
		for (int i = 1; i < n+1; i++) {

			for (int j = 1; j < n+1; j++) {

				if (i % 2 == 0) {
					System.out.print(ch);
					
				} else {
					System.out.print(d);
					

				}
				
			}
			System.out.println();
			//++ch;
			//d++;			
			
		}
	}
}