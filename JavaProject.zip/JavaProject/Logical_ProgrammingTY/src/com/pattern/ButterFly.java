package com.pattern;

public class ButterFly {
	public static void main(String[] args) 
	{
		int n=3;
		for(int i=1; i<n*2; i++)
		{
			for(int j=1; j<n*2; j++)
			{
				if(i>=j && i<=n ||i<=n && i+j>=n*2 || i+j<=n*2 && i>n ||j>=i && i>n  )
				{
					System.out.print("* ");
				}
				else
				{
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
		for(int i=1; i<n*2; i++)
		{
			for(int j=1; j<n*2; j++)
			{
				if(i==j && i<=n ||i<=n && i+j==n*2 || i+j==n*2 && i>n ||j==i && i>n || j==1 || j==n*2-1  )
				{
					System.out.print("* ");
				}
				else
				{
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
		
		for(int i=1; i<n*2; i++)
		{
			for(int j=1; j<n*2; j++)
			{
				if(i==j && i<=n ||i<=n && i+j==n*2 || i+j==n*2 && i>n ||j==i && i>n || j==1 || j==n*2-1 || i==1 ||i==n*2-1  )
				{
					System.out.print("* ");
				}
				else
				{
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
		
		for(int i=1; i<=n; i++)
		{
			for(int j=1; j<n*2; j++)
			{
				if(i+j<=n+1 || j-i>=n-1)
				{
					System.out.print("* ");
				}
				else
				{
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
		
		for(int i=1; i<n*2; i++)
		{
			for(int j=1; j<=n; j++)
			{
				if(i+j<=n+1 || i-j>=n-1)
				{
					System.out.print("* ");
				}
				else
				{
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\t");
	}
}
