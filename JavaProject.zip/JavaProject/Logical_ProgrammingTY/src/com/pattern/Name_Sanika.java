package com.pattern;

public class Name_Sanika {
	public static void name()
	{
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 3; j++) {
				if (i == 2 && j == 2 || i == 2 && j == 3 || i == 4 && j == 1 || i == 4 && j == 2) {
					System.out.print("  ");
				} else {
					System.out.print("S ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 3; j++) {
				if (i == 1 && j == 1 || i == 1 && j == 3 || i == 2 && j == 2 || i == 4 && j == 2||
						i==5&&j==2) {
					System.out.print("  ");
				} else {
					System.out.print("A ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 3; j++) {
				if (i==1 && j==2 || i==2&&j==2 ||i==4&&j==2 || i==5&&j==2) {
					System.out.print("  ");
				} else { 
					System.out.print("N ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 3; j++) {
				if (i == 1 || j==2 || i==5  ) {
					System.out.print("* ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 4; j++) {
				if (i==1&& j==2 || i==2&&j==2 || i==1&&j==3 || i==2 &&j==4 ||
						i==3&&j==3 || i==3&&j==4 || i==4 &&j==2 ||
						i==4 && j==4 || i==5&&j==2 || i==5&&j==3) {
					System.out.print("  ");
				} else {
					System.out.print("k ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 3; j++) {
				if (i == 1 && j == 1 || i == 1 && j == 3 || i == 2 && j == 2 || i == 4 && j == 2 ||
						i==5&&j==2) {
					System.out.print("  ");
				} else {
					System.out.print("A ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");
	}
	public static void main(String[] args) 
	{
		name();
	}
}
