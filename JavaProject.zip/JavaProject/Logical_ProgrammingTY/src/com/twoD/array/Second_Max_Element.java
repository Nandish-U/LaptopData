package com.twoD.array;

import java.util.Scanner;

public class Second_Max_Element {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the rows");
		int r = s.nextInt();
		System.out.println("Enter the colums");
		int c = s.nextInt();
		int[][] a = new int[r][c];
		System.out.println("Enter the elements");
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				a[i][j] = s.nextInt();
			}
		}
		System.out.println("Printing 2D Array");
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				System.out.print(a[i][j] + " ");

			}
			System.out.println();
		}
		System.out.println("=============================");
		int max = a[0][0];
		int max2= a[0][0];
//		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				for (int m = 0; m < r; m++) {
					for (int n = 0; n < c; n++) {
						if (a[m][n] > max) {
							max = a[m][n];
						}
						if(a[m][n]>max2 && a[m][n]<max )
						{
							max2= a[m][n];
						}	
					}
				}
//			}
		}
		System.out.println(max+" ");
		System.out.println(max2+" ");
	}
}
