package com.twoD.array;

import java.util.Scanner;

public class Reverse_Each_Row {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the rows");
		int r = s.nextInt();
		System.out.println("Enter the columns");
		int c = s.nextInt();
		int[][] a = new int[r][c];
		System.out.println("Enter the elements");
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				a[i][j] = s.nextInt();
			}
		}
		
		System.out.println("Printing elements");
		for(int i=0; i<r; i++)
		{
			for(int j=0; j<c; j++)
			{
				System.out.print(a[i][j]+" ");

			}
			System.out.println();
		}
		System.out.println("==================================");

		for (int i = 0; i < r/2; i++) {
			
	        int start = 0;
	        int end = c - 1;
	
	        while (start < end) {
	            int temp = a[i][start];
	            a[i][start] = a[i][end];
	            a[i][end] = temp;
	            start++;
	            end--;
	        }
	    }
		
		for(int i=0; i<r; i++)
		{
			for(int j=0; j<c; j++)
			{
				System.out.print(a[i][j]+" ");

			}
			System.out.println();
		}
	}


}
