package com.twoD.array;

import java.util.Scanner;

public class Count_Frequency {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the row size");
		int row = sc.nextInt();
		System.out.println("Enter the col size");
		int col = sc.nextInt();
		int[][] a = new int[row][col];
		System.out.println("Enter the elements");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				a[i][j] = sc.nextInt();
			}
		}
		System.out.println("=====================");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("==================");
				for (int i = 0; i < row; i++) {
					for (int j = 0; j < col; j++) {
						int p = a[i][j];
						int count=1;
						for (int k = 0; k < row; k++) {
							for (int l = k + 1; l < col; l++) {
								if (p == a[k][l]) {
									count++;
									a[k][l] = -1;
								}
								
							}
						}
						System.out.print(count+" ");
					}
				}
		
		System.out.println("======================================================");
		
		
		
		
		
		
		
		
		int k =0;
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				int c=0;
				k=a[i][j];
				for (int m = 0; m < row; m++) {
					for (int n = 0; n < col; n++) {
						if(a[m][n]==k)
						{
							c++;
							if(c>1)
							{
								a[m][n]='a';
							}
						}
					}

				}
				if(a[i][j]!='a')
				System.out.println("frequency of "+a[i][j]+" is "+c);
			}
		}
	}
}
