package com.twoD.array;

import java.util.Scanner;

public class Method_Accepting_2dArray {
	static void m1(int a[][], int r, int c) {
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				System.out.print(a[i][j] + " ");

			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the rows");
		int r = s.nextInt();
		System.out.println("Enter the columns");
		int c = s.nextInt();
		int[][] a = new int[r][c];
		System.out.println("Enter the elements");
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				a[i][j] = s.nextInt();
			}
		}
		m1(a, r, c);
	}

}
