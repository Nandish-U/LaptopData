package com.twoD.array;

import java.util.Scanner;

public class Indentity_Matrix {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the row size");
		int row = sc.nextInt();
		System.out.println("Enter the col size");
		int col = sc.nextInt();
		int[][] a = new int[row][col];
		System.out.println("Enter the elements");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				a[i][j] = sc.nextInt();
			}
		}
		System.out.println("=====================");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("==================");
		int f=0;
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				if (i == j && a[i][j] == 1 || i != j && a[i][j] == 0) {
					f++;			
				}  
			}
		}
		if (f== row*col) {
			System.out.println("Identity");
		}
		else {
			System.out.println("Not identity");
		}
	}
}
