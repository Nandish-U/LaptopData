package com.twoD.array;

import java.util.Scanner;

public class FrequencyCount {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the rows");
		int r = s.nextInt();
		System.out.println("Enter the colums");
		int c = s.nextInt();
		int[][] a = new int[r][c];
		System.out.println("Enter the elements");
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				a[i][j] = s.nextInt();
			}
		}

		System.out.println("Printing 2D Array");
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("=============================");
		int temp = 0;
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				temp = a[i][j];
				int count = 0;
				for (int m = 0; m < r; m++) {
					for (int n = 0; n < c; n++) {
						if (temp == a[m][n]) {
							count++;
							if (count > 1)
								a[m][n] = 'a';
						}
					}
				}
				if (a[i][j] != 'a')
					System.out.println("count of " + a[i][j] + " ->" + count);
			}

		}
	}

}
