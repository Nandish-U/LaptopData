package com.twoD.array;

import java.util.Scanner;

public class Matrix_Multiplication {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the row size");
		int row = sc.nextInt();
		System.out.println("Enter the col size");
		int col = sc.nextInt();
		int[][] a = new int[row][col];
		int[][] b = new int[row][col];
		System.out.println("Enter the elements");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				a[i][j] = sc.nextInt();
			}
		}
		System.out.println("Enter the elements");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				b[i][j] = sc.nextInt();
			}
		}
		System.out.println("Enter the first row to swap");
		int r1 = sc.nextInt();
		System.out.println("Enter the first col to swap");
		int c1 = sc.nextInt();
		System.out.println("Enter the second row to swap");
		int r2 = sc.nextInt();
		System.out.println("Enter the second col to swap");
		int c2 = sc.nextInt();

		System.out.println("==================");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("==================");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				System.out.print(b[i][j] + " ");
			}
			System.out.println();
		}
		int[][] c = new int[row][col];
		System.out.println("===========================");
		for (int i = 0; i < r1; i++) {
			for (int j = 0; j < c2; j++) {
				c[i][j] = 0;
				for (int k = 0; k < c1; k++) {
					c[i][j] = c[i][j] + a[i][k] * b[k][j];
				}
			}
		}
		System.out.println("==================");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				System.out.print(c[i][j] + " ");
			}
			System.out.println();
		}
	}
}
