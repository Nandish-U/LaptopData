package com.twoD.array;

import java.util.Scanner;

public class Max_Min_Diff {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the row size");
		int row = sc.nextInt();
		System.out.println("Enter the col size");
		int col = sc.nextInt();
		int[][] a = new int[row][col];
		System.out.println("Enter the elements");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				a[i][j] = sc.nextInt();
			}
		}
		int max = a[0][0];
		int min = a[0][0];
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				if (max < a[i][j]) {
					max = a[i][j];
				}
				if (min > a[i][j]) {
					min = a[i][j];
				}
			}
		}
		System.out.println(max);
		System.out.println(min);
		System.out.println(max - min);
	}
}
