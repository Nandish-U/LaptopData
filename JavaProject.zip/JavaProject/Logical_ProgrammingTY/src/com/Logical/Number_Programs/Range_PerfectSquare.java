package com.Logical.Number_Programs;

public class Range_PerfectSquare {
	public static void main(String[] args) {
		for (int i = 1; i <= 20; i++) {
			int res = (int) Math.sqrt(i);
			if (res * res == i) {
				System.out.print(i+" ");
			}
		}
	}
}
