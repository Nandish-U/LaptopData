package com.Logical.Number_Programs;

public class Prime_Within_Range 
{
	public static void main(String[] args) 
	{
		int a=1;
		int b=10;
		if(a==1)
			a++;
		for(int i=a;i<=b;i++)
		{
			int count =0;
			for(int j=2;j<=i/2;j++)
			{
				if(i%j==0)
				{
					count++;
					break;
				}
			}
			if(count == 0)
			{
				System.out.println(i+" ");
			}
		}
	}
}
