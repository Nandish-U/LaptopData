package com.Logical.Number_Programs;

public class Average 
{
	public static void main(String[] args) 
	{
		int count =0;
		int sum =0;
		int num = 5672;
		while(num!=0)
		{
			int rem = num%10;
			count++;
			sum = sum+rem;
			num = num/10;
		}
		System.out.println(sum/count);
	}
}
