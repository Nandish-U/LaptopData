package com.Logical.Number_Programs;

public class Askey_Number 
{
	public static void main(String[] args) 
	{
		char a1;
		for( a1='a'; a1<='z'; a1++)
		{
			System.out.println(a1+" - "+(int)a1);	
		}
	}
}
