package com.Logical.Number_Programs;

public class Duck_Number 
{
	public static void main(String[] args) 
	{
		int num =2250;
		int a=1;
		while(num>=1)
		{
			int rem = num%10;
			if(rem==0)
			{
				a=rem;
			}
				num = num/10;	
		}
		if(a==0)
		{
			System.out.println("Duck Number");
		}
		else
		{
			System.out.println("not a duck number");
		}
	}
}
