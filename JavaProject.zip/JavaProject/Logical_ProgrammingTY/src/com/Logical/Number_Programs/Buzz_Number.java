package com.Logical.Number_Programs;

public class Buzz_Number 
{
	public static void main(String[] args) 
	{
		int num =49;
		if(num%10==7 || num%7==0)
		{
			System.out.println("Buzz Number");
		}
		else
		{
			System.out.println("Not a buzz Number");
		}
	}
}
