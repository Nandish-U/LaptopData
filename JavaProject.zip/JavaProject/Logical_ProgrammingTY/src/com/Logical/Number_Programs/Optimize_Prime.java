package com.Logical.Number_Programs;

public class Optimize_Prime 
{
	public static void main(String[] args) 
	{
		int num =97;
		int count =0;
		if(num ==0 || num ==1)
		{
			System.out.println("Not a prime number");
		}
		else
		{
			for(int i=2; i<Math.sqrt(num); i++)
			{
				if(num%i==0)
				{
					count++;
				}
			}
			if(count == 0)
			{
				System.out.println("is a prime number");
			}
			else
			{
				System.out.println("is not a prime number");
			}
		}
	}
}
