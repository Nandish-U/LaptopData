package com.Logical.Number_Programs;

public class Sunny_Number 
{
	public static void main(String[] args) 
	{
		int n=8;
		int a=1;
		int b = n+1;
		System.out.println(b);
		for(int i=1; i<=b; i++)
		{
			if(i*i == b)
			{
				a=i*i;
			}
		}
		System.out.println(a);
		if(a==b)
		{
			System.out.println("Sunny number");
		}
		else
		{
			System.out.println("Not a sunny number");
		}
	}
}
