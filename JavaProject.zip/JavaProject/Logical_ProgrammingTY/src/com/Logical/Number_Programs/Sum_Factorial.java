package com.Logical.Number_Programs;

class $
{
	
}
public class Sum_Factorial 
{
	public static void main(String[] args) 
	{
		int num=5;
		int sum=0;
		for(int i =num; i>=1; i--)
		{
			sum = sum+i;
		}
		System.out.println(sum);
	}
}
