package com.Logical.Number_Programs;

public class Arm_Strong_Number 
{
	public static void main(String[] args) 
	{
		int num = 153;
		int num1 =num;
		int num2=num;
		int count =0;
		int res=0;
		while(num!=0)
		{
			int rem = num%10;
			count++;
			num = num/10;
		}
		while(num1!=0)
		{
			int fact =1;
			int rem = num1%10;
//			res = res+(int)Math.pow(rem, count);
			for(int i=1; i<=count; i++)
			{
				fact = fact*rem;
			}
			res = res+fact;
			num1 = num1/10;
		}
		if(res == num2)
		{
			System.out.println("Armstrong Number");
		}
		else
		{
			System.out.println("Not a arm strong number");
		}
		
		
	}
}
