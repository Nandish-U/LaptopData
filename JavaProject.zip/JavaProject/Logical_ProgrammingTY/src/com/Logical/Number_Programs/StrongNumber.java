package com.Logical.Number_Programs;

public class StrongNumber {
	public static void main(String[] args) 
	{
		int num =145;
		int sum =0;
		int temp = num;
		
		while(num!=0)
		{
			int pro = 1;
			int rem = num%10;
			for(int i=1;i<=rem;i++)
			{
				pro = pro*i;
			}
			sum = sum+pro;
			num = num/10;
		}
		if(sum == temp)
		{
			System.out.println("Strong number");
		}
		else
		{
			System.out.println("Weak number");
		}
		
	}
}
