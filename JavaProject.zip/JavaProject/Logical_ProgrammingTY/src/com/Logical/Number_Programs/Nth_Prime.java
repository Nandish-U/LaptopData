package com.Logical.Number_Programs;

public class Nth_Prime 
{
	public static void main(String[] args) 
	{
		int n=5;
		int res =0;
		int p=0;
		for(int i=2; ; i++)
		{
			int count =0;
			for(int j=2; j<i;j++)
			{
				if(i%j==0)
				{
					count++;
				}
			}
			if(count ==0)
			{
				res=i;
				p++;
			}
			if(p==n)
			{
				break;
			}
		}
		System.out.println(res);
	}
}
