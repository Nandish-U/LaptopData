package com.Logical.Number_Programs;

public class Xylem_Pholem_Number 
{
	public static void check()
	{
		int n = 1234;
		int last = n%10;
		n = n/10;
		int is=0;
		while(n>9)
		{
			int rem1 = n%10;
			is = is+rem1;
			n =n/10;
		}
		int os = last+n;
		if(os==is)
		{
			System.out.println("Xylem");
		}
		else
		{
			System.out.println("Pholem");
		}
	}
	public static void main(String[] args) 
	{
//		int n = 2323;
//		int rem = n%10;
//		System.out.println(rem);
//		n = n/10;
//		int rev=0;
//		int sum=0;
//		while(n!=0)
//		{
//			int rem1 = n%10;
//			rev = rev*10+rem1;
//			n = n/10;
//		}
//		int pp=rev%10;
//		rev = rev/10;
//		while(rev!=0)
//		{
//			int rem1 = n%10;
//			sum = sum+rem1;
//			rev = rev/10;
//		}
//		int sum1= rem+pp;
//		if(sum == sum1)
//		{
//			System.out.println("Xylem number");
//		}
//		else
//		{
//			System.out.println("Pholem Number");
//		}
		check();
		
	}
}