package com.Logical.Number_Programs;

public class Check_Prime 
{
	public static void main(String[] args) 
	{
		int num =97;
		int count =0;
		for(int i=1; i<=num; i++)
		{
			if(num%i==0)
			{
				count++;
			}
		}
		if(count ==2)
		{
			System.out.println("Prime no");
		}
	
	}
}
