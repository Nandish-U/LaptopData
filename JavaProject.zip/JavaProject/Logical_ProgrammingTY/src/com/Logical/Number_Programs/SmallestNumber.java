package com.Logical.Number_Programs;

public class SmallestNumber 
{
	public static void main(String[] args) 
	{
		int num=8569548;
		int min =num%10;
		num = num/10;
		while(num!=0)
		{
			int rem=num%10;
			if(rem<min)
			{
				min = rem;
			}
			num = num/10;
		}
		System.out.println(min);
	}
}
