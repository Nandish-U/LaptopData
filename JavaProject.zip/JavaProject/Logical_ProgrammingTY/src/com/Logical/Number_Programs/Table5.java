package com.Logical.Number_Programs;

public class Table5 
{
	public static void main(String[] args) 
	{
		int num=5;
		for(int i=1; i<=10;i++)
		{
			System.out.println(num +" * "+i+" = "+num*i);
		}
	}
}
