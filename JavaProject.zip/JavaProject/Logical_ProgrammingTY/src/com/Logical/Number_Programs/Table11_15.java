package com.Logical.Number_Programs;

public class Table11_15 {
	public static void main(String[] args) 
	{

//		for(int j=11; j<=15; j++)
//		{
//			for(int i = 1;i<=10;i++)
//			{
//				System.out.println(j + " * " + i + " = " + j * i);
//			}
//			System.out.println();
//		}
		for(int i=1; i<=10;i++)
		{
			System.out.println(11 +" * "+ i +" = " +11*i+"\t"+12+" * "+i+" = "+12*i+" \t"+13 +" * "+i+" = "+13*i+"\t"+14 +" * "+i+" = "+14*i+" \t "+ 15 +" * "+i+" = "+15*i+" \t");
		}
	}
}

