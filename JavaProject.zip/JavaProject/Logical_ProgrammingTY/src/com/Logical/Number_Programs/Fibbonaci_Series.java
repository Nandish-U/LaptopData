package com.Logical.Number_Programs;

public class Fibbonaci_Series 
{
	public static void main(String[] args) 
	{
		int n1 = 0;
		int n2 = 1;
		int n5 = 0;
		for(int i=1;i<=8 ; i++)
		{
			int n3 = n1+n2;
			n1=n2;
			n2=n3;
			n5 = n3;
		}
		System.out.println(n5);
		int a=10;
		int b=20;
		double res =a+b;
		System.out.println(res);
	}
}
