package com.Logical.Number_Programs;

public abstract class RemoveLast 
{
	public static void main(String[] args) 
	{
		int num = 56892;
		int res = num/10;
		System.out.println(res);
	}
}
