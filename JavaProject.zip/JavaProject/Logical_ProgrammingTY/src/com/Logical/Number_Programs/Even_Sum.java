package com.Logical.Number_Programs;

public class Even_Sum 
{
	public static void main(String[] args) 
	{
		int sum =0;
		for(int i=11; i<=20;i++)
		{
			if(i%2==0)
			{
				sum = sum+i;
			}
		}
		System.out.println(sum);
	}
}
