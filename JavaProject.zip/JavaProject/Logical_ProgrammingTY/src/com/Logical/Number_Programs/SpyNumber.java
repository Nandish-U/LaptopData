package com.Logical.Number_Programs;

public class SpyNumber 
{
	public static void spy(int num)
	{
		int sum = 0;
		int pro = 1;
		while(num!=0)
		{
			int rem = num%10;
			sum = sum+rem;
			pro = pro*rem;
			num = num/10;
		}
		if(sum == pro)
		{
			System.out.println("spy number");
		}
		else
		{
			System.out.println("not a spy number");
		}
	}
	public static void main(String[] args) 
	{
		spy(1234);
	}
}
