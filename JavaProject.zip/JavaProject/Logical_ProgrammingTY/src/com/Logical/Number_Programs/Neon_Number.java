package com.Logical.Number_Programs;

public class Neon_Number 
{
	public static void main(String[] args) 
	{
		int n=8;
		int pro = n*n;
		int sum =0;
		while(pro!=0)
		{
			int rem = pro%10;
			sum = sum+rem;
			pro = pro/10;
		}
		if(sum == n)
		{
			System.out.println("Neon number");
		}
		else
		{
			System.out.println("Not a neon number");
		}
	}
}
