package com.Logical.Number_Programs;

public class Square_Root_Double 
{
	public static void main(String[] args) 
	{
		int b = 8;
		double res  = Math.sqrt(b);
		for(double i=0.10000000; i<10.9000000; i++)
		{
			if(i*i == b)
			{
				System.out.println(i*i);
			}
		}
	}
}
