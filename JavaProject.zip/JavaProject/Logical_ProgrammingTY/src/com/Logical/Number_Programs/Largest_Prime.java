package com.Logical.Number_Programs;

public class Largest_Prime {
	public static void main(String[] args) {
		int res = 0;
		for (int i = 10; i >= 2; i--) {
			int count = 0;
			for (int j = 2; j < i; j++) {
				if (i % j == 0) {
					count++;
				}
			}
			if (count == 0) {
				res++;
			}
			if (res == 1) {
				System.out.println(i);
				break;
			}
		}

	}
}
