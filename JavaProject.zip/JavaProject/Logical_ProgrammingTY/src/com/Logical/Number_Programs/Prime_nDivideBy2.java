package com.Logical.Number_Programs;

public class Prime_nDivideBy2 
{
	public static void main(String[] args) 
	{
		int num = 7;
		int count =0;
		if(num ==0 || num==1)
		{
			System.out.println("not a prime number");
		}
		else
		{

			for(int i=2;i<=num/2; i++)
			{
				if(num%i==0)
				{
					count=1;
					break;
				}
			}
			if(count ==0)
			{
				System.out.println("Prime number");
			}
			else
			{
				System.out.println("Not a prime number");
			}
		}
	}
}
