package com.Logical.Number_Programs;

public class Divisible_3 
{
	public static void main(String[] args) 
	{
		for(int i=91; i<=100; i++)
		{
			if(i%3==0)
			{
				System.out.print(i+" ");
			}
		}
	}
}
