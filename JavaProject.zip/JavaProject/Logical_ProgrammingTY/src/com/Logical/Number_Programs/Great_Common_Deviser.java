package com.Logical.Number_Programs;

public class Great_Common_Deviser {
	public static void common(int a, int b) {
		while (a != b) {
			if (a > b) {
				a = a - b;
			} else {
				b = b - a;
			}
		}
		System.out.println(a);
		System.out.println(b);
	}

	public static void main(String[] args) {
//		int n1 = 12;
//		int n2 = 6;
//		int high = 0;
//		for (int i = 1; i <= n1 && i <= n2; i++) {
//			if (n1 % i == 0 && n2 % i == 0) {
//				high = i;
//			}
//		}
//		System.out.println(high);
		common(12,8);
	}
}
