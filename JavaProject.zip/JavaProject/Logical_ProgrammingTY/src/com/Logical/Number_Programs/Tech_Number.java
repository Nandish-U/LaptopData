package com.Logical.Number_Programs;

public class Tech_Number {
	public static int loop(int c )
	{
		int res =1;
		for(int i=1; i<=c;i++)
		{
			res= res*10;;
		}
		return res;
	}
	public static void main(String[] args) {
		int num = 2025;
		int num1 = num;
		int temp = num;
		int count = 0;
		int half = 0;
		while (temp != 0) {
			count++;
			temp /= 10;
		}
		if (count % 2 == 0) {
			half = num % loop(count/2);
			num = num / loop(count/2);
		}
		int sum = (half + num) * (half + num);
		if (sum == num1) {
			System.out.println("Tech Number");
		} else {
			System.out.println("Not a tech Number");
		}
		
		
	}
}
