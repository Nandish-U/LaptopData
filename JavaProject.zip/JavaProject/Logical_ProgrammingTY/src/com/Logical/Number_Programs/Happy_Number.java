package com.Logical.Number_Programs;

public class Happy_Number 
{
	public static void main(String[] args) 
	{
		int n =12;
		
		while(true)
		{
			int sum=0;
			while(n!=0)
			{
				int rem = n%10;
				sum = sum+rem*rem;
				n = n/10;
			}
			if(sum == 1)
			{
				System.out.println("Happy number");
				break;
			}
			else if(sum == 4)
			{
				System.out.println("sad number");
				break;
			}
			n=sum;
		}
	}
}
