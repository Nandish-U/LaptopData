package com.Logical.Number_Programs;

class A
{

}
class B extends A
{

}
class C extends A
{

}
class K
{

}
public class Main 
{
	public static void main(String[] args) 
	{
		Object a = new K();
		C c = (C)a;
	}
}
