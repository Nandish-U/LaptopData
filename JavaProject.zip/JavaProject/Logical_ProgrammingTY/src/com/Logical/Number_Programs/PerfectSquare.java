package com.Logical.Number_Programs;

public class PerfectSquare 
{
	public static void square()
	{
		int n = 121;
		int res = (int)Math.sqrt(n);
		if(res*res == n)
		{
			System.out.println("perfect squarq "+n);
		}
		else
		{
			System.out.println("Not a perfect square "+n);
		}
	}
	public static void main(String[] args) 
	{
//		int num =121;
//		int sqr=1;
//		for(int i=1; i<=num; i++)
//		{
//			if(i*i==num)
//			{
//			sqr = i*i;
//			}
//		}
//		if(sqr == num)
//		{										
//			System.out.println("perfect square");
//		}
//		else
//		{
//			System.out.println("Not a perfect square");
//		}
		square();
	}
}
