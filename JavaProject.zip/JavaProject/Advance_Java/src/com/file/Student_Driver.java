package com.file;

import java.io.*;

public class Student_Driver {
	public static void main(String[] args) {
		File f = new File("e:Stu.ser");
		try {
			FileOutputStream ff = new FileOutputStream(f);
			ObjectOutputStream o = new ObjectOutputStream(ff);
			o.writeObject(new Student("nandi",101,"nandi@",9035546696l));
			o.writeObject(new Student("shree",102,"shree@",7022672081l));
			o.flush();
			System.out.println("Data added Successfully");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("==========================");
		//read all data from file
		try {
			FileInputStream f1 = new FileInputStream(f);
			ObjectInputStream o1 = new ObjectInputStream(f1);
			while(true)
			{
				try {
					Object a = o1.readObject();
					Student s = (Student)a;
					System.out.println(s);
				} catch (Exception e) {
					break;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("==========================");
		//update data from file
		try {
			FileInputStream f1 = new FileInputStream(f);
			ObjectInputStream o1 = new ObjectInputStream(f1);
			FileOutputStream l1 = new FileOutputStream(f);
			ObjectOutputStream l2 = new ObjectOutputStream(l1);
//			FileWriter f2 = new FileWriter(f,true);
//			while(true)
//			{
				try {
					Object a = o1.readObject();
					Student s = (Student)a;
					if(s.getName().equalsIgnoreCase("nandi"))
					{
					
					}
				} catch (Exception e) {
//					break;
					e.printStackTrace();
				}
//			}
			System.out.println("Data updated Successfully");
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("==========================");
		//read all data from file
		try {
			FileInputStream f1 = new FileInputStream(f);
			ObjectInputStream o1 = new ObjectInputStream(f1);
			while(true)
			{
				try {
					Object a = o1.readObject();
					Student s = (Student)a;
					System.out.println(s);
				} catch (Exception e) {
					break;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("==========================");
	}
}
