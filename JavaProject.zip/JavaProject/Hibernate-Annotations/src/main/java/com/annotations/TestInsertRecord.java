package com.annotations;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestInsertRecord 
{
	public static void main(String[] args) 
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vikas");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		Teacher teacher = new Teacher();
		teacher.setName("shree");
		teacher.setEmail("shree@12");
		teacher.setPhone(903554696l);
		
		et.begin();
		em.persist(teacher);
		et.commit();
	}
}
