package ex;

public class Factor 
{
	public static void main(String[] args) 
	{
		int num = 6;
		for(int i=1; i<=6; i++)
		{
			if(num%i==0)
			{
				System.out.print(i+" ");
			}
		}
	}
}
