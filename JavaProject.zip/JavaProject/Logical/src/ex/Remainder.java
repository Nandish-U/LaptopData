package ex;

public class Remainder 
{
	public static void main(String[] args) 
	{
		int num = 56892;
		int rem = num%10;
		System.out.println(rem);
	}
}
