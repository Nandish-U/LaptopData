package com.view;

import com.controller.Cycle_Controller;

public class Driver {
	public static void main(String[] args) {
		Cycle_Controller c = new Cycle_Controller();
		c.mrp();
	}
}
