package com.model;

public class BiCycle {
	private int seat = 1;
	private int frame = 1;
	private int brakeSet = 2;
	private int handleBar = 1;
	private int wheel = 2;
	private int tire = 2;
	private int chain = 1;
	private int crankSet = 1;
	private int pedal = 2;

	public int getSeat() {
		return seat;
	}

	public void setSeat(int seat) {
		this.seat = seat;
	}

	public int getFrame() {
		return frame;
	}

	public void setFrame(int frame) {
		this.frame = frame;
	}

	public int getBrakeSet() {
		return brakeSet;
	}

	public void setBrakeSet(int brakeSet) {
		this.brakeSet = brakeSet;
	}

	public int getHandleBar() {
		return handleBar;
	}

	public void setHandleBar(int handleBar) {
		this.handleBar = handleBar;
	}

	public int getWheel() {
		return wheel;
	}

	public void setWheel(int wheel) {
		this.wheel = wheel;
	}

	public int getTire() {
		return tire;
	}

	public void setTire(int tire) {
		this.tire = tire;
	}

	public int getChain() {
		return chain;
	}

	public void setChain(int chain) {
		this.chain = chain;
	}

	public int getCrankSet() {
		return crankSet;
	}

	public void setCrankSet(int crankSet) {
		this.crankSet = crankSet;
	}

	public int getPedal() {
		return pedal;
	}

	public void setPedal(int pedal) {
		this.pedal = pedal;
	}
}
