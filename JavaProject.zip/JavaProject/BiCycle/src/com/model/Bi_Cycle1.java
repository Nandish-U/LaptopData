package com.model;

import java.util.HashMap;
import java.util.Map;

public class Bi_Cycle1 {
	private Map<String, Integer> map = new HashMap<>();

	public Map<String, Integer> getMap() {
		return map;
	}

	public void setMap(Map<String, Integer> map) {
		this.map = map;
	}

	public void add()
	{
		map.put("seat", 1);
		map.put("frame", 1);
		map.put("brakeSet", 2);
		map.put("handleBar", 1);
		map.put("wheel", 2);
		map.put("tire", 2);
		map.put("crankSet", 1);
		map.put("peddal", 2);
		map.put("chain", 1);
	}
}
