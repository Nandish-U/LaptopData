package com.controller;

import java.util.Set;

import com.model.*;

public class Cycle_Controller {
	Bi_Cycle1 b = new Bi_Cycle1();
	BiCycle c = new BiCycle();
	Inventory i = new Inventory();

	public void mrp() {
		b.add();
		i.stock();
		Set<String> keys = b.getMap().keySet();
		Set<String> s = i.getMap().keySet();
		for (String it : s) {
			for (String it2 : keys) {
				if (it2.equalsIgnoreCase(i.getMap().get(it).getName())) {
					System.out.println(it2 + "\n" + "=>For one Bicycle= " + b.getMap().get(it2)+" "+it2 + "\n"
							+ "=>For 200 Bicycles= " + b.getMap().get(it2) * 200+" "+it2 + "\n" + "=>Available in stock ="
							+ i.getMap().get(it).getQuantity()+" "+it2 + "\n" + "=>Need to be purchased = "
							+ ((b.getMap().get(it2) * 200) - i.getMap().get(it).getQuantity())+" "+it2);
				}
			}
		}
	}
}
