package com.student;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class Driver {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vikas");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
//		Student s = new Student();
//		s.setId(10);
//		s.setName("nandi");
//		s.setEmail("nandise#");
//		et.begin();
//		em.persist(s);
//		et.commit();
		
		// how to find the data
		Student id = em.find(Student.class, 1);
		System.out.println(id.getName());
	}
}
