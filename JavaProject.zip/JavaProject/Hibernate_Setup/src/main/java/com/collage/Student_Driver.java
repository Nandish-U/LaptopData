package com.collage;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class Student_Driver 
{
	public static void main(String[] args) 
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vikas");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		Student s = new Student();
		s.setRol(18);
		s.setName("shree");
		s.setHeight(5.4);
		s.setEmail("shree@34");
		
		et.begin();
		em.persist(s);
		et.commit();
		
		System.out.println("Data has been stored successfully");
	}
}
