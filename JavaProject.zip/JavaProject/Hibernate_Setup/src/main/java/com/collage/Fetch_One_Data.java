package com.collage;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Fetch_One_Data {
	public static void main(String[] args) 
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vikas");
		EntityManager em = emf.createEntityManager();
		Student s = em.find(Student.class, 120);
		if(s!=null) {
		System.out.println(s.getName());
		System.out.println(s.getEmail());
		System.out.println(s.getHeight());
		System.out.println(s.getRol());
		}
		else
		{
			System.out.println("No data found");
		}
		
	}
}
