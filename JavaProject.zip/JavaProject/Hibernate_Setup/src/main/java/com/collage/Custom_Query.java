package com.collage;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Custom_Query {
	public static void main(String[] args) 
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vikas");
		EntityManager em = emf.createEntityManager();
		
		Query query =  em.createQuery("select s from Student s");
		List<Student> l = query.getResultList();
		for(Student s:l)
		{
			System.out.println("Roll no :	 "+s.getRol());
			System.out.println("Name : "+s.getName());
			System.out.println("email : "+s.getEmail());
			System.out.println("height : "+s.getHeight());
			System.out.println("=========================");
		}
	}
}
