package com.ty;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Teacher {
	@Id
	int id;
	String name;
	String email;
}
