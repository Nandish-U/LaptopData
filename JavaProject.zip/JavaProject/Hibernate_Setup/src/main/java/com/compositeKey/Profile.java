package com.compositeKey;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Profile 
{
	@EmbeddedId
	Account_Id ac;
	String name;
	long mobno;
	
	
}
