package com.compositeKey;

import jakarta.persistence.Embeddable;
@Embeddable
public class Account_Id 
{
	int id;
	String email;
}
