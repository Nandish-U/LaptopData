package com.string.onlineclass;

public class CountString 
{
	public static void main(String[] args) 
	{
		String s = "Ram is a   good   Boy";
		int count = 0;
//		for(int i=0; i<s.length(); i++)
//		{
//			if(s.charAt(i)!=' ')
//			{
//				count++;
//			}
//		}
//		System.out.println(count);
		for(int i=0; i<s.length();i++)
		{
			if((i==0&&s.charAt(i)!=' ') || (s.charAt(i)==' ' && s.charAt(i+1)!=' '))
			{
				count++;
			}
		}
		System.out.print(count);
	}
}
