package com.string.onlineclass;

public class Example1 
{
	public static void main(String[] args) 
	{
		String s = "gadag";
		String s1 = "";
		for(int i=s.length()-1; i>=0; i--)
		{
			s1 = s1+s.charAt(i);
		}
		System.out.println(s1);
		System.out.println(s.equals(s1));
		
	}
}
