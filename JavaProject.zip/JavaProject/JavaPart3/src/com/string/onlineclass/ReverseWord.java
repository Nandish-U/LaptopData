package com.string.onlineclass;

public class ReverseWord 
{
	public static void main(String[] args) 
	{
		String s = "Ram is a   good   Boy";
		String rev="";
		System.out.println(rev);
		for(int i=0; i<s.length();i++)
		{
			int start=i;
			int end=0;
			
			while(i<s.length() && s.charAt(i)!=' ')
			{
				end=i;
				i++;
			}
			for(int j=end; j>=start;j--)
			{
				rev = rev+s.charAt(j);
			}
			if(i<s.length() && s.charAt(i)==' ')
			{
				rev+= s.charAt(i);
			}
		}
		System.out.println(rev);
	}
}
