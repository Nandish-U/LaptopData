package com.string;

public class Example2 
{
	public static void main(String[] args) 
	{
		String s1 = new String("India");
		String s2 = new String("India");
		if(s1 == s2)
		{
			System.out.println("welcome");
		}
		else
		{
			System.out.println("Thankyou");
		}
	}
}
