package com.string;

public class Example3 
{
	public static void main(String[] args) 
	{
		StringBuffer s1 = new StringBuffer("India");
		StringBuffer s2 = new StringBuffer("India");
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
		System.out.println();
		System.out.println("============================");
		
		StringBuilder s3 = new StringBuilder("India");
		StringBuilder s4 = new StringBuilder("India");
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
		System.out.println(s3==s4);
		System.out.println(s3.equals(s4));
		System.out.println("======================");
		
		Object o = new String("India");
		Object o1 = new String("India");
		System.out.println(o);
		String s ="swl";
		System.out.println(s.hashCode());
		System.out.println(s.toString());
		System.out.println(s.getClass()+"@"+Integer.toHexString(s.hashCode()));
	}
}
