package com.string;

public class Ex {
	String s;
	public static void main(String[] args) {
		Ex e = new Ex();
		System.out.println(e);
		System.out.println(Integer.toHexString(e.hashCode()));
	}

}
