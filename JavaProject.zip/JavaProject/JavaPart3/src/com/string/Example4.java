package com.string;

public class Example4 
{
	public static void main(String[] args) 
	{
//		String s = new String("Hello");
//		String m = s;
//		System.out.println(m==s);
//		s="change";
//		System.out.println(s==m);
//		String k = "change";
//		System.out.println(s==k);
//		System.out.println(s.hashCode());
//		System.out.println(k.hashCode());
//		System.out.println(s.equals(k));
//		
//		
//		s = s.concat("evng");
//		k = k.concat("evng");
//		System.out.println(s);
//		System.out.println(k);
//		System.out.println(s==k);//here string address are different
		
//		String g = "ok";
//		String h = "ok";
//		System.out.println(g==h);
//		g = g.concat("done");
//		h = h.concat("done");
//		System.out.println(g==h);
		
		String s = new String("Hello");
		String s1 = new String("Hello");
		System.out.println(s==s1);
		s=s.concat("ok");
		s1 = s1.concat("ok");
		System.out.println(s==s1);
		s="Done";
		s1="Done";
		System.out.println(s==s1);
		
		
		
		
		System.out.println("====================");
//		String d = new String("working");
//		String f = new String("working");
//		
//		d = d.concat("morning");
//		f = f.concat("morning");
//		System.out.println(d);
//		System.out.println(f);
//		System.out.println(d==f);
//		System.out.println(d.equals(f));
//		d="ok";
//		f="ok";
//		System.out.println(d==f);
	}
}
