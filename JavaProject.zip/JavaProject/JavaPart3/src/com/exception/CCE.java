package com.exception;

class A
{
	
}
class B extends A
{
	
}
class C extends A
{
	
}

public class CCE 
{
	public static void main(String[] args) 
	{
		A a1 = new B();
		System.out.println(a1);
		C c1 = (C)a1;
		System.out.println(c1);
	}
}
