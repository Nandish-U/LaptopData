package com.exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MainCalci 
{
	public static void main(String[] args) 
	{

		Scanner sc = new Scanner(System.in);
		try
		{
			System.out.println("enter the distance in kms");
			int dis = sc.nextInt();
			System.out.println("enter the time in hours");
			int hrs = sc.nextInt();
			int speed = Calculator.div(dis, hrs);
			System.out.println("the speed to travel "+dis+"km with time "+hrs+"hrs is "+speed+"KMPH");
		}
//		catch(ArithmeticException e)
//		{
//			e.printStackTrace();
//		}
//		catch(InputMismatchException e)
//		{
//			System.out.println("please enter a integer number");
//			System.out.println("Thankyou");
//		}
		catch(ArithmeticException | InputMismatchException e)
		{
			e.printStackTrace();
		}
		catch(Throwable e)
		{
			System.out.println("Extremely sorry..");
			System.out.println("Something went wrong");
			System.out.println("COME BACK LATER...!");
		}
	}
}
