package com.exception;

import java.util.Scanner;

class InvalidSalaryException extends RuntimeException
{
	InvalidSalaryException(String message)
	{
		super(message);
	}
}
class Employee
{
	private String id;
	private String name;
	private double salary;
	Employee(String id, String name, double salary)
	{
		this.id = id;
		this.name = name;
//		setSalary(salary);
		if(salary>0)
		{
			this.salary = salary;
		}
		else
		{
			throw new InvalidSalaryException("please enter a valid salary");
		}
	}
	public String getId()
	{
		return id;
	}
	public String getName()
	{
		return name;
	}
	public double setSalary()
	{
		return salary;
	}
	public String toString()
	{
		return "Eid : "+id+" Empoyee name :"+name+" salary id : "+salary;
	}
//	public void setSalary(double salary)
//	{
//		if(salary>0)
//		{
//			this.salary = salary;
//		}
//		else
//		{
//			throw new InvalidSalaryException("please enter a valid salary");
//		}
//	}
}
public class CustomException 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the employee ID in String");
		String id = sc.next();
		System.out.println("Enter the Employee name");
		String name = sc.next();
		System.out.println("Enter the Employee Salary");
		double salary = sc.nextDouble();
		Employee e = new Employee(id,name,salary);
		System.out.println(e);
		
	}
}
