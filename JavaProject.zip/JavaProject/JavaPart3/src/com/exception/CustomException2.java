package com.exception;

import java.util.Scanner;

class Emp
{
	String id;
	String name;
	double sal;
	
	public String getId()
	{
		return id;
	}
	public Emp(String id, String name, double sal) 
	{
		this.id = id;
		this.name = name;
		if(sal>0)
		{
			this.sal = sal;
		}
		else
		{
			throw new InvalidSalaryException("please enter a valid salary");
		}
	}
	public String[] getS()
	{
		String[] s = {id,name,""+sal};
		return s;
	}	
}
public class CustomException2 
{
	public static void main(String[] args) 
	{
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter the employee ID in String");
//		String id = sc.next();
//		System.out.println("Enter the Employee name");
//		String name = sc.next();
//		System.out.println("Enter the Employee Salary");
//		double salary = sc.nextDouble();
//		Emp e = new Emp(id,name,salary);
//		
//		for(int i=0; i<e.getS().length;i++)
//		{
//			System.out.println(e.getS()[i]);
//		}
		System.out.println(5000-3000);
	}
}
