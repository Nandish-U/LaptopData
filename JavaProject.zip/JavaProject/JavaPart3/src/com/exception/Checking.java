package com.exception;

import java.sql.SQLException;

public class Checking 
{
	static void a() throws SQLException
	{
		throw new SQLException();
	}
	public static void main(String[] args) {
		try {
			a();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
