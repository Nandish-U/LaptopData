package com.exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

class GFG {
	 
    public static void main() {
 
      
        try {
			FileInputStream GFG = new FileInputStream("/Desktop/GFG.txt");
		} catch (FileNotFoundException e) 
        {
			e.printStackTrace();
		}
    }
}
public class Checked 
{
	public static void main(String[] args) 
	{
		GFG.main();
	}
}
