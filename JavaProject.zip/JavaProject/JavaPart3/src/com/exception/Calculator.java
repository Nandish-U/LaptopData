package com.exception;

import java.util.InputMismatchException;

public class Calculator 
{
	public static int div(int a, int b) throws ArithmeticException,InputMismatchException
	{
		return a/b;
	}
}
