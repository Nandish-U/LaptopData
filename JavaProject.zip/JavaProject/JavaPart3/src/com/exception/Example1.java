package com.exception;

class Sample
{
	static void add(int a)
	{
		try
		{
		System.out.println(a/0);
		
		
		}
		catch(ArithmeticException | ArrayIndexOutOfBoundsException e)
		{
			System.out.println("exception handeled");
		}
		finally
		{
			int[] k = {10,20,30};
			System.out.println(k[a]);
		}
	}
}
public class Example1 
{
	public static void main(String[] args) 
	{
		Sample.add(9);
	}
}
