package com.exception;

public class SIOBE 
{
	public static void main(String[] args) 
	{
		String n = "Hello";
		System.out.println(n.charAt(8));
	}
}
