package com.sample;

import java.util.Arrays;

import org.apache.commons.lang3.ArrayUtils;

public class Main {
	public static void main(String[] args) {
		int[] a = { 1, 3, 5, 40, 50 };
		int[] a1 = ArrayUtils.insert(3, a, 80);
		System.out.println(Arrays.toString(a1));
		
	}
}
