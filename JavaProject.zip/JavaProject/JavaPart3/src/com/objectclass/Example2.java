package com.objectclass;

class Mobile
{
	int ram;
	int rom;
	Mobile(int ram, int rom)
	{
		this.ram = ram;
		this.rom = rom;
	}
	public String toString()
	{
		return "Mobile { ram: "+ram+", rom: "+rom+" }";
	}
}
public class Example2 
{
	public static void main(String[] args) 
	{
		Mobile b = new Mobile(4,64);
//		System.out.println(b.ram);
//		System.out.println(b.rom);
		Mobile b2 = new Mobile(4,64);
//		System.out.println(b2.ram);
//		System.out.println(b2.rom);
		System.out.println(b);
		System.out.println(b2);
		System.out.println("=========================");
		Mobile[] mobiles = new Mobile[4];
		mobiles[0] = new Mobile(8,256);
		mobiles[1] = new Mobile(6,128);
		mobiles[2] = new Mobile(12,256);
		mobiles[3] = new Mobile(4,32);
		// how to retrieve
		for(int i=0; i<mobiles.length; i++)
		{
			System.out.println(mobiles[i]);
		}
		char[]  c = new char[3];
		System.out.println(" "+c);
		boolean[]  c1 = new boolean[3];
		System.out.println(c1);
	}
}
