package com.objectclass;

public class Example1 extends Object
{
	Example1()
	{
		super();
	}
	public static void main(String[] args) 
	{
		Example1 c = new Example1();
		char d = '6';
		System.out.println(d);
		byte a =10;
		byte b = 20;
		byte res = (byte) ((byte)a+b);
	}
}
