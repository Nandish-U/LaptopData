package com.objectclass;

import java.util.Objects;

class A
{
	int age;
	
	@Override
	public int hashCode() {
		return Objects.hash(age);
	}
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		A other = (A) obj;
//		return age == other.age;
//	}
	
}
public class HashcodeMain extends K
{
	public static void main(String[] args) 
	{
		A a = new A();
	//	a.age=29
		A a1 = new A();
		System.out.println(a);
		System.out.println(a1.toString());
//		System.out.println(a.getClass() != obj.getClass()a.);
		
		
		
//		String s = new String("ok");
//		String s1 = "Hello";
//		System.out.println(s);
//		System.out.println(s1);
//		new K().a();
//		System.out.printf("%10, a");
		System.out.printf("'%10s' %n", "Hello");
	}
	@Override
	public int a() {
		return 10;
	}
}
class K	
{
	public native int a();
}
