package com.objectclass;

class Box
{
	double price;
	Box(double price)
	{
		this.price = price;
	}
	
}
public class EqualsMain 
{
	public static void main(String[] args) 
	{
		Box b1 = new Box(10);
		Box b2 = b1;
		System.out.println(b1==b2);
		System.out.println(b1.equals(b2));
		
		Box b3 = new Box(10);
		
		Box b4 = new Box(10);
		System.out.println(b3 == b4);
		System.out.println(b3.equals(b4));
		char c;
	}
}
