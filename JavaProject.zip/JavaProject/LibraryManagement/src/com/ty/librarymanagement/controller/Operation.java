package com.ty.librarymanagement.controller;

import java.util.Arrays;
import java.util.Scanner;

import com.ty.librarymanagement.entity.*;

public class Operation {
	public Library l = new Library("SapnaBookHouse","SouthEnd",562130);
	int count;
	public Book[] newbook;


	public Book[] addBook(Book e) {
		l.b[count] = e;
		count++;
		return l.b;
	}
	public Book[] deleteBook(String name1)
	{
		int k = 0;
		int count1 = 0;
		for (int i = 0; i < l.b.length; i++) {
			if (l.b[i].getName().equalsIgnoreCase(name1)) {
				count1++;
			}
		}
		newbook = new Book[l.b.length - count1];
		for (int i = 0; i < l.b.length; i++) {
			if (!l.b[i].getName().equalsIgnoreCase(name1)) {
				newbook[k] = l.b[i];
				k++;
			}
		}
		return newbook;
	}
	public Book[] updateBook(String name, double price)
	{
		for (int i = 0; i < newbook.length; i++) {
			if (newbook[i].getName().equalsIgnoreCase("Java") && newbook[i].getPrice()==500)
			{
				newbook[i].setPrice(price);
			}
		}
		return newbook;
	}
	public void getBook(String name)
	{
		for (int i = 0; i < newbook.length; i++) {
			if (newbook[i].getName().equalsIgnoreCase(name))
			{
				System.out.println(newbook[i]);
			}
		}
	}
	

}
