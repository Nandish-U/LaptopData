package com.ty.librarymanagement.driver;

import java.util.Arrays;

import com.ty.librarymanagement.controller.Operation;
import com.ty.librarymanagement.entity.Book;

public class Driver
{
	public static void main(String[] args) 
	{
		Operation o = new Operation();
		Book b = new Book("Java","JamesGosling",500.0, "Ty");
		o.addBook(b);
		Book b1 = new Book("Sql","raymond boyce",300.0, "Ty");
		o.addBook(b1);
		Book b2 = new Book("Sql","raymond boyce",300.0, "Ty");
		o.addBook(b2);
		Book b3 = new Book("Sql","raymond boyce",900.0, "Ty");
		o.addBook(b3);
		Book b4 = new Book("web","chamberlin",600.0, "Ty");
		System.out.println("===================");
		o.addBook(b4);
		for(Book ele: o.l.b)
		{
			System.out.println(ele);
		}
		System.out.println("=====================");
		System.err.println("After Deleting data");
		o.deleteBook("web");
		for(Book ele: o.newbook)
		{
			System.out.println(ele);
		}
		System.out.println("=====================");
		System.err.println("After updating data");
		o.updateBook("java", 800.0);
		for(Book ele: o.newbook)
		{
			System.out.println(ele);
		}
		System.out.println("=====================");
		System.err.println("Retrieving by name");
		o.getBook("java");
		
		
	}
}
