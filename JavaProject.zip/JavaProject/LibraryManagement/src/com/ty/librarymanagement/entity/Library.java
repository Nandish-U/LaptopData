package com.ty.librarymanagement.entity;

import java.util.Arrays;

public class Library {
	private String name;
	private String address;
	private int pincode;

	public Library(String name, String address, int pincode) {
		this.name = name;
		this.address = address;
		this.pincode = pincode;
	}

	public Library()
	{
		
	}
	 public Book[] b = new Book[5];

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "Library [name=" + name + ", address=" + address + ", pincode=" + pincode + ", b=" + Arrays.toString(b)
				+ "]";
	}
	
}
