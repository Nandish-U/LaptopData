package com.test_editor_view;

import com.test_editor_controller.Test_Editor_Controller;

public class Text_Editor_View {
	public static void main(String[] args) {
		Test_Editor_Controller te = new Test_Editor_Controller();
		while (true) {
			System.out.println("Welcome to Text_Editor...!");
			System.out.println(
					" 1 : save\n 2 : undo\n 3 : redo\n 4 : display\n 5 : addWordsToDic\n 6 : AutoSuggest\n 7: exit");
			System.out.println("Enter the choice");
			int choice = te.scanner.nextInt();
//			te.scanner.nextLine();
			String str = te.scanner.next();
			te.scanner.nextLine();
			String str2 = "";
			switch (choice) {
			case 1:
				te.save();
				break;
			case 2:
				te.undo();
				break;
			case 3:
				te.redo();
				break;
			case 4:
				te.display();
				break;
			case 5:
				te.addWordsToDictionary();
				break;
			case 6:
				System.out.println("Enter the character");
				str = te.scanner.next();
				te.autoSuggest(str);
				break;
			case 7:
				System.out.println("Thankyou....!!");
				return;
			default:
				System.out.println("Enter a valid choice");
			}
		}
	}
}
