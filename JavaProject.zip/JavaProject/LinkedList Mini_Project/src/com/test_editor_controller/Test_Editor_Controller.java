package com.test_editor_controller;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

public class Test_Editor_Controller 
{
	LinkedList<String> l = new LinkedList<>();
	ArrayList<String> dictionary = new ArrayList<>();
	public Scanner  scanner = new Scanner(System.in);
	int position = -1;
	public void save()
	{
		System.out.println("Enter the name");
		String name = scanner.nextLine();
		while(position<l.size()-1)
		{
			l.removeLast();
		}
		String str1 = scanner.next();
		if(str1.equalsIgnoreCase("y"))
		{
			l.add(autoSuggest(name));
		}
		l.add(name);
		position++;
		System.out.println("Data added successfully");
		System.out.println("================");
	}
	public void undo()
	{
		if(position>-1)
		{
		position--;
		}
	}
	public void redo()
	{
		if(position<l.size()-1)
		{
			position++;
		}
	}
	public void display()
	{
		for(int i=0; i<=position && position>=0; i++)
		{
			System.out.println(l.get(i));
		}
	}
	public void addWordsToDictionary()
	{
		System.out.println("Enter exit to quit");
		System.out.println("Enter the word to add Dictionary");
		String str="";
		while(true)
		{
			if(str.equalsIgnoreCase("exit"))
			{
				break;
			}
			else
			{
				str = scanner.next();
				dictionary.add(str);
				
			}
		}
		System.out.println(dictionary.size()+" words successfully added");
	}
	public String autoSuggest(String str)
	{
		int i=0;
//		System.out.println("Enter the character");
//		String str = scanner.next();
		for(String word: dictionary)
		{
			i++;
			if(word.equalsIgnoreCase(str))
			{
				System.out.println(i+" "+word);
			}
		}
		int c = scanner.nextInt();
		return dictionary.get(--c);
	}
}
