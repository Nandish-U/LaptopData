package com.treeSet;

import java.util.*;

public class Employee_Controller {
	TreeSet<Employe> t = new TreeSet<>();
	ArrayList<Employe> a ;
	Scanner sc = new Scanner(System.in);
	
	public void add()
	{
		System.out.println("Enter the name");
		String name = sc.next();
		System.out.println("Enter the id");
		int id = sc.nextInt();
		System.out.println("Enter the phno ");
		long phno = sc.nextLong();
		t.add(new Employe(name,id,phno));
		System.out.println("Data added successfully");
		a = new ArrayList<>(t);
	}
	public void display()
	{
		for(Employe e :t)
		{
			System.out.println(e);
		}
	}
	public void sort()
	{
		System.out.println("1: Sort based on name");
		System.out.println("2: Sort based on id");
		System.out.println("3: Sort based on phno");
		System.out.println("enter the choice");
		int choice = sc.nextInt();
		switch(choice)
		{
		case 1: {
			Collections.sort(a
					, new Sort_Employee());
			for(Employe e :a)
			{
				System.out.println(e);
			}
		}
		break;
		case 2:{
			
		}
		break;
		case 3: {
			
		}
		break;
		}
	}
}
