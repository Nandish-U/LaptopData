package com.treeSet;

import java.util.TreeSet;

public class Company_Driver 
{
	public static void main(String[] args) 
	{
		SortById s = new SortById();
		TreeSet<Company> t = new TreeSet<>(s);
		t.add(new Company(101));
		t.add(new Company(106));
		t.add(new Company(108));
		t.add(new Company(103));
		t.add(new Company(105));
		System.out.println(t);
		
	}
}
