package com.treeSet;

public class Employe implements Comparable<Employe> 
{
	String name;
	int id;
	Long phno;
	Employe(String name, int id, long phno)
	{
		this.name = name;
		this.id = id;
		this.phno = phno;
	}
	public String toString()
	{
		return "Name : "+name+" id : "+id+" phno : "+phno;
	}
	@Override
	public int compareTo(Employe o) {
		return this.id - o.id;
	}
}
