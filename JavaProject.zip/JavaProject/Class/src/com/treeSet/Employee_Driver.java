package com.treeSet;

import java.util.Scanner;

public class Employee_Driver {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Employee_Controller e = new  Employee_Controller();
		while(true) {
			System.out.println("Enter the choice");
			int choice = sc.nextInt();

			switch(choice)
			{
			case 1:{
				e.add();
			}
			break;
			case 2:{
				e.display();
			}
			break;
			case 3:{
				e.sort();
			}
			break;
			case 5:{
				System.exit(0);
			}
			}
		}
	}
}
