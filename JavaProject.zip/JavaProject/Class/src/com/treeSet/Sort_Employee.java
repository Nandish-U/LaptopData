package com.treeSet;

import java.util.Comparator;

class Sort_By_Id implements Comparator<Employe>
{

	@Override
	public int compare(Employe o1, Employe o2) {
		return o1.name.compareTo(o2.name);
	}
}
class Sort_By_phno implements Comparator<Employe>
{

	@Override
	public int compare(Employe o1, Employe o2) {
		return o1.phno.compareTo(o2.phno);
	}
}
public class Sort_Employee 	implements Comparator<Employe>
{

	@Override
	public int compare(Employe o1, Employe o2) {
		return o2.name.compareTo(o1.name);
	}
}
