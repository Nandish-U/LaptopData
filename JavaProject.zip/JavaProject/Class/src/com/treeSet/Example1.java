package com.treeSet;

import java.util.TreeSet;

public class Example1 
{
	public static void main(String[] args) 
	{
		TreeSet<Integer> t = new TreeSet<>();
		t.add(10);
		t.add(80);
		t.add(30);
		t.add(5);
		System.out.println(t);
	}
}
