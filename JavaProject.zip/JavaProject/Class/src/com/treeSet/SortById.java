package com.treeSet;

import java.util.Comparator;

public class SortById implements Comparator<Company>{

	@Override
	public int compare(Company o1, Company o2) {
		return o2.id-o1.id;
	}

	

}
