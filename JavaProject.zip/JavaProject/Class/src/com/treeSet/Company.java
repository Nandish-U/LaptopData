package com.treeSet;

public class Company
{
//	String name;
	int id;
	public Company(int id) {
		super();
//		this.name = name;
		this.id = id;
	}
	@Override
	public String toString() {
		return "Company [name=" +", id=" + id + "]";
	}
//	@Override
//	public int compareTo(Company o) {
//		return this.id - o.id;
//	}
//	
}
	