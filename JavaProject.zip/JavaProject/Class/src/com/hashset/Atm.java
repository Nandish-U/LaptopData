package com.hashset;

public class Atm {
	private int money;
	private int id;
	
	void setmoney(int money) {
		this.money=money;
	}
	int getmoney() {
		return money;
	}
	void setid(int id) {
		this.id=id;
	}
	int getid() {
		return id;
	}
	Atm(int money, int id){
		this.setmoney(money);
		this.setid(id);
	}
	public String toString() {
		return "The money is - "+ money+" and id is - "+ id;
	}
	public boolean equals(Object o) {
		Atm a= (Atm)o;
		return this.id==a.id;
	}
	public int hashCode()
	{
		return id;
	}
}
