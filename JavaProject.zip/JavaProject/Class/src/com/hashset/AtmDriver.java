package com.hashset;

import java.util.Arrays;
import java.util.HashSet;

public class AtmDriver {
	public static void main(String [] args) {
		String n="hello hi Good morning" ;
//		System.out.println(n);
//		System.out.println(n.indexOf("hi"));
//		System.out.println(n.replace('e', 'a'));
//		System.out.println(n.replaceAll(n, "hello"));
//		System.out.println(n.replace(n, "bye"));
//		System.out.println(n.trim());
//		String [] b = n.split("   ");
		String[] b = n.split("hi", 3);
		for (String string : b) {
			System.out.println(string);
		}
//		HashSet b = new HashSet();
//		b.add(new Atm(100, 01));
//		b.add(new Atm(50, 01));
//		b.add(new Atm(150, 02));
//		b.add(new Atm(150, 02));
//		System.out.println(b);
	}

}
