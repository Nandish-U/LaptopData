package com.hashset;
import java.util.ArrayList;
import java.util.HashSet;
public class Demo
{
	public static void main(String[] args) 
	{
		HashSet a = new HashSet();
		a.add(10);
		a.add(1);
		a.add(null);
		a.add(16);
		a.add(5);
		a.add(2);
		a.add(null);
		a.add(16);
//		System.out.println(a);
//		for(Object obj:a)
//		{
//			if(obj == 16)
//			System.out.println(obj);
//		}
		ArrayList a1 = new ArrayList<>(a);
		System.out.println(a1);
		System.out.println(a1.get(1));
		}
}
