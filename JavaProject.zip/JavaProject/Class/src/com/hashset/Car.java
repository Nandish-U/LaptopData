package com.hashset;

public class Car 
{
	private String name;
	private int price;
	
	//getter
	String getname() {
		return name;
	}
	//setter
	void setname(String name) {
		this.name=name;
	}
	int getprice() {
		return price;
	}
	void setprice(int price) {
		this.price=price;
	}
	Car(String name, int price){
		this.name=name;
		this.setprice(price);
	}
	public String toString() {
		return "The car name is - "+name+" and the price is - "+price;
	}
	public boolean equals(Object o) {
		Car c = (Car)o;
		return this.name.equals(c.name);
	}
	public int hashCode()
	{
		return price;
	}
}
