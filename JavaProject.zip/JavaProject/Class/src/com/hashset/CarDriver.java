package com.hashset;

import java.util.HashSet;

public class CarDriver {
	public int hashCode()
	{
		return 10;
	}
public static void main(String[] args) {
	HashSet a=new HashSet();
	a.add(new Car("audi", 10));
	a.add(new Car("BMW", 30));
	a.add(new Car("Maruti", 5));
	a.add(new Car("audi", 10));
	a.add(new Car("Maruti",5));
	for(Object obj:a) {
		System.out.println(obj);
	}
	
	CarDriver d = new CarDriver();
	CarDriver d1 = new CarDriver();
	CarDriver d2 = new CarDriver();
	CarDriver d3 = new CarDriver();
	CarDriver d4 = new CarDriver();
	System.out.println(d.hashCode());
	System.out.println(d1.hashCode());
	System.out.println(d2.hashCode());
	System.out.println(d3.hashCode());
	System.out.println(d4.hashCode());
}
}
