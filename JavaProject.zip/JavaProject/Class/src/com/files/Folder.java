package com.files;

import java.io.File;

public class Folder 
{
	public static void main(String[] args) 
	{
		 File f= new File("D:/Desktop/Harshsoni/Nandeesh");
		 System.out.println(f.mkdir());
	}
}
