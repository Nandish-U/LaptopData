package com.files;

import java.io.*;

public class Write 
{
	public static void main(String[] args) 
	{
		String path = "D:/Desktop/Harshsoni/newfile.txt";
		FileWriter f = null;
		try {
			f = new FileWriter(path,true);
			f.write("Hello");
			f.append("good evening");
			f.flush();
			System.out.println("Added Successfully");
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				f.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
		
		System.out.println("===================================");
		//read data...!
		try {
			FileReader j= new FileReader(path);
			try {
				int a = j.read();
				while(a>=0) {
					System.out.println((char)a);
					a=j.read();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
