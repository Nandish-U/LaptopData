package com.linkedList;

import java.util.LinkedList;
import java.util.Scanner;

public class Pen implements Comparable<Pen>
{
	int price;
	String color;
	public Pen(int price, String color) {
		super();
		this.price = price;
		this.color = color;
	}
	@Override
	public String toString() {
		return "Pen [price=" + price + ", color=" + color + "]";
	}
	@Override
	public int compareTo(Pen o) {
		return this.price - o.price;
	}
	 
}
