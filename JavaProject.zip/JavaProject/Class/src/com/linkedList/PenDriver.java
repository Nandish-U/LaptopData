package com.linkedList;

import java.util.LinkedList;
import java.util.Scanner;

public class PenDriver {
	LinkedList<Pen> l = new LinkedList<>();

	public void add() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the price");
		int price = sc.nextInt();
		System.out.println("Enter the color");
		String name = sc.next();
		//		Pen p = new Pen(price,name);
		l.add(new Pen(price, name));
		System.out.println("Added successfully");
	}

	public void print() {
		while (l.size() != 0) {
			System.out.println(l.poll());
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PenDriver l = new PenDriver();
		while (true) {
			System.out.println("Enter the choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1: {
				l.add();
			}
			break;
			case 2: {
				l.print();
			}
			break;
			case 3:System.out.println("Thankyou");
			System.exit(0);
			}
		}
	}
}
