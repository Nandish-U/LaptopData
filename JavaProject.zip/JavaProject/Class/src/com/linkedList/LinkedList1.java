package com.linkedList;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

public class LinkedList1{
	
	public static void main(String[] args) 
	{
		LinkedList<Integer> l =  new LinkedList();
		l.add(10);
		l.add(50);
		l.add(80);
		l.add(30);
		l.add(10);
		l.add(null);
		Iterator<Integer> k = l.iterator();
		for (Integer integer : l) {
			System.out.println(integer);
		}
//		System.out.println(l);
//		while(l.size()!=0)
//		{
//			System.out.println(l.poll());
//		}
//		System.out.println(l);
//		System.out.println("====================");
//		System.out.println(l.pollFirst());
//		System.out.println(l);
//		System.out.println(l.pollFirst());
//		System.out.println(l);
//		System.out.println(l.pollLast());
//		System.out.println(l);
//		System.out.println(l.peekFirst());
//		System.out.println(l.peekLast());
//		Collections.sort(l);
//		while(l.size()!=0)
//		{
//			System.out.println(l.poll());
//		}
		
	}

//	@Override
//	public int compareTo(Object o) {
//		return ;
//	}
}
