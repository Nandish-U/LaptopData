package com.arraylist;

import java.util.ArrayList;
public class Sample 
{
	public static void main(String[] args) 
	{
		ArrayList a = new ArrayList();
		a.add(10);
		a.add(50);
		a.add(10);
		a.add(null);
		a.add('a');
		a.add("nan");
		a.add(null);
		System.out.println(a);
		a.add(2, 80);
		
		System.out.println(a);
		
		for(int i=0; i<a.size(); i++)
		{
			System.out.println(a.get(i));
		}
	}
}
/*
 * get(int index)- is used to get the elemets from
 * object.
 * It is a non static method
 * */
