package com.arraylist;

public class Student 
{
	int id;
	String name;
	String usn;
	
	Student(int id, String name, String usn)
	{
		this.id = id;
		this.name = name;
		this.usn = usn;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", usn=" + usn + "]";
	}
}
