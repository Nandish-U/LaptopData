package com.arraylist;

import java.util.ArrayList;
import java.util.Collections;

public class Student_Driver 
{
	public static void main(String[] args) 
	{
		Student s1 = new Student(8, "allen", "1vkuj897");
		Student s2 = new Student(2, "jones", "1vkuj897");
		Student s3 = new Student(6, "adams", "1vkuj897");
		Student s = new Student(1, "smith", "1nkush78");
		
		
		ArrayList<Student> a= new ArrayList<Student>();
		a.add(s);
		a.add(s1);
		a.add(s3);
		a.add(s2);
		
		for(int i=0; i<a.size(); i++)
		{
			System.out.println(a.get(i));
		}
		
//		Collections.sort(a);
	}
}
