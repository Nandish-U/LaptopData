package com.arraylist;

import java.util.ArrayList;
import java.util.Collections;

public class Demo {
	String name;
	Demo(String name)
	{
		this.name = name;
	}
	public static void main(String[] args) 
	{
		ArrayList<Integer> a = new ArrayList<Integer>();
		a.add(10);
		a.add(10);
		a.add(50);
		a.add(80);
		a.add(20);
		a.add(5);
		System.out.println(a);
		
		Collections.sort(a);//call compareTo()
		// in every wrapper class compareTo method is overriden
		
		System.out.println(a);
	}
}
