package com.custom.exception;

import java.io.FileWriter;

abstract class A
{
	abstract void m1();
}
class B extends A
{

	@Override
	void m1() {
		
	}
	
}


public class Driver {

	public static void main(String[] args) {
		A b = new B();
		b.m1();
		
		
		
		
		
		
		
	
		String a="nandi";
		String b=a;
		System.out.println(a);
		System.out.println(b);
		System.out.println(a==b);
		a=a.concat("vade");
		System.out.println(a);
		System.out.println(b);
		System.out.println(a==b);
		
		System.out.println("================================");
		
		StringBuffer c=new StringBuffer("nandi");
		StringBuffer d=c;
		System.out.println(c==d);
		c.append("vade");
		System.out.println(c==d);
	}
	
}