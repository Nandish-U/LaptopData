package com.ty.demo;

public class Sample {
	public static void main(String[] args) {
		Demo.m1();
		System.out.println(Demo.a);
		
		Demo.m2();
		System.out.println(Demo.b);
		
		Demo.m3();
		System.out.println(Demo.c);
		
		Demo.m4();
		System.out.println(Demo.d);
		
	}
}
