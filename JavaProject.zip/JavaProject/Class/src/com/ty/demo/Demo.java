package com.ty.demo;

public class Demo {
	public static int a=10;
	public static void m1() {
		System.out.println("public method");
	}
	
	protected static int b=20;
	protected static void m2() {
		System.out.println("protected method");
	}
	
	
	static int c=30;
	static void m3() {
		System.out.println("default method");
	}
	
	private static int d=40;
	private static void m4() {
		System.out.println("private method");
	}
	
	public static void main(String[] args) {
		System.out.println(a);
		m1();
		
		System.out.println(b);
		m2();
		
		System.out.println(c);
		m3();
		
		System.out.println(d);
		m4();
		
	}
}
