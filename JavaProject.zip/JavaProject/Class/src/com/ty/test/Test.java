package com.ty.test;

import com.ty.demo.Demo;

public class Test {
	public static int m1(int a, int b)
	{
	    return a+b;
	}
	public static void main(String[] args)

	{

	       System.out.println(m1('a','b'));

	}

	
}
