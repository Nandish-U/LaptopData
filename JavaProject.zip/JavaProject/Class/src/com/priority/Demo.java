package com.priority;

import java.util.Iterator;
import java.util.PriorityQueue;

public class Demo {
	public static void main(String[] args) 
	{
		PriorityQueue<Integer> p = new PriorityQueue<>();
		p.add(10);
		p.add(20);
		p.add(80);
		p.add(15);
		p.add(1);
//		System.out.println(p);
//		System.out.println(p.poll());
//		System.out.println(p);
//		System.out.println(p.peek());
		Iterator<Integer> l = p.iterator();
		for (Integer integer : p) {
			System.out.println(integer);
		}
		
	}
}
