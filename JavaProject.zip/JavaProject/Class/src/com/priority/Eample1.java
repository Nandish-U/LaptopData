package com.priority;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.TreeSet;

public class Eample1 
{
	public static void main(String[] args) 
	{
//		LinkedList<Integer> l  = new LinkedList<>();
//		l.add(10);
//		l.add(80);
//		l.add(22);
//		l.add(11);
//		System.out.println(l);
//		Collections.sort(l);
//		System.out.println(l);
//		Iterator<Integer> i = l.iterator();
//		for (Integer integer : l) {
//			System.out.println(integer);
//		}
		PriorityQueue<Integer> p = new PriorityQueue(new Sort());
		p.add(10);
		p.add(45);
		p.add(6);
		p.add(6);
		p.add(12);
//		System.out.println(p.peek());
//		System.out.println();
//		System.out.println(p);
//		Iterator i = p.iterator();
//		for (Object object : p) {
//			System.out.println(object);
//		}
		while(p.size()!=0)
		{
			System.out.println(p.poll());
		}
		System.out.println(p);
	}
}
