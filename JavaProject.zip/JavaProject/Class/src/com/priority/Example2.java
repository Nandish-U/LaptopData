package com.priority;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;

class Sort2 implements Comparator<Integer>
{

	@Override
	public int compare(Integer o1, Integer o2) {
		return o2-o1;
	}

}
public class Example2 
{
	public static void main(String[] args) 
	{
		PriorityQueue<Integer> p = new PriorityQueue<>();
		p.add(80);
		p.add(50);
		p.add(30);
		p.add(90);
		p.add(5);

		//		System.out.println(p);
		//		System.out.println(p.peek());
		Iterator<Integer> i =  p.iterator();
//		while(i.hasNext())
//		{
//			System.out.println(i.next());
//		}
		Integer v = i.next();
		System.out.println(v);
//		for(Integer j : i)
//		{
//			
//		}
		//		while(p.size()!=0)
		//		{
		//			System.out.println(p.poll());
		//		}

		HashSet<Integer> l = new HashSet<>(p);
		Iterator<Integer> j = 	l.iterator();
		boolean b = j.hasNext();
//		for()
//		while(j.hasNext())
//		{
//			System.out.println(j.next());
//		}


	}
}
