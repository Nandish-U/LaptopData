package com.treemap;

import java.util.Set;
import java.util.TreeMap;

public class Demo 
{
	public static void main(String[] args) 
	{
		TreeMap<Integer, String> t = new TreeMap<>();
		t.put(55, "hello");
		t.put(10, "hi");
		t.put(5, "good");
		t.put(25, "bye");
		t.put(80, "ok");
		System.out.println(t);
		Set<Integer> s =  t.keySet();
		for(Integer i :s)
		{
			System.out.println(i+"  --> "+t.get(i));
			 
		}
	}
}
