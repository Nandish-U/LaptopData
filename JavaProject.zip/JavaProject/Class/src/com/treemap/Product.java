package com.treemap;

public class Product implements Comparable<Product> {
	String pname;
	int id;
	public Product(String pname, int id) {
		super();
		this.pname = pname;
		this.id = id;
	}
	@Override
	public String toString() {
		return "Product" + pname + ", id=" + id;
	}
	public int compareTo(Product o)
	{
		return this.id-o.id;
	}
	
}
