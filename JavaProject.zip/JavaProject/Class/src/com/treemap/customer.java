package com.treemap;

public class customer implements Comparable<customer> {
	int id;
	String name;
	long phno;
	public customer(int id, String name, long phno) {
		super();
		this.id = id;
		this.name = name;
		this.phno = phno;
	}
	@Override
	public String toString() {
		return "customer id=" + id + ", name=" + name + ", phno=" + phno;
	}
	@Override
	public int compareTo(customer o) {
		// TODO Auto-generated method stub
		return this.id-o.id;
	}
	

}
