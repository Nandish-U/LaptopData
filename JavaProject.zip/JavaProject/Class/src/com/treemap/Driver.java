package com.treemap;

import java.util.TreeMap;

public class Driver {
	public static void main(String[] args) {
		TreeMap<Product, Integer> t = new TreeMap<>();
		t.put(new Product("mobile",5), 2);
		t.put(new Product("watch",8), 12);
		t.put(new Product("laptop",2), 16);
		t.put(new Product("mic",6), 11 );
		System.out.println(t);
	}

}
