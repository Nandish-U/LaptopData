package com.treemap;

import java.util.Set;
import java.util.TreeMap;

public class Driver1 {
	public static void main(String[] args) {
		TreeMap<customer, Integer> t=new TreeMap();
		t.put(new customer(1,"Smith",9876543210l), 1);
		t.put(new customer(3,"Allen",7890654321l), 3);
		t.put(new customer(6,"King",8765432109l), 6);
		t.put(new customer(9,"Omega",9876598765l), 9);
		t.put(new customer(7,"Dhoni",9876543210l), 7);
		Set<customer> s=t.keySet();
		for(customer c:s)
			System.out.println(c + ":::::::"+ t.get(c));
	}
}
