package com.vector;

import java.util.Scanner;

public class Driver {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		Employee e = new Employee();
		int a;

		while (true) {
			System.out.println("Enter your choice - ");
			System.out.println("1. Add employee details");
			System.out.println("2. Display employee details");
			a = s.nextInt();
			switch (a) {
			case (1): {
				e.add();
				break;
			}
			case (2): {
				e.display();
				break;
			}
			case 3:
				System.out.println("Thankyou");
				System.exit(0);
			}
		}

	}
}
