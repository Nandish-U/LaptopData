package com.vector;

import java.util.Vector;
import java.util.Collections;
import java.util.Scanner;

public class Employee implements Comparable{
	String name;
	int id;
	Vector<Employee> v = new Vector<Employee>();
	void add() {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter Name of employee");
		String name = s.nextLine();
		System.out.println("Enter id of employee");
		int id=s.nextInt();
		
		v.add(new Employee(name,id));
	}
	void display() {
//		System.out.println(v);
		for(int i=0; i<v.size();i++)
		{
			System.out.println(v);
			Collections.sort(v);
		}
	}
	public String toString() {
		return "The name of the employee is - " + name+"The ID of the employee is - " + id;
	}
	Employee(){
		
	}
	Employee(String name,int id){
		this.name=name;
		this.id=id;
		}
	public int compareTo(Object e) {
		Employee e1 = (Employee )e;
		return this.id-e1.id;
	}
}
