package com.wrapperclasses;

public class Un_Boxing {
	public static void main(String[] args) 
	{
		//boxing
		int a =10;
		// convert into object type
		
		Integer b = a; // successfully converted.
		System.out.println(b.hashCode());
		
		// unboxing
		int c = b;
		System.out.println(c);//10
		//System.out.println(c.toString());// converted back to primitive
	}
}
/*
 * 1. create byte type primitive variable and convert into object type 
 * and try to access some methods
 * 2. create boolean type primitve variable and convert into object tyep
 * and try to access some methods.
 */

