package com.wrapperclasses;

public class Demo {
	public static void main(String[] args) {
		// Boxing --> converting primitive value into object
		int a = 10;
		Integer b = a;
		System.out.println(a);
		System.out.println(b);
//		System.out.println(a.toString());//CTE ( with primitive variables we can't 
				// access method/behaviours
		System.out.println(b.hashCode());// 10
		System.out.println(b.toString());// 10
	}
}
