package com.map;

import java.util.HashMap;
import java.util.Set;

public class Demo 
{
	public static void main(String[] args) 
	{
		HashMap<Integer,employee> h=new HashMap<>();
		h.put(01, new employee(01, "Aman"));
		h.put(03, h.get(01));
		h.put(02, new employee(02, "Vikas"));
		System.out.println(h);
		Set<Integer> i= h.keySet();
		for(Integer s:i) {
			System.out.println(s);
		}
		
	}
}
