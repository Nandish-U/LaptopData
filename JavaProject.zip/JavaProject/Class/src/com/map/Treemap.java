package com.map;

import java.util.Comparator;
import java.util.TreeMap;

class Customer 
{
	String name;
	int id;
	String product;
	Customer(String name, int id, String product)
	{
		this.name = name;
		this.id = id;
		this.product = product;
	}
	public String toString()
	{
		return " name : "+name+" id : "+id+" product : "+product; 
	}
//	@Override
//	public int compareTo(Customer o) {
//		return this.name.compareTo(o.name);
//	}
	public int hashCode()
	{
		return product.hashCode();
	}
	public boolean equals(Object o)
	{
		Customer c = (Customer)o;
		return this.product.equals(c.product);
	}
}
class Sort implements Comparator<Customer>
{

	@Override
	public int compare(Customer o1, Customer o2) {
		return o1.product.compareTo(o2.product);
	}
	
}
public class Treemap 
{
	public static void main(String[] args) 
	{
		TreeMap<Customer, Integer> t = new TreeMap<>(new Sort());
		t.put(new Customer("nandi",1,"apple"), 5);
		t.put(new Customer("shree",4,"laptop"), 2);
		t.put(new Customer("sani",8,"earpodes"), 3);
		t.put(new Customer("raji",3,"apple"), 1);
		System.out.println(t);
	}
}
