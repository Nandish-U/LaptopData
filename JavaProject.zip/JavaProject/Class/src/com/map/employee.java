package com.map;

public class employee {
	int empid;
	String name;
	public employee(int empid, String name) {
		super();
		this.empid = empid;
		this.name = name;
	}
	@Override
	public String toString() {
		return "empid=" + empid + ", name=" + name;
	}

}
