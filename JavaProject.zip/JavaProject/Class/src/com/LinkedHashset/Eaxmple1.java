package com.LinkedHashset;

import java.util.LinkedHashSet;

public class Eaxmple1 {
	public static void main(String[] args) 
	{
		LinkedHashSet h = new LinkedHashSet<>();
		h.add(110);
		h.add(null);
		h.add('A');
		System.out.println(h);
	}
}
