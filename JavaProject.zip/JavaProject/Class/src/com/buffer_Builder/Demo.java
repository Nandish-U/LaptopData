package com.buffer_Builder;

public class Demo 
{
	public static void main(String[] args) 
	{
		StringBuffer a  = new StringBuffer("java");
		System.out.println(a);//toString() has been overriden
		StringBuffer b = a;
		System.out.println(b);
		a.append("sql");
		System.out.println(a);
		System.out.println(b);
		
		System.out.println(a==b);
		
		
		Demo d = new Demo();
		System.out.println(d);//toString() will get called from Objec class
		// 
	}
}
