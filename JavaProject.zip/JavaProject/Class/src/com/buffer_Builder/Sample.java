package com.buffer_Builder;

public class Sample 
{
	public static void main(String[] args) 
	{
		StringBuilder b = new StringBuilder("Program");
		System.out.println(b);
		StringBuilder c = b;
		System.out.println(c);
		b.append(" done");
		System.out.println("[===================");
		System.out.println(b);
		System.out.println(c);
		System.out.println(c==b);
	}
}
