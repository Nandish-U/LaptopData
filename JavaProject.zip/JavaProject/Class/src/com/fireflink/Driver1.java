package com.fireflink;

public class Driver1 
{
	public static void main(String[] args) {
		Driver1 a = new Driver1();
		System.out.println(new Driver1());
	}
}
