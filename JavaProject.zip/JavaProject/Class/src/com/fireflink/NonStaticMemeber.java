package com.fireflink;

public class NonStaticMemeber {
	int a;
	public void m2()
	{
		System.out.println(a);
		System.out.println("Non static method");
	}
	public static void main(String[] args)
	{
		System.out.println(new NonStaticMemeber());
	}
}
