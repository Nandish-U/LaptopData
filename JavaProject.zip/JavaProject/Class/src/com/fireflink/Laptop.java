package com.fireflink;

public class Laptop {
	static int id;
	public static void display()
	{
		System.out.println("Hello");
	}
}
