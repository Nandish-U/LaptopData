package com.fireflink;

public class Account {
	//global variables
	String name;
	long accno;
	double bal;
	static String bankName="Axis Bank";
	// consturctor is present
	public static void showBankName()
	{
		System.out.println(bankName);
	}
	public void deposit(double amount)
	{
		bal = bal+amount;
		System.out.println(bal);
	}
	public void withdraw(double amount)
	{
		bal = bal-amount;
		System.out.println(bal);
	}
	public static void main(String[] args) {
		Account person1 = new Account();
		person1.name="smith";
		person1.accno=9866536545l;
		person1.bal=1000.0;
		person1.showBankName();
		System.out.println(person1.name);
		System.out.println(person1.accno);
		System.out.println(person1.bal);
		System.out.println("================");
		
		Account person2 = new Account();
		person2.name="Allen";
		person2.accno=5651254785l;
		person2.bal=2500.0;
		person2.showBankName();
		System.out.println(person2.name);
		System.out.println(person2.accno);
		System.out.println(person2.bal);
		System.out.println("===========");
		Account person3 = person2;
		System.out.println(person3.name);
		System.out.println(person3.accno);
		System.out.println(person3.bal);
	}
}
/*
 *create a class called as student and have some data members like
 *sid,sname,class,schoolname,updateStudentName,displayAllData
 *
 *in a main method create 3 student objects and store the data 
 *and perform some operation
 * 
 * */
