package com.list;

public class Bike implements Comparable
{
	String bikename;
	int cc;
	
	Bike(String bikename, int cc)
	{
		this.bikename = bikename;
		this.cc = cc;
	}

	@Override
	public String toString() {
		return "bikename=" + bikename + ", cc=" + cc ;
	}

	@Override
	public int compareTo(Object o) {
		Bike b = (Bike)o;
		return b.cc-this.cc;
	}
	
}
