package com.list;

import java.util.ArrayList;
import java.util.Collections;

public class BikeDriver 
{
	public static void main(String[] args) 
	{
		ArrayList<Bike> a = new ArrayList<>();
		a.add(new Bike("Dominor",120));
		a.add(new Bike("ns200",250));
		a.add(new Bike("pulsar",200));
		a.add(new Bike("dio",110));
		System.out.println(a);
		Collections.sort(a);
		System.out.println(a);
	}
}
