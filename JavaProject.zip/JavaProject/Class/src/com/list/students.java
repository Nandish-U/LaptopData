package com.list;

public class students implements Comparable {
	int Class;
	String name;

	students(int Class, String name){
		this.Class=Class;
		this.name=name;
	}
	public String toString() {
		return "Class - "+ Class + ", Name - "+ name;
	}
	public int compareTo(Object o) {
		students s=(students)o;
		return this.Class-s.Class;
	}
}
