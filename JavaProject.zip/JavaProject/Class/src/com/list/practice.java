package com.list;

import java.util.ArrayList;

class Movies{
	String name;
	
	Movies(String name){
		this.name=name;
	}
	public String toString() {
		return "name - " + name;
	}
}

public class practice {
	public static void main(String[] args) {
		Movies m1=new Movies("kgf");
		Movies m2=new Movies("kgf2");
		Movies m3=new Movies("kgf3");
		
		ArrayList<Movies> a=new ArrayList<Movies>();
		a.add(m1);
		a.add(m2);
		a.add(m3);
		
		System.out.println(a);
		System.out.println(a.get(0));
		System.out.println(a.get(1));
		System.out.println(a.get(2));
		
	}
	

}
