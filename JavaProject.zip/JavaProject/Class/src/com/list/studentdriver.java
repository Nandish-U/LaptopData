package com.list;

import java.util.ArrayList;
import java.util.Collections;

public class studentdriver {
	public static void main(String[] args) {
		ArrayList<students> a=new <students>ArrayList();
		a.add(new students( 5, "smith"));
		a.add(new students( 3, "king"));
		a.add(new students( 9, "Ellen"));
		
		Collections.sort(a);
		System.out.println(a);
	}

}
