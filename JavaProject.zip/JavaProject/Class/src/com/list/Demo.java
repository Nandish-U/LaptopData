package com.list;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class Demo 
{
	public static void main(String[] args) 
	{
		ArrayList<Integer> a = new ArrayList<Integer>();
		a.add(10);
		a.add(80);
		a.add(30);
		a.add(50);
		a.add(5);
		a.add(65);
//		Iterator i = a.iterator();
//		while(i.hasNext())
//		{
//			System.out.println(i.next());
//		}
		ListIterator l = a.listIterator(3);
		while(l.hasPrevious())
		{
			System.out.println(l.next());
		}
//		a.remove(1);
//		System.out.println(a.size());
//		System.out.println(a.isEmpty());
//		System.out.println(a);
//		a.clear();
//		System.out.println(a.contains(a));
//		Collections.sort(a);
//		System.out.println(a);
		
		
		
		ArrayList<Integer> b = new ArrayList<>(a);
//		b.addAll(a);
		b.add(50);
	}
}
