package com.list;

import java.util.ArrayList;

class Employee
{
	String name;
	Employee(String name)
	{
		this.name = name;
	}
}
public class Student 
{
	String name;
	int id;
	Student(String name, int id)
	{
		this.name = name;
		this.id = id;
	}
	public String toString()
	{
		return "name : "+name+" id : "+id;
	}
	public static void main(String[] args)
	{
		Student s = new Student("Dinga", 1);
//		Student s1 = new Student("smith", 1);
//		Student s2 = new Student("allen", 1);
//		Student s3 = new Student("ford", 1);;
		
		Employee e = new Employee("King");
				
		ArrayList<Student> a = new ArrayList<Student>();
		a.add(s);
		System.out.println(a);
		
	}
}
