package com.stringclass;

public class Example1 
{
	public static void main(String[] args) 
	{
		String s = "Hello";
		System.out.println(s.toString());// in a string class toString() 
		// has been overriden
//		Example1 e = new Example1();
//		System.out.println(e);// toString() method will get called
//		System.out.println(e.toString());
	}
}
/*
 * Task of toString()
 * toString() method is present in Object class
 *  will return 3 things
 *  1. fully qualified class name
 *  2. @ character
 *  3. some hexadecimal value
 *  */

