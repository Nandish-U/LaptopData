package com.stringclass;

public class Example2
{
	public static void main(String[] args) 
	{
//		String s = "Hello";
//		String s1 = s;
//		System.out.println(s1==s);
//		
//		s = s.concat(" good morning");
//		System.out.println(s1==s);//?
//		
//		
//		String s2 = "hi";
//		String s3 = "Hi";
//		System.out.println(s2==s3);
//		System.out.println("==========================");
//		System.out.println(s2.hashCode());
//		System.out.println(s3.hashCode());
		System.out.println("============================");
		
//		String s5 = new String("bye");
		
//		System.out.println(s5.length());
//		System.out.println(s5.charAt(2));
		String s6 = new String("Hello");
		System.out.println(s6.substring(2));
		System.out.println(s6.indexOf('l'));
		
		
		
//		System.out.println("==========================");
//		System.out.println(s5.hashCode());
//		System.out.println(s6.hashCode());
//		System.out.println("==========================");
//		System.out.println(s5==s6);//false
//		System.out.println("=====================");
//		System.out.println(s5.equals(s6));
//		System.out.println(s5.equalsIgnoreCase(s6));
	}
}
