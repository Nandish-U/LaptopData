package com.strings;

public class Demo 
{
	public static void main(String[] args) 
	{
		String s1 = "hi";
		System.out.println(s1);//hi
		s1 = s1.concat("bye");
		System.out.println(s1);//hibye
		
	}
}
