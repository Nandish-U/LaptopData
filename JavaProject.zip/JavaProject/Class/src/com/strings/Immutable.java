package com.strings;

public class Immutable 
{
	public static void main(String[] args) 
	{
		String s1 = "hello";
		String s2 = s1;
		System.out.println(s1);
		System.out.println(s2);
		s1 = s1.concat("good evening");
		System.out.println("==============");
		System.out.println(s1);
		System.out.println(s2);
	}
}
