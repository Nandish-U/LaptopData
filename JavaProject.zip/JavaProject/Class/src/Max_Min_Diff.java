
public class Max_Min_Diff 
{
	public static void main(String[] args) 
	{
		int[][]b= {{1,2,3},{4,5,6},{7,8,9}};
		int max = 0;
		int min = b[0][0];
		for(int i=0 ;i<b.length; i++)
		{
			for(int j=0; j<b.length; j++)
			{
				if(b[i][j]>max)
				{
					max = b[i][j];
				}
				if(b[i][j]<min)
				{
					min = b[i][j];
				}
			}
		}
		System.out.println(max-min);
	}
}
