import java.util.SortedSet;
import java.util.TreeSet;

public class Tree {
	String name;
	Tree(String name)
	{
		this.name = name;
	}
	public int hashCode()
	{
		return name.hashCode();
	}
	public boolean equals(Object o)
	{
		Tree tt = (Tree)o;
		return this.name==tt.name;
	}
	public String toString()
	{
		return name;
	}
	public static void main(String[] args)
	{
		Tree t = new Tree("Hello");
		System.out.println(t.hashCode());
		System.out.println("======================");
		Tree t1 = new Tree("Hello");
		System.out.println(t1.hashCode());
		System.out.println(t==t1);
		System.out.println(t.equals(t1));
		Tree k = t1;
		System.out.println(t1==k);
		System.out.println(t1.equals(k));
	}
}
