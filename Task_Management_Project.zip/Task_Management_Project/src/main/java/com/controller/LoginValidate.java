package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.UserDao;
import com.dto.User;

@WebServlet(value="/service")
public class LoginValidate extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String user_email = req.getParameter("User_email");
		String user_password = req.getParameter("User_password");
				
		User user = UserDao.FindUser(user_email, user_password);
		System.out.println(user);
		if(user!=null)
		{
			if(user.getRole().equals("manager"))
			{
			RequestDispatcher dispatcher = req.getRequestDispatcher("Manager.jsp");
			dispatcher.forward(req, resp);
			}
			else if(user.getRole().equals("employee"))
			{
				RequestDispatcher dispatcher = req.getRequestDispatcher("Employee.jsp");
				dispatcher.forward(req, resp);
			}
		}
		else
		{
			PrintWriter printWriter = resp.getWriter();
			printWriter.print("<h1>No data found</h1>");
		}
	}
}
