package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.dto.User;

public class UserDao {
	static EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("vikas");
	static EntityManager entityManager = entityManagerFactory.createEntityManager();
	static EntityTransaction entityTransaction = entityManager.getTransaction();

//	static {
//		User user = FindUser("manager@abc.in", "manager@123");
//		if (user == null) {
//			user = new User();
//			user.setId(101);
//			user.setName("Raj");
//			user.setEmail("manager@abc.in");
//			user.setPassword("manager@123");
//			user.setRole("manager");
//			saveUser(user);
//		}
//	}

	public static User saveUser(User user) {
		entityTransaction.begin();
		entityManager.persist(user);
		entityTransaction.commit();
		return user;
	}

	public User updateUser(User user) {
		entityTransaction.begin();
		entityManager.merge(user);
		entityTransaction.commit();
		return user;
	}

	public User removeUser(User user) {
		entityTransaction.begin();
		entityManager.remove(user);
		entityTransaction.commit();
		return user;
	}

	public User FindUserById(int id) {
		User user = entityManager.find(User.class, id);
		return user;
	}

	public static User FindUser(String user_email, String user_password) {
		Query query = entityManager.createQuery("select s from User s ");
		List<User> user = query.getResultList();
//		User user1 =null;
		for (User user2 : user) {
			if (user2.getEmail().equals(user_email) && user2.getPassword().equals(user_password)) {
//				user1= user2;
				return user2;
			}
		}
		return null;
	}
}
