package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dto.Task;

public class TaskDao 
{
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("vikas");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction = entityManager.getTransaction();
	
	public Task saveUser(Task task)
	{
		entityTransaction.begin();
		entityManager.persist(task);
		entityTransaction.commit();
		return task;
	}
	public Task updateUser(Task task)
	{
		entityTransaction.begin();
		entityManager.merge(task);
		entityTransaction.commit();
		return task;
	}
	public Task removeUser(Task task)
	{
		entityTransaction.begin();
		entityManager.remove(task);
		entityTransaction.commit();
		return task;
	}
	public Task FindUserById(int id)
	{
		Task task = entityManager.find(Task.class, id);
		return task;
	}
}
