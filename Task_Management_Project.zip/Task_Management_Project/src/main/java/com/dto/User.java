package com.dto;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name="user_info")
public class User 
{
	@Id
	private int id;
	private String name;
	private String email;
	private String password;
	private String role;
	@OneToMany
	private List<Task> task;
	
}
