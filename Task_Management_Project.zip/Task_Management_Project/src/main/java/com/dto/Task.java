package com.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Task 
{
	@Id
	private int id;
	private String description;
	private String status;
	private String createdDateAndDate;
	private String CompletedDataAndTime;

}
