package edu.ty.userapp.controller;

import java.util.List;
import java.util.Scanner;

import edu.ty.userapp.bean.User;

public class UserViewForCsv {
	static Scanner input = new Scanner(System.in);

	public static User createUser() {
		User user = new User();
		System.out.println("enter user id");
		user.setId(input.nextInt());
		System.out.println("Enter user name");
		input.nextLine();
		user.setName(input.nextLine());
		System.out.println("Enter email");
		user.setEmail(input.next().toLowerCase());
		return user;
	}

	private static void printData(List<User> user) {

		System.out.println(user);
	}

	private static void resultInfo(boolean result) {
		if (result) {
			System.out.println("sucessfull");
		} else {
			System.out.println("Unsucessfull");
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		while (true) {
			System.out.println("enter choice");
			System.out.println("1.to save user");
			int choice = input.nextInt();
			switch (choice) {
			case 1: {
				boolean result = UserControllerForCsv.saveUser(createUser());
				resultInfo(result);
				break;
			}
			case 2: {

				List<User> user = UserControllerForCsv.findUser();
				printData(user);
				break;
			}
			}
		}

	}
}
