package edu.ty.userapp.controller;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import edu.ty.userapp.bean.User;

public class UserController {
	private static String filePath = "user.txt";
	private static List<User> userList = new ArrayList<User>();

	public static boolean saveUser(User user) {

		try {
			FileOutputStream fileOutput = new FileOutputStream(filePath, true);
			byte[] data = user.toString().getBytes();

			fileOutput.write(data);

			fileOutput.close();
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public static List<User> findUser() {
		try {
			InputStream stream = new FileInputStream(filePath);
			InputStreamReader inp = new InputStreamReader(stream);
			BufferedReader bf = new BufferedReader(inp);
			String line = "";
			while ((line = bf.readLine()) != null) {
				userList.add(convertToStudent(line));
			}
			stream.close();
			bf.close();
			return userList;

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private static User convertToStudent(String line) {
		User user = new User();
		String[] data = line.split(",");
		String[] id = data[0].split("=");
		user.setId(Integer.parseInt(id[1]));
		String[] name = data[1].split("=");
		user.setName(name[1]);
		String[] email = data[2].split("=");
		user.setEmail(email[1]);
		return user;
	}

	public static void sort(Scanner input) {
		List<User> user = findUser();
		System.out.println("enter the choice");
		System.out.println("1.sort by id assending");
		System.out.println("2.sort by id desending");
		int choice = input.nextInt();
		Comparator<User> com = null;
		switch (choice) {
		case 1: {
			com = (o1, o2) -> o1.getId() - o2.getId();
			break;
		}
		case 2: {
			com = (o1, o2) -> o2.getId() - o1.getId();
			break;
		}
		case 3: {
			com = (o1, o2) -> o1.getName().compareTo(o2.getName());
			break;
		}
		case 4: {
			com = (o1, o2) -> o2.getName().compareTo(o1.getName());
			break;
		}
		}
		if (com != null) {
			Collections.sort(user, com);

			System.out.println(user);
		}
	}
}