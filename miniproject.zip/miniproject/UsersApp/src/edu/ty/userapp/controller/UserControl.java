package edu.ty.userapp.controller;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import edu.ty.userapp.bean.User;

public class UserControl {

	public static void saveUser(User user) {
		String path="user1.ser";
		try  
        {  
            //Serialization  
            FileOutputStream fos=new FileOutputStream(path,true);  
            ObjectOutputStream oos=new ObjectOutputStream(fos);  
            oos.writeObject(user);  
            fos.close();  
            oos.close();  
        //    Deserialization  
            FileInputStream fis=new FileInputStream("file");  
            ObjectInputStream ois=new ObjectInputStream(fis); 
            System.out.println(ois.readObject());
            System.out.println(ois.readObject());
          ArrayList  list=(ArrayList)ois.readObject();  
          System.out.println(list);    
        }catch(Exception e)  
        {  
            System.out.println(e);  
        }  
	}
	public static void main(String[] args) {
		User user=new User();
		user.setId(2);
		user.setName("a5vith");
		user.setEmail("anvit2@gmailcom");
		
		saveUser(user);
	}
}
