package edu.ty.userapp.controller;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import edu.ty.userapp.bean.User;

public class UserControllerForCsv {

	private static String filePath = "user.csv";
	private static List<User> userList = new ArrayList<User>();

	public static boolean saveUser(User user) {
		try {
			FileOutputStream fileOutput = new FileOutputStream(filePath,true);
			byte[] data = user.toString().getBytes();

			fileOutput.write(data);

			fileOutput.close();
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	
	}
	public static List<User> findUser() {
		try {
			InputStream stream = new FileInputStream(filePath);
			InputStreamReader inp = new InputStreamReader(stream);
			BufferedReader bf = new BufferedReader(inp);
			String line = "";
			while ((line = bf.readLine()) != null) {
				userList.add(convertToStudent(line));
			}
			stream.close();
			bf.close();
			return userList;

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private static User convertToStudent(String line) {
		User user = new User();
		String[] data = line.split(",");
		user.setId(Integer.parseInt(data[0]));
		user.setName(data[1]);
		user.setEmail(data[2]);
		return user;
	}
	
	public static String updateUserEmailById(int id, String email) {
		User user = findUserByEmail(email);
		if (user != null) {

			user.setUserAge(age);
			return "user data updated";

		}
		return "user data not updated";

	}

	

	public static String removeUserByEmail(String email) {
		User user = findUserByEmail(email);
		if (user != null) {
			userList.remove(user);
			return "user data removed";

		}
		return "user data not found";
	}
}
