package com.anynomus;

abstract class person {

 abstract void eat();
}
interface Man {
	void dance();
}

public class Driver {
  static int i=0;
  public static void main(int a) {
	  
  }
	public static void main(String[] args) {
		
		System.out.println("main start");
		System.out.println(args.length);
		String[] a=new String[2];
		a[0]="hello";
		i++;
		if(i<3)
		main(10);
		return;
	}

}
