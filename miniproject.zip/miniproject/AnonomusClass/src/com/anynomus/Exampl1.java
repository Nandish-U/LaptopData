package com.anynomus;

import java.util.Comparator;
import java.util.TreeSet;

class Person1 {
    private String name;
    private int age;

    public Person1(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}

public class Exampl1 {
    public static void main(String[] args) {
        TreeSet<Person1> people = new TreeSet<>(Comparator.comparing(Person1::getAge));

        people.add(new Person1("John", 25));
        people.add(new Person1("Alice", 32));
        people.add(new Person1("Bob", 18));

        // Print sorted set
        for (Person1 person : people) {
            System.out.println(person.getName() + ": " + person.getAge());
        }
    }
}

