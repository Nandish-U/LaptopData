package com.anynomus;

public class PersonDriver extends person {

	@Override
	void eat() {
		// TODO Auto-generated method stub
		System.out.println("eat");
	}

	
	
}
