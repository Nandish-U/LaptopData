package edu.jsp.foodapp.controller;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import edu.jsp.foodapp.model.Recipe;
import edu.jsp.foodapp.model.RecipeType;

public class RecipeController {

	/**
	 * create a file path where data to be stored
	 */
	private String filePath = "foodInfo.csv";
	private List<Recipe> recipeList = new ArrayList<Recipe>();
    private boolean update;
	/**
	 * create a method to store data in file
	 * 
	 * @return boolean
	 */
	public boolean saveRecipe(Recipe recipe) {
		try {
			FileOutputStream fileOutput = new FileOutputStream(filePath, true);
			fileOutput.write(recipe.toString().getBytes());
			fileOutput.close();
			return true;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * create a method to store data in file
	 * 
	 * @return boolean
	 */
	public List<Recipe> fetchdata() {
		try {
			InputStream stream = new FileInputStream(filePath);
			InputStreamReader inputReader = new InputStreamReader(stream);
			BufferedReader bufferReader = new BufferedReader(inputReader);
			String line = "";
			while ((line = bufferReader.readLine()) != null) {
				recipeList.add(convertToRecipe(line));
			}
			stream.close();
			bufferReader.close();
			return recipeList;

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private static Recipe convertToRecipe(String line) {
		Recipe recipe = new Recipe();
		String[] data = line.split(",");
		recipe.setRecipeName(data[0]);
		recipe.setRecipeCusine(data[1]);
		recipe.setRecipeType(RecipeType.valueOf(data[2]));
		recipe.setRecipeCategory(data[3]);
		String[] time = data[4].split(":");
		int hours = Integer.parseInt(time[0]);
		int minutes = Integer.parseInt(time[1]);
		int seconds = Integer.parseInt(time[2]);
		Time times = new Time(hours, minutes, seconds);
		recipe.setRecipePerparationTime(times);
		recipe.setRecipeIngredients(data[5]);
		recipe.setRecipePrice(Double.parseDouble(data[6]));
		return recipe;
	}

	public Recipe fetchDataByName(String recipeName) {
		recipeList = fetchdata();
		for (Recipe recp : recipeList) {
			if (recipeName.equals(recp.getRecipeName())) {
				return recp;
			}
		}
		return null;
	}

	public boolean updatePriceByRecipeName(String recipeName, double price) {
		boolean flag = false;
		recipeList = fetchdata();
		for (Recipe recipe : recipeList) {
			if (recipe.getRecipeName().equalsIgnoreCase(recipeName)) {
				recipe.setRecipePrice(price);
				flag = true;
			}
		}
		try {
			FileOutputStream outputStream = new FileOutputStream(filePath);
			for (Recipe recipe : recipeList) {
				outputStream.write(recipe.toString().getBytes());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return flag;

	}

	public boolean removeRecipeByName(String recipeName) {
		Recipe recipe = fetchDataByName(recipeName);
		if (recipe != null) {
			recipeList.remove(recipe);
			return true;
		}
		return false;

	}

	public void sort(Scanner input) {
		List<Recipe> recipe = fetchdata();
		System.out.println("enter the choice");
		System.out.println("1.sort recipe name asending");
		System.out.println("2.sort recipe name desending");
		System.out.println("3.sort recipe price asending");
		System.out.println("4.sort recipe price desending");
		int choice = input.nextInt();
		Comparator<Recipe> comp = null;

		switch (choice) {
		case 1: {
			comp = (o1, o2) -> o1.getRecipeName().compareTo(o2.getRecipeName());
			break;
		}
		case 2: {
			comp = new Comparator<Recipe>() {
				@Override
				public int compare(Recipe o1, Recipe o2) {
					return o2.getRecipeName().compareTo(o1.getRecipeName());
				}
			};
			break;
		}
		case 3: {
			comp = (o1, o2) -> o1.getRecipePrice().compareTo(o2.getRecipePrice());
			break;
		}
		case 4: {
			comp = (o1, o2) -> o2.getRecipePrice().compareTo(o1.getRecipePrice());
			break;
		}
		default:
			comp = null;

		}
		if (comp != null) {
			recipe.sort(comp);
			System.out.println(recipe);
		}
	}
}
