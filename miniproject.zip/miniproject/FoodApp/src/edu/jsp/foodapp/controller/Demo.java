package edu.jsp.foodapp.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo {
	static int num;
	int a;

	static {
		System.out.println(num + " InSide Static Block");
	}

	{
		System.out.println(a + " InSide Non-Static Block");
	}

	public Demo() {
		System.out.println(a + " InSide Cons");
	}

	public static void main(String[] args) {
		Connection con;
		try {
			Class.forName("org.postgresql.Driver");
			con=DriverManager.getConnection("h1");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Statement stat=con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
