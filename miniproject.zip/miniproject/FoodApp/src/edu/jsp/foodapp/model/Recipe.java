package edu.jsp.foodapp.model;

import java.io.Serializable;
import java.sql.Time;

public class Recipe implements Serializable{
	
	private String recipeName;
	private String recipeCusine;
	private RecipeType recipeType;
	private String recipeCategory;
	private Time recipePerparationTime;
	private String recipeIngredients;
	private double recipePrice;
	public String getRecipeName() {
		return recipeName;
	}
	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}
	public String getRecipeCusine() {
		return recipeCusine;
	}
	public void setRecipeCusine(String recipeCusine) {
		this.recipeCusine = recipeCusine;
	}
	public RecipeType getRecipeType() {
		return recipeType;
	}
	public void setRecipeType(RecipeType recipeType) {
		this.recipeType = recipeType;
	}
	public String getRecipeCategory() {
		return recipeCategory;
	}
	public void setRecipeCategory(String recipeCategory) {
		this.recipeCategory = recipeCategory;
	}
	public Time getRecipePerparationTime() {
		return recipePerparationTime;
	}
	public void setRecipePerparationTime(Time recipePerparationTime) {
		this.recipePerparationTime = recipePerparationTime;
	}
	public String getRecipeIngredients() {
		return recipeIngredients;
	}
	public void setRecipeIngredients(String recipeIngredients) {
		this.recipeIngredients = recipeIngredients;
	}
	public Double getRecipePrice() {
		return recipePrice;
	}
	public void setRecipePrice(double recipePrice) {
		this.recipePrice = recipePrice;
	}
	@Override
	public String toString() {
		return  recipeName + "," + recipeCusine + "," + recipeType
				+ "," + recipeCategory + "," + recipePerparationTime
				+ "," + recipeIngredients + "," + recipePrice + "\n";
	}
	
	
	

	
}
