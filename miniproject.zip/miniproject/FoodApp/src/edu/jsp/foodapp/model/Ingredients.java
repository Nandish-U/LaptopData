package edu.jsp.foodapp.model;

/**
 * @author Anwith gowda
 *
 */
public class Ingredients {

	private String ingredientName;
	int ingredientQuantity;

	public String getIngredientName() {
		return ingredientName;
	}

	public void setIngredientName(String ingredientName) {
		this.ingredientName = ingredientName;
	}

	public int getIngredientQuantity() {
		return ingredientQuantity;
	}

	public void setIngredientQuantity(int ingredientQuantity) {
		this.ingredientQuantity = ingredientQuantity;
	}

}
