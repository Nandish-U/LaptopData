package edu.jsp.foodapp.model;

public enum RecipeType {

	VEG,NONVEG;
}
