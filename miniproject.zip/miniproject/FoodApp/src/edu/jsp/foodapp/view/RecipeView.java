package edu.jsp.foodapp.view;

import java.sql.Time;
import java.util.List;
import java.util.Scanner;

import edu.jsp.foodapp.controller.RecipeController;
import edu.jsp.foodapp.model.Recipe;
import edu.jsp.foodapp.model.RecipeType;

public class RecipeView {

	static Scanner input =new Scanner(System.in);
	static {
		System.out.println("Welcome To Food App");
	}
	/***
	 * method to print the data
	 * @param recipe
	 */
	static void printData(Recipe recipe) {
		System.out.println(recipe);
	}
	public static void main(String[] args) {
		RecipeController controller=new RecipeController();
		while(true) {

		System.out.println("1.Save the Recipe");
		System.out.println("2.Find a Menu");
		System.out.println("3.Get Recipe By Name");
		System.out.println("4.update Recipe Price by name");
		System.out.println("5.Remove the Recipe By Name");
		System.out.println("6.Search on sort Operation");
		System.out.println("7.Exit");
		int choice=input.nextInt();
		switch(choice) {
		case 1:{
			boolean result=controller.saveRecipe(createRecipe());
			giveInfoToUser(result);
			break;
		}
		case 2:{
			List<Recipe> list=controller.fetchdata();
			printAllData(list);
			break;
		}
		case 3:{
			System.out.println("enter recipe name ");
			Recipe recipe=controller.fetchDataByName(input.next());
			printData(recipe);
			break;
		}
		case 4:{
			boolean result=controller.updatePriceByRecipeName(userInputName(), userInputPrice());
			giveInfoToUser(result);
			break;
		}
		case 5:{
			boolean result=controller.removeRecipeByName(userInputName());
			giveInfoToUser(result);
			break;
		}
		case 6:{
			controller.sort(input);
			break;
		}
		case 7:{
			System.exit(0);
		}
			default:{
				System.out.println("invalid choice");
			}
		}
		}	
	}
	private static void printAllData(List<Recipe> list) {
		System.out.println(list);
		
	}
	private static double userInputPrice() {
		System.out.println("enter the price");
		return input.nextDouble();
	}
	private static String userInputName() {
		System.out.println("enter recipe name");
		return input.next();
	}
	/***
	 * print updated result to user
	 * @param result
	 */
	
	private static void giveInfoToUser(boolean result) {

		if(result) {
			System.out.println("sucessfull");
		}
		else {
			System.out.println("Unsucessfull");
		}
		
	}
	/**
	 * create a recipe object and return the value to the caller to save the data
	 * @return Recipe
	 */
	private static Recipe createRecipe() {
		Recipe recipe =new Recipe();
		System.out.println("Enter the recipe Name");
		input.nextLine();
		recipe.setRecipeName(input.nextLine());
		System.out.println("Enter the recipe Cusine");
		recipe.setRecipeCusine(input.nextLine());
		System.out.println("Select the recipe Type \n1.VEG \n2.NON-VEG");
		int choice=input.nextInt();
		switch(choice) {
		case 1:{
			recipe.setRecipeType(RecipeType.VEG);
			break;
		}
		case 2:
			recipe.setRecipeType(RecipeType.NONVEG);
			break;
		default:{
			System.out.println("Invalid choice Taken as VEG");
			recipe.setRecipeType(RecipeType.VEG);
		}
		}
		
		input.nextLine();
		System.out.println("Enter the recipe Categoery");
		recipe.setRecipeCategory(input.nextLine());
		System.out.println("Enter the recipe Preparation Time");
		recipe.setRecipePerparationTime(prepationTime());
		System.out.println("Enter the recipe Ingredients");
		input.nextLine();
		recipe.setRecipeIngredients(input.nextLine());
		System.out.println("Enter the recipe Price");
		recipe.setRecipePrice(input.nextDouble());
		
		
		return recipe;
	}
	private static Time prepationTime() {
		System.out.println("Enter the time in HH:MM:SS");
		String[] time=input.next().split(":");
		int hours=Integer.parseInt(time[0]);
		int minutes=Integer.parseInt(time[1]);
		int seconds=Integer.parseInt(time[2]);
		return new Time(hours, minutes, seconds);
	}

}
