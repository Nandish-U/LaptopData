package edu.ty.carmodel.view;

import java.util.List;
import java.util.Scanner;

import edu.ty.carmodel.controller.*;
import edu.ty.carmodel.util.FuelType;
import edu.ty.carmodel.bean.Car;

public class CarView {

	static {
		System.out.println("Welcome Student App");
	}
	static Scanner input = new Scanner(System.in);

	public static Car createCarObject() {
		Car car = new Car();
		System.out.println("enter engine number");
         car.setEngineNumber(input.next());
         System.out.println("enter chassie number");
         car.setChassieNumber(input.next());
         System.out.println("enter the brand");
         car.setBrand(input.next());
         System.out.println("enter the model");
         car.setModel(input.next());
         System.out.println("enter manufactuer year");
         car.setYear(input.nextInt());
         System.out.println("enter the color");
         car.setColor(input.next());
         System.out.println("Select the fuel type as 1.PETROL,\n2.DIESEL,\n3.EV");
 		int fuelChoice = input.nextInt();
 		switch (fuelChoice) {
 		case 1: {
 			car.setFuelType(FuelType.PETROL);
 			break;
 		}
 		case 2: {
 			car.setFuelType(FuelType.DIESEL);
 			break;
 		}
 		case 3: {
 			car.setFuelType(FuelType.EV);
 		}
 		}
         System.out.println("enter the price");
         car.setPrice(input.nextDouble());
		return car;
	}

	public static void printData(List<Car> carList) {
		for (Car car : carList) {
			System.out.println(car);
			System.out.println("================");
		}
	}

	public static void main(String[] args) {

		while (true) {
			System.out.println("1.Save Car");
			System.out.println("2.Fetch car by enginenumber");
			System.out.println("3.Fetch All records");
			System.out.println("4.Update Car model by engine number");
			System.out.println("5.Update Car Chassie number by engine number");
			System.out.println("6.Delete car by engine number");
			System.out.println("7.Exit");
			System.out.println("select choice");
			int choice = input.nextInt();

			switch (choice) {
			case 1: {
				Car car = createCarObject();
				CarController.saveCar(car);
				break;
			}
			case 2: {
				System.out.println("Enter the engine number");
				Car car = CarController.findCarBYEngineNumber(input.next());
				System.out.println(car);
				break;
			}
			case 3: {
				List<Car> carList = CarController.viewAllCar();
				printData(carList);
				break;
			}
			case 4: {
				System.out.println("enter the model and enginenumber");
				boolean result = CarController.updateCarModelByEngineNumber(input.next(), input.next());
				if (result)
					System.out.println("data updated");
				else
					System.out.println("data not found");
				break;
			}
			case 5: {
				System.out.println("enter the chassie number and enginenumber");
				boolean result = CarController.updateCarModelByEngineNumber(input.next(), input.next());
				if (result)
					System.out.println("data updated");
				else
					System.out.println("data not found");
				break;
			}
			case 6: {
				System.out.println("Enter the enginenumber");
				boolean result = CarController.removeCarByEngineNumber(input.next());
				if (result)
					System.out.println("data deleted");
				else
					System.out.println("data not found");
				break;
			}
			case 7: {
				System.out.println("Thank You");
				input.close();
				System.exit(0);
			}
			default:
				System.out.println("invalid choice");
			}
		}
	}
}