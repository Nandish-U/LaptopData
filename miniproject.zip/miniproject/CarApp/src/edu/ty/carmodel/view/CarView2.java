package edu.ty.carmodel.view;

import java.util.Comparator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import edu.ty.carmodel.bean.Car;
import edu.ty.carmodel.controller.CarController2;
import edu.ty.carmodel.util.FuelType;

public class CarView2 {

	static {
		System.out.println("Welcome Student App");
	}
	static Scanner input = new Scanner(System.in);

	/**
	 * method to create a object then return object to caller
	 * 
	 * @author Anwith gowda
	 * @date 7 JUL 2023
	 * 
	 */
	public static Car createCarObject() {
		Car car = new Car();
		System.out.println("enter engine number");
		car.setEngineNumber(input.next());
		System.out.println("enter chassie number");
		car.setChassieNumber(input.next());
		System.out.println("enter the brand");
		car.setBrand(input.next());
		System.out.println("enter the model");
		car.setModel(input.next());
		System.out.println("enter manufactuer year");
		car.setYear(input.nextInt());
		System.out.println("enter the color");
		car.setColor(input.next());
		System.out.println("Select the fuel type as \n1.PETROL,\n2.DIESEL,\n3.EV");
		int fuelChoice = input.nextInt();
		switch (fuelChoice) {
		case 1: {
			car.setFuelType(FuelType.PETROL);
			break;
		}
		case 2: {
			car.setFuelType(FuelType.DIESEL);
			break;
		}
		case 3: {
			car.setFuelType(FuelType.EV);
		}
		}
		System.out.println("enter the price");
		car.setPrice(input.nextDouble());
		return car;
	}

	public static void printData(Car c) {
		System.out.println(c);
	}

	public static void userMessage(int choice) {
		switch (choice) {
		case 1: {
			System.out.println("enter the engine number");
			break;
		}
		case 2: {
			System.out.println("enter the model and engine number");
			break;
		}
		case 3: {
			System.out.println("enter the chassie number and enginenumber");
			break;
		}
		case 4: {
			System.out.println("Thank You");
			break;
		}
		}
	}

	public static void operationResult(boolean result) {

		if (result)
			System.out.println("Sucessful");
		else
			System.out.println("Unsucessful");

	}

	public static void printAllData(Map<String, Car> car) {
		System.out.println("1.sort car brand by asending");
		System.out.println("2.sort car brand by desending");
		System.out.println("3.sort brand by desending");
		System.out.println("4.sort brand by desending");
		System.out.println("enter the choice");
		int choice = input.nextInt();
		Comparator<Car> com = null;
		switch (choice) {

		case 1: {
			com = (o1, o2) -> o1.getBrand().compareTo(o2.getBrand());

			break;
		}
		case 2: {
			com = (o1, o2) -> o2.getBrand().compareTo(o1.getBrand());

			break;
		}
		case 3: {
			com = (o1, o2) -> o2.getPrice().compareTo(o1.getPrice());
			break;
		}
		case 4: {
			com = (o1, o2) -> o1.getPrice().compareTo(o2.getPrice());
			break;
		}
		}
		Set<String> keys = car.keySet();
		if (com != null) {
			TreeSet<Car> ts;
			ts = new TreeSet<Car>(com);
			for (String key : keys) {
				Car c = car.get(key);
				ts.add(c);
			}
			System.out.println(ts);
		}
//		Comparator<Car> com=new Comparator<Car>() {
//
//			@Override
//			public int compare(Car o1, Car o2) {
//				// TODO Auto-generated method stub
//				return o1.getBrand().compareTo(o2.getBrand());
//			}
//		};

//		System.out.println(car.values());
	}

	public static void main(String[] args) {

		while (true) {
			System.out.println("1.Save Car");
			System.out.println("2.Fetch car by enginenumber");
			System.out.println("3.Fetch All records");
			System.out.println("4.Update Car model by engine number");
			System.out.println("5.Update Car Chassie number by engine number");
			System.out.println("6.Delete car by engine number");
			System.out.println("7.Exit");
			System.out.println("select choice");
			int choice = input.nextInt();

			switch (choice) {
			case 1: {
				Car car = createCarObject();
				CarController2.saveCar(car);
				break;
			}
			case 2: {
				userMessage(1);
				Car car = CarController2.findCarByEngineNumber(input.next());
				printData(car);
				break;
			}
			case 3: {
				Map<String, Car> carList = CarController2.viewAllCar();
				printAllData(carList);
				break;
			}
			case 4: {
				userMessage(2);
				boolean result = CarController2.updateCarmodelByEngineNumber(input.next(), input.next());
				operationResult(result);
				break;
			}
			case 5: {
				userMessage(3);
				boolean result = CarController2.updateCarChassieByEngineNumber(input.next(), input.next());
				operationResult(result);
				break;
			}
			case 6: {
				userMessage(1);
				boolean result = CarController2.removeCarByEngineNumber(input.next());
				operationResult(result);
				break;
			}
			case 7: {
				userMessage(4);
				input.close();
				System.exit(0);
			}
			default:
				System.out.println("invalid choice");
			}
		}
	}

}
