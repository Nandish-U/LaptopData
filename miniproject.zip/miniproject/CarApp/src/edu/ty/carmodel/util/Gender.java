package edu.ty.carmodel.util;

public enum Gender {

	MALE,FEMALE,OTHER;
}
