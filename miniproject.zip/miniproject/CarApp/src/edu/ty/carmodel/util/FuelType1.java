package edu.ty.carmodel.util;

public enum FuelType1 {

	PETROL,DIESEL,EV
}
