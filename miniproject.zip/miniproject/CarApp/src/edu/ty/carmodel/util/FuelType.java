package edu.ty.carmodel.util;

public enum FuelType {

	PETROL,DIESEL,EV;
}
