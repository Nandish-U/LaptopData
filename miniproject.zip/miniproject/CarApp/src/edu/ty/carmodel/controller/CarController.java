package edu.ty.carmodel.controller;

import java.util.ArrayList;
import java.util.List;

import edu.ty.carmodel.bean.Car;

public class CarController {

	private static List<Car> carList = new ArrayList<Car>();

	/**
	 * this method save the car object into the arraylist
	 * 
	 * @author Anwith gowda
	 * @date 07 JUL 2023
	 */
	public static void saveCar(Car car) {
		carList.add(car);
	}

	/**
	 * this method fetch the car object into the by engine number
	 * 
	 * @author Anwith gowda
	 * @date 07 JUL 2023
	 */
	public static Car findCarBYEngineNumber(String engineNumber) {
		for (Car car : carList) {
			if (car.getEngineNumber().equals(engineNumber)) {
				return car;
			}
		}
		return null;
	}

	/**
	 * this method get all the object in arraylist
	 * 
	 * @author Anwith gowda
	 * @date 07 JUL 2023
	 */
	public static List<Car> viewAllCar() {
		return carList;
	}

	/**
	 * this method update the model using engine number in the car object into the
	 * arraylist
	 * 
	 * @author Anwith gowda
	 * @date 07 JUL 2023
	 */
	public static boolean updateCarModelByEngineNumber(String model, String engineNumber) {
		Car car = findCarBYEngineNumber(engineNumber);
		if (car != null) {
			car.setModel(model);
			return true;

		}
		return false;
	}

	/**
	 * this method update the chassienumber using engine number in the car object
	 * into the arraylist
	 * 
	 * @author Anwith gowda
	 * @date 07 JUL 2023
	 */
	public static boolean updateCarChassieByEngineNumber(String chassieNumber, String engineNumber) {
		Car car = findCarBYEngineNumber(engineNumber);
		if (car != null) {
			car.setChassieNumber(chassieNumber);
			return true;
		}
		return false;
	}

	/**
	 * this method remove the car object into the arraylist
	 * 
	 * @author Anwith gowda
	 * @date 07 JUL 2023
	 */
	public static boolean removeCarByEngineNumber(String engineNumber) {
		Car car = findCarBYEngineNumber(engineNumber);
		if (car != null) {
			carList.remove(car);
			return true;

		}
		return false;
	}
}
