package edu.ty.carmodel.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import edu.ty.carmodel.bean.Car;

public class CarController2 {

	private static Map<String, Car> map = new HashMap<String, Car>();

	public static void saveCar(Car car) {
		map.put(car.getEngineNumber(), car);
	}

	public static Car findCarByEngineNumber(String engineNumber) {
		Set<String> keys = map.keySet();
		for (String key : keys) {
			if (key.equals(engineNumber)) {
				
				return map.get(key);
			}
		}
		return null;
	}
	public static Map<String,Car> viewAllCar() {
		return map;
	}
	public static boolean updateCarmodelByEngineNumber(String model,String engineNumber) {
		Car car=findCarByEngineNumber(engineNumber);
		if(car!=null) {
			car.setModel(model);
			return true;
		}
		return false;
			
	}
	/**
	 * this method update the chassienumber using engine number in the car object
	 * into the arraylist
	 * 
	 * @author Anwith gowda
	 * @date 07 JUL 2023
	 */
	public static boolean updateCarChassieByEngineNumber(String chassieNumber, String engineNumber) {
		Car car = findCarByEngineNumber(engineNumber);
		if (car != null) {
			car.setChassieNumber(chassieNumber);
			return true;
		}
		return false;
	}
	public static boolean removeCarByEngineNumber(String engineNumber) {
		Car car=findCarByEngineNumber(engineNumber);
		if(car!=null) {
			map.remove(engineNumber);
			return true;
		}
		return false;
	}
}
