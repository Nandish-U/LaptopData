package edu.ty.carmodel.sort;

import java.util.Comparator;

import edu.ty.carmodel.bean.Car;

public class SortCarByBrandDesending implements Comparator<Car> {
	@Override
	public int compare(Car x, Car y) {
		return y.getBrand().compareTo(x.getBrand());
	}

}
