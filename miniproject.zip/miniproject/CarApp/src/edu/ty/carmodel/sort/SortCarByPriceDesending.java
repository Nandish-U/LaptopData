package edu.ty.carmodel.sort;

import java.util.Comparator;

import edu.ty.carmodel.bean.Car;

public class SortCarByPriceDesending implements Comparator<Car> {

	@Override
	public int compare(Car o1, Car o2) {
		// TODO Auto-generated method stub
		return o2.getPrice().compareTo(o1.getPrice());
	}

}
