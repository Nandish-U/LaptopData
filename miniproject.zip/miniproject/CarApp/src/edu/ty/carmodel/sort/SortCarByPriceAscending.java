package edu.ty.carmodel.sort;

import java.util.Comparator;

import edu.ty.carmodel.bean.Car;

public class SortCarByPriceAscending implements Comparator<Car> {

	@Override
	public int compare(Car x, Car y) {
		return x.getPrice().compareTo(y.getPrice());
	}

}
