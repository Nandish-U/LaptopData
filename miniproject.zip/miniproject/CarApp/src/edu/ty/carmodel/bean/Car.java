package edu.ty.carmodel.bean;

import java.io.Serializable;

import edu.ty.carmodel.util.FuelType;

public class Car implements Serializable{
	private String engineNumber;
	private String chassieNumber;
	private String brand;
	private String model;
	private int year;
	private String color;
	private FuelType fuelType;
	private Double price;

	public String getEngineNumber() {
		return engineNumber;
	}

	public void setEngineNumber(String engineNumber) {
		this.engineNumber = engineNumber;
	}

	public String getChassieNumber() {
		return chassieNumber;
	}

	public void setChassieNumber(String chassieNumber) {
		this.chassieNumber = chassieNumber;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public FuelType getFuelType() {
		return fuelType;
	}

	public void setFuelType(FuelType fuelType) {
		this.fuelType = fuelType;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "engineNumber=" + engineNumber + "\nchassieNumber=" + chassieNumber + "\nbrand=" + brand + "\nmodel="
				+ model + "\nyear=" + year + "\ncolor=" + color + "\nfuelType=" + fuelType + "\nprice=" + price+"\n\n"
						+ "====================";
	}

	

	
}
