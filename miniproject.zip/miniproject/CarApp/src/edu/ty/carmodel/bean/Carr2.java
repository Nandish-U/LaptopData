package edu.ty.carmodel.bean;

import java.util.Comparator;
import java.util.TreeSet;

public class Carr2  {

	int id;
	String name;
	
	
	
	public Carr2(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Carr2 c1=new Carr2(4,"a");
		Carr2 c2=new Carr2(2,"p");
		Carr2 c3=new Carr2(3,"x");
		Carr2 c4=new Carr2(1,"y");
		TreeSet<Carr2> t=new TreeSet<>();
		t.add(c1);
		t.add(c2);
		t.add(c3);
		t.add(c4);
		
		
		
		System.out.println(t);
	}
	

	@Override
	public String toString() {
		return "id=" + id + ", name=" + name + "\n";
	}

	

}
