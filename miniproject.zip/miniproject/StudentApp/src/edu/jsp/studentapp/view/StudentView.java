package edu.jsp.studentapp.view;

import java.util.List;
import java.util.Scanner;

import edu.jsp.studentapp.bean.Student;
import edu.jsp.studentapp.controller.StudentController;
import edu.jsp.studentapp.exception.InvalidChoiceException;

public class StudentView {

	static {
		System.out.println("Welcome Student App");
	}
	static Scanner input = new Scanner(System.in);

	public static Student createStudentObject() {

		Student student = new Student();
		System.out.println("enter student id");
		student.setStudentId(input.nextInt());
		System.out.println("enter Student name");
		student.setStudentName(input.next());
		System.out.println("Enter Student email");
		student.setStudentEmail(input.next().toLowerCase());
		System.out.println("Enter Student Phone");
		student.setStudentPhone(input.nextLong());
		System.out.println("Enter Student Age");
		student.setStudentAge(input.nextInt());
		return student;
	}

	public static void printData(List<Student> studentList) {
		for (Student student : studentList) {
			System.out.println(student);
			System.out.println("================");
		}
	}

	public static void main(String[] args) {

		while (true) {
			System.out.println("1.Save user");
			System.out.println("2.Fetch user by id");
			System.out.println("3.Fetch tabel");
			System.out.println("4.Update user by id");
			System.out.println("5.Delete user by id");
			System.out.println("6.Exit");
			System.out.println("select choice");
			int choice = input.nextInt();

			switch (choice) {
			case 1: {
				Student student = createStudentObject();
				StudentController.saveStudent(student);
				break;
			}
			case 2: {
				System.out.println("Enter the id");
				Student student = StudentController.findStudentByid(input.nextInt());
				System.out.println(student);
				break;
			}
			case 3: {
				List<Student> studentList = StudentController.fetchAllData();
				printData(studentList);
				break;
			}
			case 4: {
				System.out.println("enter the id and phone");
				boolean result = StudentController.updateStudentPhoneById(input.nextInt(), input.nextLong());
				if (result)
					System.out.println("data updated");
				else
					System.out.println("data not found");
				break;
			}
			case 5: {
				System.out.println("Enter the id");
				boolean result = StudentController.removeStudentById(input.nextInt());
				if (result)
					System.out.println("data deleted");
				else
					System.out.println("data not found");
				break;
			}
			case 6: {
				System.out.println("Thank You");
				input.close();
				System.exit(0);
			}
			default:
				try {
					throw new InvalidChoiceException("Invalid choice");
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
			}
		}
	}
}
