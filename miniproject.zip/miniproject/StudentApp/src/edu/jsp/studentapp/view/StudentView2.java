package edu.jsp.studentapp.view;

import java.util.Map;
import java.util.Scanner;
import edu.jsp.studentapp.bean.Student;
import edu.jsp.studentapp.controller.StudentController2;
import edu.jsp.studentapp.exception.InvalidChoiceException;

public class StudentView2 {

	static {
		System.out.println("Welcome Student App");
	}
	static Scanner input = new Scanner(System.in);

	public static Student createStudentObject() {

		Student student = new Student();
		System.out.println("enter student id");
		student.setStudentId(input.nextInt());
		System.out.println("enter Student name");
		student.setStudentName(input.next());
		System.out.println("Enter Student email");
		student.setStudentEmail(input.next().toLowerCase());
		System.out.println("Enter Student Phone");
		student.setStudentPhone(input.nextLong());
		System.out.println("Enter Student Age");
		student.setStudentAge(input.nextInt());
		return student;
	}
	public static void getUpdateResult(boolean result) {
		if (result)
			System.out.println("Sucessful");
		else
			System.out.println("Not Sucessful");
	}

	public static void main(String[] args) {

		while (true) {
			System.out.println("1.Save user");
			System.out.println("2.Fetch user by id");
			System.out.println("3.Fetch All student");
			System.out.println("4.Update Student by id");
			System.out.println("5.Delete Student by id");
			System.out.println("6.Exit");
			System.out.println("select choice");
			int choice = input.nextInt();

			switch (choice) {
			case 1: {
				Student student = createStudentObject();
				StudentController2.saveStudent(student);
				break;
			}
			case 2: {
				System.out.println("Enter the id");
				Student student = StudentController2.findStudentByid(input.nextInt());
				System.out.println(student);
				break;
			}
			case 3: {
				Map<Integer, Student> studentList = StudentController2.fetchAllData();
				System.out.println(studentList.values());
				System.out.println("======================");
				break;
			}
			case 4: {
				System.out.println("enter the id and phone");
				boolean result = StudentController2.updateStudentPhoneById(input.nextInt(), input.nextLong());
				
				break;
			}
			case 5: {
				System.out.println("Enter the id");
				boolean result = StudentController2.removeStudentById(input.nextInt());
				if (result)
					System.out.println("data deleted");
				else
					System.out.println("data not found");
				break;
			}
			case 6: {
				System.out.println("Thank You");
				input.close();
				System.exit(0);
			}
			default:
				try {
					throw new InvalidChoiceException("Invalid choice");
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
			}
		}
	}
}
