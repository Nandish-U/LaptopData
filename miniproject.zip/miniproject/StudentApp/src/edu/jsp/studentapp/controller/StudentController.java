package edu.jsp.studentapp.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import edu.jsp.studentapp.bean.Student;

/**
 * @author Anwith gowda
 *
 */
public class StudentController {

	private static List<Student> studentList = new ArrayList<Student>();

	/**
	 * this method store the student object in ArrayList
	 * 
	 * @author Anwith gowda
	 * @date 2023 Jul 06
	 * 
	 */
	public static void saveStudent(Student student) {
		student.setStudentEmail(student.getStudentEmail().toLowerCase());
		studentList.add(student);
	}

	/**
	 * this method store the fetch student data in ArrayList by id
	 * 
	 * @author Anwith gowda
	 * @return
	 * @date 2023 Jul 06
	 * 
	 */
	public static Student findStudentByid(int id) {
		Iterator<Student> i = studentList.iterator();
		while (i.hasNext()) {
//			i.next().getStudentId();

			Student su = i.next();
			if (su.getStudentId() == id) {
				return su;
			}

		}
		return null; 
	}

	public static List<Student> fetchAllData() {

		return studentList;
	}

	/**
	 * this method store the update student data in ArrayList by id
	 * 
	 * @author Anwith gowda
	 * @return
	 * @date 2023 Jul 06
	 * 
	 */

	public static boolean updateStudentPhoneById(int id, long phone) {
		Student student = findStudentByid(id);
		if (id == student.getStudentId()) {
			student.setStudentPhone(phone);
			return true;
		}

		return false;

	}

	/**
	 * this method store the delete student data in ArrayList by id
	 * 
	 * @author Anwith gowda
	 * @return
	 * @date 2023 Jul 06
	 * 
	 */

	public static boolean removeStudentById(int id) {
		Student student = findStudentByid(id);
		if (id == student.getStudentId()) {
			studentList.remove(student);
			return true;
		}

		return false;

	}
}
