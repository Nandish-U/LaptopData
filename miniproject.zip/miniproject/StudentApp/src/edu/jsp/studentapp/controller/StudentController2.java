package edu.jsp.studentapp.controller;

import java.util.HashMap;
import java.util.Map;

import edu.jsp.studentapp.bean.Student;



public class StudentController2 {

	private static Map<Integer, Student> map = new HashMap<Integer, Student>();

	/**
	 * the saveStudent() is accepting student object 
	 * adding student to object to my map if that id is not there and return true
	 * if the id is present then @return boolean values
	 * 
	 * @author Anwith gowda
	 * @date 07-JUL-2023
	 */
	public static boolean saveStudent(Student student) {
		if(!map.containsKey(student.getStudentId())) {
		map.put(student.getStudentId()	, student);
		return true;
		}
		return false;
	}

	/**
	 * the fetchStudentById() is accepting id  
	 * this check weather object is present or not to id 
	 * if the id is present then @return object of id 
	 * else @return null
	 
	 * @author Anwith gowda
	 * @date 07-JUL-2023
	 */

	public static Student findStudentByid(int id) {
	    if(map.containsKey(id)) {
	    	return map.get(id);
	    }
		return null;
	}

	/**
	 * the fetchAllData()  
	 * @return entire data present in a map
	 
	 * @author Anwith gowda
	 * @date 07-JUL-2023
	 */
	public static Map<Integer,Student> fetchAllData() {
		return map;
	}

	/**
	 * this method accept argument to update and  update student data in map by using key
	 * 
	 * @author Anwith gowda
	 * @return
	 * @date 2023 Jul 07
	 * 
	 */

	public static boolean updateStudentPhoneById(int id, long phone) {
		Student student = findStudentByid(id);
		if (student!=null) {
			student.setStudentPhone(phone);
			return true;
		}
		return false;
	}

	/**
	 * this method store the delete student data in map by key 
	 * 
	 * @author Anwith gowda
	 * @return
	 * @date 2023 Jul 07
	 * 
	 */

	public static boolean removeStudentById(int id) {
		Student student = findStudentByid(id);
		if (student!=null) {
			map.remove(id);
			return true;
		}
		return false;
	}
}
