package edu.jsp.studentapp.bean;

import java.io.Serializable;

/**
 * @author Anwith gowda
 *
 */
public class Student implements Serializable {

	private int StudentId;
	private String studentName;
	private String studentEmail;
	private long studentPhone;
	private int studentAge;

	public int getStudentId() {
		return StudentId;
	}

	public void setStudentId(int studentId) {
		StudentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}






	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public long getStudentPhone() {
		return studentPhone;
	}

	public void setStudentPhone(long studentPhone) {
		this.studentPhone = studentPhone;
	}

	public int getStudentAge() {
		return studentAge;
	}

	public void setStudentAge(int studentAge) {
		this.studentAge = studentAge;
	}

	@Override
	public String toString() {
		return "StudentId=" + StudentId + "\nstudentName=" + studentName + "\nstudentEmail=" + studentEmail
				+ "\nstudentPhone=" + studentPhone + "\nstudentAge=" + studentAge ;
	}

}
