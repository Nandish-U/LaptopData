package edu.jsp.userapp.bean;

import java.io.Serializable;

/**
 * @author Anwith gowda
 *
 */
public class User implements Serializable{
	
	
	private String  userName;
	private String userEmail;
	private long userPhone;
	private int userAge;
	

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public long getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(long userPhone) {
		this.userPhone = userPhone;
	}
	public int getUserAge() {
		return userAge;
	}
	public void setUserAge(int userAge) {
		this.userAge = userAge;
	}
	
	@Override
	public String toString() {
		return "userName=" + userName + "\n userEmail=" + userEmail + "\n userPhone=" + userPhone + "\n userAge="
				+ userAge + "]";
	}
}
