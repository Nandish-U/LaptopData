package edu.jsp.userapp.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import edu.jsp.userapp.bean.User;

public class UserController {

	private static List<User> userList = new ArrayList<User>();

	/**
	 * this method create a user object the return the user to caller
	 * 
	 * @author Anvith
	 * @date 2023 JUL 06
	 * 
	 */
	public static User createUser(Scanner input) {
		User user = new User();
		System.out.println("Enter User Name");
		input.nextLine();
		user.setUserName(input.nextLine());
		System.out.println("Enter User Mail");
		user.setUserEmail(input.next());
		System.out.println("Enter User Phone Number");
		user.setUserPhone(input.nextLong());
		System.out.println("Enter User Age");
		user.setUserAge(input.nextInt());

		return user;
	}

	/**
	 * this method save user in the ArrayList
	 * 
	 * @author Anvith
	 * @date 2023 JUL 06
	 * 
	 */

	public static void saveUser(User user) {

		
		String userEmail = user.getUserEmail();
		userEmail = userEmail.toLowerCase();
		user.setUserEmail(userEmail);
		userList.add(user);
		
	}

	/**
	 * this method will find the user by id and return user
	 * 
	 * @author Anvith
	 * @date 2023 JUL 06
	 * 
	 */
	public static User findUserByEmail(String email) {
		for (User user : userList) {
			System.out.println(user.getUserName());
			if (user.getUserEmail().equals(email)) {
				return user;
			}
		}
		return null;
	}

	/**
	 * this method will update a user age by using email
	 * 
	 * @author Anvith
	 * @date 2023 JUL 06
	 * 
	 */
	public static String updateUserAgeByEmail(int age, String email) {
		User user = findUserByEmail(email);
		if (user != null) {

			user.setUserAge(age);
			return "user data updated";

		}
		return "user data not updated";

	}

	/**
	 * this method remove user from ArrayList
	 * 
	 * @author Anvith
	 * @date 2023 JUL 06
	 * 
	 */

	public static String removeUserByEmail(String email) {
		User user = findUserByEmail(email);
		if (user != null) {
			userList.remove(user);
			return "user data removed";

		}
		return "user data not found";
	}
}
