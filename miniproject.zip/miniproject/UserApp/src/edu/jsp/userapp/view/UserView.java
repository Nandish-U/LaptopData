package edu.jsp.userapp.view;

import java.util.Scanner;

import edu.jsp.userapp.bean.User;
import edu.jsp.userapp.controller.UserController;

public class UserView {
	static {
		System.out.println("Welcome to User App");
	}

	public static void main(String[] args) {
		
		Scanner input =new Scanner(System.in);
		while(true) {
			
		
		System.out.println("Select options");
		System.out.println("1.Save User\n2.Find User By Email");
		System.out.println("3.Update User Age By Email\n4.Remove user By Email");
		System.out.println("5.Exit");
		int options=input.nextInt();
		switch(options) {
		case 1:
		{
			User user =UserController.createUser(input);
			UserController.saveUser(user);
			break;
		}
		case 2:
		{
			System.out.println("Enter Email");
			User user =UserController.findUserByEmail(input.next());
			System.out.println(user);
			break;
		}
		
		case 3:
		{
			System.out.println("Enter Age and Email");
			UserController.updateUserAgeByEmail(input.nextInt(), input.next());
			break;
		}
		case 4:{
			System.out.println("Enter Email");
			UserController.removeUserByEmail(input.next());
			break;
		}
		case 5:{
			input.close();
			System.out.println("Thank You");
			System.exit(0);
			
		}
		default:System.out.println("invalid choice");
		}

	}
	}
}
