package com.nested;

 public class Demo1 {
    int a;
	class Demo2{
		void can() {
			System.out.println(a);
		}
	}
	
	static class demo3{
		public static void main(String[] args) {
			System.out.println("main2");
			con();
		}
		static void con() {
			System.out.println("hello");
		}
	}
 public static void main(String[] args) {
	System.out.println("main");
}
}
