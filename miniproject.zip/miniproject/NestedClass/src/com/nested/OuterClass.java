package com.nested;

public class OuterClass {
//static and non static variable  and method can  outer class have 
	String outer1="ouert 1";
	static String outer2="outer2";
	//outer class can have static and non-static class
	
	class InnnerClass{
        /**
         * inside non static inner class can contain
         * 1.non-static variable
         * 2.non-static method
         * 3.non-static inner class
         
         * it does not contain 
         * 1.static variable and static method
         * 2.static inner class
         */
		int i=10;
		
		public   void innerMethod() {
			
			System.out.println(outer1);
			System.out.println(outer2);
		}
	 
	 
	}
	static class InnerStaticClass{
		  /**
         * inside non static inner class can contain
         * 1.non-static variable
         * 2.non-static method
         * 3.non-static inner class
         *
         * 4.static variable and static method
         * 5.static inner class
         * 6.can't access non-static outer class variable
         */
		public  static void innerStatic2() {
//			System.out.println(outer1); cannot use non-static member in static inner class
			System.out.println(outer2);
			
		}
		public void innerStaticClass() {
			System.out.println(outer2);
		}
		
	}
	public void outerMet() {
		System.out.println("outer non static");
		
		InnerStaticClass.innerStatic2();
	}
	
	  /**
     * 1.static inner class variable access using class name
     * 2.to access inner static class non-static method create object
     * 3.to access non static class create the object of outer class and then call 
     * 4.object creation inner non static class follows
     * objectrefenceOfOuterClass.new InnerNonStaticClass()
     */
	public static void main(String[] args) {
		System.out.println("main start");
		System.out.println(outer2);
		InnerStaticClass.innerStatic2();
		InnerStaticClass i=new InnerStaticClass();
		i.innerStaticClass();
		System.out.println();
		System.out.println("=====================");
		OuterClass o=new OuterClass();
		InnnerClass in=o.new InnnerClass();
		in.innerMethod();
		in.i=45;
		System.out.println("main end");
	}
}
