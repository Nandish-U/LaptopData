package com.filehandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class FileInputStreamExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStream ip=null;
		try {
			ip=new FileInputStream("a.txt");
			int b=1;
			while(b<=10) {
				System.out.println((char) b);
				b=10;
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
