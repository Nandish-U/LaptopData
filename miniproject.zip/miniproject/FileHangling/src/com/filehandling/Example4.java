package com.filehandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Example4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> al=new ArrayList<String>();
		al.add("hello");
		al.add("hi");
		al.add("bye");
		al.add("good");
		
		//file output stream
		try {
			FileOutputStream fo=new FileOutputStream("D:\\testyanta\\miniproject\\a.txt\\A.txt");
//			ObjectOutputStream o=new ObjectOutputStream(fo);
			
			fo.write(1);
			fo.close();
//			o.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//deserilazation
		try {
			FileInputStream fi=new FileInputStream("D:\\testyanta\\miniproject\\a.txt\\A.txt");
			ObjectInputStream i=new ObjectInputStream(fi);
			ArrayList x=(ArrayList)i.readObject();
			System.out.println(x);
			fi.close();
			i.close();
		} catch (IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
