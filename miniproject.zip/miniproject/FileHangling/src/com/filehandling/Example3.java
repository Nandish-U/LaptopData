package com.filehandling;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class Example3 {

	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<String>();
		al.add("java");
		al.add("jdbc");
		al.add("collections");
		
//		//using iterator
//		Iterator<String> i=al.iterator();
//		while(i.hasNext()) {
//			System.out.println(i.next());
//		}
		
		//using listIterator
//		ListIterator<String> i=al.listIterator(al.size());
//		while(i.hasPrevious()) {
//			
//			System.out.println(i.previous());
//		}
		
		//using for each loop
		for(String s:al) {
			System.out.println(s);
		}
		System.out.println("foreach method");
		//using for each()
		al.forEach(a->{
			System.out.println(a);
		});
	}
}
