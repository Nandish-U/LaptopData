package com.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import lombok.Data;

@Entity
@Data
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator = "abc1")
	@SequenceGenerator(name="abc1",initialValue = 201,allocationSize = 1)
	private int a_id;
	private String area;
	private int pincode;
	
		
}
