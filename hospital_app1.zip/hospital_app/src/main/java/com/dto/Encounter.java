package com.dto;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import lombok.Data;

@Entity
@Data
public class Encounter {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator = "abc3")
	@SequenceGenerator(name="abc3",initialValue = 401,allocationSize = 1)
	private int e_id;
	private String cause;
	
	@ManyToOne
	@JoinColumn(name="my_person_id")
	private Person person;

	@ManyToOne
	@JoinColumn(name="my_branch_id")
	private Branch branch;
	
	@OneToMany(mappedBy = "encounter")
	private List<MedOrders> medorders;
}
