package com.dto;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;

import lombok.Data;

@Entity
@Data
public class Item {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator = "abc6")
	@SequenceGenerator(name="abc6",initialValue = 601,allocationSize = 1)
	private int item_id;
	private String item_name;
	private double item_price;
	
	@ManyToMany(mappedBy = "items")
	private List<MedOrders> medOrders;

}
