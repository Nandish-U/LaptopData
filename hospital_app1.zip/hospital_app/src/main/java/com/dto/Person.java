package com.dto;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import lombok.Data;

@Entity
@Data
public class Person {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator = "abc2")
	@SequenceGenerator(name="abc2",initialValue = 301,allocationSize = 1)
	private int p_id;
	private String p_name;
	private String place;
	
	@OneToMany(mappedBy = "person")
	private List<Encounter> encounters;
}
