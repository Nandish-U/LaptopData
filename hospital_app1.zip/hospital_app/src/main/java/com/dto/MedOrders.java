package com.dto;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

import lombok.Data;

@Entity
@Data
public class MedOrders {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator = "abc4")
	@SequenceGenerator(name="abc4",initialValue = 501,allocationSize = 1)
	private int order_id;
	private double price;
	
	@ManyToOne
	@JoinColumn(name="my_encounter_id")
	private Encounter encounter;
	
	@ManyToMany
	@JoinTable(joinColumns = @JoinColumn(name="my_orders_id"),
	inverseJoinColumns = @JoinColumn(name="my_item_id"))
	private List<Item> items;

}
