package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dto.Branch;
import com.dto.Person;

public class PersonDao {
	private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("vikas");
	private EntityManager entityManager=entityManagerFactory.createEntityManager();
	private EntityTransaction entityTransaction=entityManager.getTransaction();
	
	public void savePerson(Person person) {
		entityTransaction.begin();
		entityManager.persist(person);
		entityTransaction.commit();
		
	}
	public void updatePerson(Person person) {
		entityTransaction.begin();
		entityManager.merge(person);
		entityTransaction.commit();
		
	}
	
	public Person findPersonById(int id) {
		return entityManager.find(Person.class, id);
	
	}

}
