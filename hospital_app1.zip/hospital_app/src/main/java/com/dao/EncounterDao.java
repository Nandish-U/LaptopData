package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dto.Encounter;


public class EncounterDao {
	private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("vikas");
	private EntityManager entityManager=entityManagerFactory.createEntityManager();
	private EntityTransaction entityTransaction=entityManager.getTransaction();
	
	public void saveEncounter(Encounter encounter) {
		entityTransaction.begin();
		entityManager.persist(encounter);
		entityTransaction.commit();
		
	}
	
	public Encounter findEncounterById(int id) {
		return entityManager.find(Encounter.class, id);
	}

}
