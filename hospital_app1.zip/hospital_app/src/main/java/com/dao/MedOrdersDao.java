package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dto.MedOrders;

public class MedOrdersDao {
	private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("vikas");
	private EntityManager entityManager=entityManagerFactory.createEntityManager();
	private EntityTransaction entityTransaction=entityManager.getTransaction();
	
	public void saveMedOrders(MedOrders medOrders) {
		entityTransaction.begin();
		entityManager.persist(medOrders);
		entityTransaction.commit();
		
	}
	
	public void updateMedOrders(MedOrders medOrders) {
		entityTransaction.begin();
		entityManager.merge(medOrders);
		entityTransaction.commit();
		
	}
	
	public MedOrders findOrderById(int id) {
		return entityManager.find(MedOrders.class, id);
	}
}
