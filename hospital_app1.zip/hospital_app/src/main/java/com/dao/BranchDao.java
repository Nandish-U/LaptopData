package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.dto.Branch;
import com.dto.Hospital;

public class BranchDao {
	private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("vikas");
	private EntityManager entityManager=entityManagerFactory.createEntityManager();
	private EntityTransaction entityTransaction=entityManager.getTransaction();
	
	public void saveBranch(Branch branch) {
		entityTransaction.begin();
		entityManager.persist(branch);
		entityTransaction.commit();
		
	}
	public void updateBranch(Branch branch) {
		entityTransaction.begin();
		entityManager.merge(branch);
		entityTransaction.commit();
		
	}
	
	public void deleteBranch(Branch branch) {
		entityTransaction.begin();
		entityManager.remove(branch);
		entityTransaction.commit();
		
	}
	
	public Branch findBranchById(int id) {
		return entityManager.find(Branch.class, id);
	
	}
	
	public List<Branch> getAllBranch() {
		Query query =entityManager.createQuery("SELECT b FROM Branch b");
		return query.getResultList();
		
		
	}
}
