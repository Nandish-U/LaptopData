package com.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.dao.AddressDao;
import com.dao.BranchDao;
import com.dao.EncounterDao;
import com.dao.HospitalDao;
import com.dao.ItemDao;
import com.dao.MedOrdersDao;
import com.dao.PersonDao;
import com.dto.Address;
import com.dto.Branch;
import com.dto.Encounter;
import com.dto.Hospital;
import com.dto.Item;
import com.dto.MedOrders;
import com.dto.Person;

public class Driver {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		HospitalDao hospitalDao = new HospitalDao();
		BranchDao branchDao = new BranchDao();
		AddressDao addressDao = new AddressDao();
		PersonDao personDao = new PersonDao();
		EncounterDao encounterDao = new EncounterDao();
		MedOrdersDao medOrdersDao = new MedOrdersDao();
		ItemDao itemDao = new ItemDao();

		while (true) {
			System.out.println("1.Save hospital\n2.Save branches\n3.Save Address\n4.Save Person"
					+ "\n5.Save encounter\n6.Save MedOrders\n7.Save Item\n12.End");
			System.out.println("Enter choice");

			int choice = scanner.nextInt();

			switch (choice) {
			case 1: {
				Hospital hospital = new Hospital();
				hospital.setH_name("Sakra");
				hospitalDao.saveHospital(hospital);
			}
				break;
			case 2: {
				System.out.println("Enter hospital id");
				int id = scanner.nextInt();
				Hospital hospital = hospitalDao.findHospitalById(id);
				if (hospital != null) {
					Branch branch = new Branch();
					branch.setPhno(98765432);
					List<Branch> list = new ArrayList<Branch>();
					list.add(branch);

					hospital.setBranches(list);
					branch.setHospital(hospital);
					branchDao.saveBranch(branch);
					hospitalDao.updateHospital(hospital);

				} else {
					System.out.println("No hospital exists");
				}

			}
				break;

			case 3: {
				System.out.println("Enter branch id");
				int id = scanner.nextInt();
				Branch branch = branchDao.findBranchById(id);
				if (branch != null) {
					Address address = new Address();
					address.setArea("hebbala");
					address.setPincode(560065);

					branch.setAddress(address);
					addressDao.saveAddress(address);
					branchDao.updateBranch(branch);

				}

			}
				break;
			case 4: {
				Person person = new Person();
				person.setP_name("Ammu");
				person.setPlace("Bangalore");
				personDao.savePerson(person);
			}
				break;

			case 5: {
				System.out.println("Enter branch id");
				int id = scanner.nextInt();
				Branch branch = branchDao.findBranchById(id);

				System.out.println("Enter person id");
				int id1 = scanner.nextInt();
				Person person = personDao.findPersonById(id1);

				if (branch != null && person != null) {
					Encounter encounter = new Encounter();
					encounter.setCause("thd");

					encounter.setBranch(branch);
					encounter.setPerson(person);
					encounterDao.saveEncounter(encounter);

				}

			}
				break;
			case 6: {
				System.out.println("Enter encounter id");
				int id = scanner.nextInt();
				Encounter encounter = encounterDao.findEncounterById(id);
				if (encounter != null) {
					MedOrders medOrders = new MedOrders();
					medOrders.setPrice(233.4);
					medOrders.setEncounter(encounter);

					MedOrders medOrders1 = new MedOrders();
					medOrders1.setPrice(566.8);
					medOrders1.setEncounter(encounter);

					List<MedOrders> list = new ArrayList<MedOrders>();
					list.add(medOrders);
					list.add(medOrders1);

					encounter.setMedorders(list);

					medOrdersDao.saveMedOrders(medOrders);
					medOrdersDao.saveMedOrders(medOrders1);

				}

			}
				break;

			case 7: {
				System.out.println("Enter order_id");
				int id = scanner.nextInt();
				MedOrders medOrders = medOrdersDao.findOrderById(id);
				if (medOrders != null) {
					List<Item> l1=medOrders.getItems();
					
					Item item = new Item();
					item.setItem_name("Dolo");
					item.setItem_price(67.8);

					Item item1 = new Item();
					item1.setItem_name("para");
					item1.setItem_price(34.6);

//					List<Item> list = new ArrayList<Item>();
//					list.add(item);
//					list.add(item1);
					
					l1.add(item1);
					l1.add(item);

					List<MedOrders> list1 = new ArrayList<MedOrders>();
					list1.add(medOrders);

					medOrders.setItems(l1);
					item.setMedOrders(list1);

					itemDao.saveItem(item);
					itemDao.saveItem(item1);
					
					medOrdersDao.updateMedOrders(medOrders);
					
				}

			}
				break;
			case 12: {
				System.out.println("Thanks");
				System.exit(0);
			}

			}
		}
	}
}
