package com.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.dao.AddressDao;
import com.dao.BranchDao;
import com.dao.EncounterDao;
import com.dao.HospitalDao;
import com.dao.ItemDao;
import com.dao.MedOrdersDao;
import com.dao.PersonDao;
import com.dto.Address;
import com.dto.Branch;
import com.dto.Hospital;

public class HospitalDriver {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		HospitalDao hospitalDao = new HospitalDao();
		BranchDao branchDao = new BranchDao();
		AddressDao addressDao = new AddressDao();
		PersonDao personDao = new PersonDao();
		EncounterDao encounterDao = new EncounterDao();
		MedOrdersDao medOrdersDao = new MedOrdersDao();
		ItemDao itemDao = new ItemDao();

		while (true) {
			System.out.println(
					"1.Hospital\n2.Branches\n3.Address\n4.Person" + "\n5.Encounter\n6.MedOrders\n7.Item\n8.End");
			System.out.println("Enter choice");
			int choice = scanner.nextInt();

			switch (choice) {
			case 1: {

				boolean flag = true;
				while (flag) {
					System.out.println("1.Save hospital\n2.Delete\n3.FindById\n4.End");
					System.out.println("Enter choice");
					int choice1 = scanner.nextInt();

					switch (choice1) {
					case 1: {
						Hospital hospital = new Hospital();
						System.out.println("Enter Hospital Name");
						hospital.setH_name(scanner.next());
						hospitalDao.saveHospital(hospital);

					}
						break;

					case 2: {
						System.out.println("Enter hospital id");
						int id = scanner.nextInt();
						hospitalDao.deleteHospital(hospitalDao.findHospitalById(id));
					}
						break;
					case 3: {
						System.out.println("Enter hospital id");
						int id = scanner.nextInt();
						Hospital hospital = hospitalDao.findHospitalById(id);
						System.out.println(hospital.getH_id());
						System.out.println(hospital.getH_name());

					}
						break;
					case 4: {
						flag = false;
					}
					}
				}

			}
				break;
			case 2: {
				boolean flag = true;
				while (flag) {
					System.out.println("1.Save\n2.Update\n3.Delete\n4.FindById\n5.FetchAll\n6.End");
					System.out.println("Enter choice");
					int choice1 = scanner.nextInt();
					switch (choice1) {
					case 1: {
						System.out.println("Enter hospital id");
						int id = scanner.nextInt();
						Hospital hospital = hospitalDao.findHospitalById(id);
						if (hospital != null) {
							Branch branch = new Branch();
							System.out.println("Enter branch phone number");
							branch.setPhno(scanner.nextLong());
							List<Branch> list = new ArrayList<Branch>();
							list.add(branch);

							hospital.setBranches(list);
							branch.setHospital(hospital);
							branchDao.saveBranch(branch);
							hospitalDao.updateHospital(hospital);

						} else {
							System.out.println("No hospital exists");
						}

					}
						break;

					case 2: {
						System.out.println("Enter branch id");

						Branch branch = branchDao.findBranchById(scanner.nextInt());
						System.out.println("Enter new phno");
						branch.setPhno(scanner.nextLong());

						branchDao.updateBranch(branch);
					}
						break;
					case 3: {
						System.out.println("Enter branch id");

						Branch branch = branchDao.findBranchById(scanner.nextInt());
						branchDao.deleteBranch(branch);
					}
						break;

					case 4: {
						System.out.println("Enter branch id");
						Branch branch = branchDao.findBranchById(scanner.nextInt());
						System.out.println(branch.getBranch_id());
						System.out.println(branch.getPhno());
					}
						break;

					case 5: {
						List<Branch> branches = branchDao.getAllBranch();
						for (Branch branch : branches) {
							System.out.println(branch.getBranch_id());
							System.out.println(branch.getPhno());
							System.out.println("-----------------------------");
						}
					}
						break;
					case 6:
						flag = false;
						break;
					default:
						System.out.println("Invalid choice");
					}
				}

			}
				break;
			case 3: {
				boolean flag = true;
				while (flag) {
					System.out.println("1.SaveAddress to branch\n2.Update\n3.Delete\n4.FindById\n6.End");
					System.out.println("Enter choice");
					int choice1 = scanner.nextInt();
					switch (choice1) {
					case 1: {
						System.out.println("Enter branch id");
						int id = scanner.nextInt();
						Branch branch = branchDao.findBranchById(id);
						if (branch != null) {
							Address address = new Address();
							System.out.println("Enter area");
							address.setArea(scanner.next());
							System.out.println("Enter pincode");
							address.setPincode(scanner.nextInt());

							branch.setAddress(address);
							addressDao.saveAddress(address);
							branchDao.updateBranch(branch);

						} else {
							System.out.println("No branch exists");
						}
					}
						break;
						
					case 2:{
						System.out.println("Enter address id");
						
						System.out.println("1.Update area\n2.Update pincode");
						System.out.println("Enter choice");
						
						switch(scanner.nextInt()) {
						case 1:{
							
						}
							break;
						}
						
					}
						break;
					case 6:
						flag = false;

					}

				}
			}
				break;
			case 4: {

			}
				break;
			case 5: {

			}
				break;
			case 6: {

			}
				break;
			case 7: {

			}
				break;
			case 8: {

			}
				break;

			default: {

			}

			}

		}
	}

}
