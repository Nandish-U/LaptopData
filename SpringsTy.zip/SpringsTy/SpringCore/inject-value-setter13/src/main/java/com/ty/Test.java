package com.ty;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test 
{
	public static void main(String[] args) 
	{
		ConfigurableApplicationContext applicationContext =  new ClassPathXmlApplicationContext("my_cofig.xml");
		Student student = (Student)applicationContext.getBean("mystudent");
		System.out.println(student.getName());
		System.out.println(student.getAge());
		System.out.println(student.getHeight());
	}
}
