package com.ty;

public class Teacher 
{
	private int id;
	private String name;
	private double height;
	
	
	Teacher(int id, String name, double height)
	{
		this.id = id;
		this.name = name;
		this.height = height;
	}
	
	public void display()
	{
		System.out.println("Teacher id is : "+id);
		System.out.println("Teacher name is : "+name);
		System.out.println("Teacher height is : "+height);
	}
}
