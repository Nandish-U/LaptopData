package com.ty;

public class Student 
{
	String name;
	
	public Student(String name )
	{
		this.name = name;
	}
	public void printName()
	{
		System.out.println("Student name is "+name);
	}
}
