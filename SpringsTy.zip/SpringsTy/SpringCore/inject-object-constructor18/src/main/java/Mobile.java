
public class Mobile 
{
	private String name;
	private String model;
	
	
	public void ring()
	{
		System.out.println("Mobile is ringing");
	}
}
