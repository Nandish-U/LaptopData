
public class Person {
	private Mobile mobile;
	
	public Person(Mobile mobile)
	{
		this.mobile = mobile;
	}
	
	public void use()
	{
		System.out.println("Person is using");
		mobile.ring();
	}
}
