package com.all;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.qspiders.Staff;
import com.ty.Student;
import com.ty.Teacher;

public class TestAll {
	public static void main(String[] args) 
	{
		ConfigurableApplicationContext applicationContext= new ClassPathXmlApplicationContext("my_cofig.xml");
		Student student = (Student)applicationContext.getBean("mystudent");
		Teacher teacher = (Teacher)applicationContext.getBean("myteacher");
		Staff staff = (Staff)applicationContext.getBean("mystaff");
		
		student.run();
		teacher.read();
		staff.work();
	}
}		
