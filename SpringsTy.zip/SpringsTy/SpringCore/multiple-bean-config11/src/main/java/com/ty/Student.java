package com.ty;

public class Student 
{
	public void run()
	{
		System.out.println("Student is running");
	}
}
