package com.ty;

public class Teacher {
	public void read()
	{
		System.out.println("Teacher's are reading");
	}
}
