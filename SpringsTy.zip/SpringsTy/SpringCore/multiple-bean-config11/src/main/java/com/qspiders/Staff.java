package com.qspiders;

public class Staff {
	public void work()
	{
		System.out.println("Staff's are working");
	}
}
