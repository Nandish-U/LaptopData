package com.ty;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAppCont 
{
	public static void main(String[] args) 
	{
		ConfigurableApplicationContext appcont = new ClassPathXmlApplicationContext("my_cofig.xml");
		Person person = (Person)appcont.getBean("myperson");
		person.message();
	}
}
