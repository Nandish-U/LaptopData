package com.ty;

public class Person 
{
	public void message()
	{
		System.out.println("Hi i am called");
	}
}
