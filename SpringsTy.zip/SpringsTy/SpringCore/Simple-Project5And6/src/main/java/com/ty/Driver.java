package com.ty;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Driver 
{
	public static void main(String[] args) 
	{
		//core container 
		Resource resource = new ClassPathResource("my_cofig.xml");
		BeanFactory beanFactory =  new XmlBeanFactory(resource);
		Person person = (Person)beanFactory.getBean("myperson");
		person.message();
	}
}
