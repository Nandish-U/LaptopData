package com.ty;

public class Mobile {
	public void ring()
	{
		System.out.println("Mobile is ringing");
	}
}
