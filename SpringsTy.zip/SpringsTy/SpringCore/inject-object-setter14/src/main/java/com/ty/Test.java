package com.ty;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test 
{
	public static void main(String[] args) {
	
	ConfigurableApplicationContext applicationContext= new ClassPathXmlApplicationContext("my_cofig.xml");
	Person person =	(Person)applicationContext.getBean("myperson");
//		person.use();
	
	Mobile mobile = person.getMobile();
	mobile.ring();
	}
}
