package com.ty;

import java.util.List;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestA 
{
	public static void main(String[] args) 
	{
		ConfigurableApplicationContext applicationContext = new ClassPathXmlApplicationContext("my_cofig.xml");
		Student student = (Student)applicationContext.getBean("mystudent");
		
		System.out.println("Name :"+student.getName());
		System.out.println("Name :"+student.getAge());
		
		List<String> sub =  student.getSubjectName();
		for (String string : sub) {
			System.out.println(string);
		}
	}
}
