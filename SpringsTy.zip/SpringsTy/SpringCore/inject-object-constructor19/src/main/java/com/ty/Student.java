package com.ty;

import java.util.List;

public class Student {
	private String name;

	List<String> subjectName;
	
	Student(String name, List<String> subjectName)
	{
		this.name = name;
		this.subjectName = subjectName;
	}
	public void display()
	{
		System.out.println("Student name :"+name);
		for(String subject: subjectName)
		{
			System.out.println(subject);
		}
	}
}
