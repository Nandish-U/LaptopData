
public class Mobile 
{
	private String name;
	private double cost;
	
	Mobile(String name, double cost)
	{
		this.name = name;
		this.cost = cost;
	}
	
	public void display()
	{
		System.out.println(name);
		System.out.println(cost);
	}
}
