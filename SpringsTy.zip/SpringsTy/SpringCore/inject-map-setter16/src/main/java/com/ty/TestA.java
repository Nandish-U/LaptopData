package com.ty;

import java.util.Map;
import java.util.Set;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestA {
	public static void main(String[] args) 
	{
		ConfigurableApplicationContext applicationContext =  new ClassPathXmlApplicationContext("my_cofig.xml");
		Shop shop = (Shop)applicationContext.getBean("myshop");
		
		System.out.println("Shop name : "+shop.getName());
		
		Map<String, Double> map =  shop.getMap();
//		Set<String> keys =  map.keySet();
//		for (String key : keys) {
//			System.out.println(key+" "+map.get(key));
//		}
		for(Map.Entry<String, Double> entry:map.entrySet())
		{
			System.out.println(entry.getKey()+" "+entry.getValue());
		}
	}
}
