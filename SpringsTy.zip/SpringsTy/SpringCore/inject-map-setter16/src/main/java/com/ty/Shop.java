package com.ty;

import java.util.Map;

public class Shop 
{
	private String name;
	private Map<String, Double> map;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Map<String, Double> getMap() {
		return map;
	}
	public void setMap(Map<String, Double> map) {
		this.map = map;
	}
	
	
}
