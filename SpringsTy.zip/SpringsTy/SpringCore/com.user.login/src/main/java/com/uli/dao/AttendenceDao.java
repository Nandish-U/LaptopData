package com.uli.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.uli.dto.Attendence;

@Component
public class AttendenceDao {
	@Autowired
	EntityManagerFactory entityManagerFactory;
	@Autowired
	EntityManager entityManager;
	@Autowired
	EntityTransaction entityTransaction;

	public Attendence saveAttendence(Attendence attendence) {
		entityTransaction.begin();
		entityManager.persist(attendence);
		entityTransaction.commit();
		return attendence;
	}

	public List<Attendence> findAttendanceByUserId(int userId) {
		Query query = entityManager.createQuery("select a from Attendence a where u.id=?1");
		query.setParameter(1, userId);
		List<Attendence> attendances = query.getResultList();
		return attendances;
	}
}
