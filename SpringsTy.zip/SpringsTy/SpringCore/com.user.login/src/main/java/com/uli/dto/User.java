package com.uli.dto;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name="user1") 
@Component
public class User 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY,generator = "user_atten_gen")
	@SequenceGenerator(name="user_atten_gen", initialValue = 100,allocationSize = 1)
	private int id;
	private String name;
	private long phno;
	private String password;
	@OneToMany
	private List<Attendence> attendences;
	
}
