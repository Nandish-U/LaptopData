package com.uli.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.uli.dao.AttendenceDao;
import com.uli.dao.UserDao;
import com.uli.dto.Attendence;
import com.uli.dto.User;
import com.uli.service.MyConfig;

public class View {

	public static void main(String[] args) {
		ConfigurableApplicationContext applicationContext = new AnnotationConfigApplicationContext(MyConfig.class);
		User user = (User) applicationContext.getBean("user");
		Attendence attendence = (Attendence) applicationContext.getBean("attendence");

		UserDao dao = (UserDao) applicationContext.getBean("userDao");
		AttendenceDao attendenceDao = (AttendenceDao) applicationContext.getBean("attendenceDao");
		Scanner sc = new Scanner(System.in);
		System.out.println("1: Register\n 2: Login\n 3: Exit");
		System.out.println("Enter the choice");
		int choice = sc.nextInt();

		switch (choice) {
		case 1: {
			System.out.println("Enter the name");
			String name = sc.next();
			System.out.println("Enter the phno");
			long phno = sc.nextLong();
			System.out.println("Enter the password");
			String password = sc.next();
			user.setName(name);
			user.setPassword(password);
			user.setPhno(phno);

			dao.saveUser(user);
		}
			break;
		case 2: {
			System.out.println("Enter the phno");
			long phno = sc.nextLong();

			System.out.println("Enter the password");
			String password = sc.next();

			User user1 = dao.findUserByPhoneAndPassword(phno, password);

			if (user1 != null) {
				attendenceDao.saveAttendence(attendence);
				List<Attendence> attendences = new ArrayList<Attendence>();
				attendences.add(attendence);
				user1.setAttendences(attendences);
				dao.updateUser(user1);
			}
		}
			break;
		case 3: {
			System.out.println("ThankYou...!");
			System.exit(0);
		}
		}
	}
}


