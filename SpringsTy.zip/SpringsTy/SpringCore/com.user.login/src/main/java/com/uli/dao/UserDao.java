package com.uli.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.uli.dto.User;

@Component  
public class UserDao 
{
	@Autowired
	EntityManagerFactory entityManagerFactory;
	@Autowired
	EntityManager entityManager;
	@Autowired 
	EntityTransaction entityTransaction;

	public User saveUser(User user)
	{
		entityTransaction.begin();
		entityManager.persist(user);
		entityTransaction.commit();
		return user;
	}
	
	public User updateUser(User user)
	{
		entityTransaction.begin();
		entityManager.merge(user);
		entityTransaction.commit();
		return user;
	}
	
	public User findUserByPhoneAndPassword(long phno, String password)
	{
		Query query =  entityManager.createQuery("select s from User s where phno=?1 and password=?2");
		query.setParameter(1, phno);
		query.setParameter(2, password);
		 List<User> user =  query.getResultList();
		 return user.get(0);
	}
}
