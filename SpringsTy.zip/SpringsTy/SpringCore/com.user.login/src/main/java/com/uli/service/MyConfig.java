package com.uli.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.uli.dto.Attendence;

@Configuration
@ComponentScan(basePackages = "com.uli")
public class MyConfig 
{
	@Bean
	public EntityManagerFactory getEmf()
	{
		return Persistence.createEntityManagerFactory("vikas");
	}
	@Bean
	public EntityManager getEm()
	{
		return getEmf().createEntityManager();
	}
	@Bean
	public EntityTransaction getTransaction()
	{
		return getEm().getTransaction();
	}
	
}
