package com.collage.ty;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) 
	{
		ConfigurableApplicationContext applicationContext =  new ClassPathXmlApplicationContext("my_cofig1.xml");
		Teacher teacher = (Teacher)applicationContext.getBean("myteacher");
		teacher.read();
	}
}
