package com.collage.ty;

public class Teacher {
	public void read()
	{
		System.out.println("Teacher is reading");
	}
}
